"""Combina los resultados de Explorar_E3 y de Explorar_E3_E (mismos pliegues y semillas) en una sola tabla de desarrollo.

    python combinar_exploraciones.py RUTA\\resultados_exploracion_e3 RUTA\\resultados_exploracion_e3_E [salida]

- Comprueba que las celdas compartidas (E·control y patchtst·control) coincidan corrida a corrida: es una prueba de
  reproducibilidad entre paquetes.
- Aplica la regla 6 del plan de la exploración de E: ema_coh y ema_dro deben mejorar a E·coh y E·dro de Explorar_E3.
- Ordena todas las celdas por MASE de desarrollo; no reemplaza ninguna decisión congelada (solo informa).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def leer(r: Path) -> pd.DataFrame:
    f = r / "decision" / "desarrollo_por_semilla.csv"
    if not f.exists():
        raise SystemExit(f"No encuentro {f}: termine primero la etapa decision de ese paquete")
    return pd.read_csv(f)


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    a, b = Path(sys.argv[1]), Path(sys.argv[2])
    sal = Path(sys.argv[3]) if len(sys.argv) > 3 else b.parent / "resultados_exploracion_combinados"
    sal.mkdir(parents=True, exist_ok=True)
    ta, tb = leer(a).assign(paquete="Explorar_E3"), leer(b).assign(paquete="Explorar_E3_E")
    comunes = sorted(set(ta.celda) & set(tb.celda))
    repro = []
    for c in comunes:
        x = ta[ta.celda == c].set_index(["pliegue", "semilla"]).MASE
        y = tb[tb.celda == c].set_index(["pliegue", "semilla"]).MASE
        j = x.index.intersection(y.index)
        repro.append(dict(celda=c, pares=len(j), dif_max_abs=float(np.abs(x.loc[j] - y.loc[j]).max())))
    t = pd.concat([ta, tb[~tb.celda.isin(comunes)]], ignore_index=True)
    r = t.groupby(["celda", "paquete"]).MASE.agg(["mean", "std", "size"]).reset_index().sort_values("mean")
    m = dict(zip(r.celda, r["mean"]))
    regla6 = {c: {q: bool(c in m and q in m and m[c] < m[q]) for q in qs} for c, qs in
              {"E·ema_coh": ["E·coh"], "E·ema_dro": ["E·dro"]}.items() if c in m}
    r.to_csv(sal / "desarrollo_resumen_combinado.csv", index=False)
    t.to_csv(sal / "desarrollo_por_semilla_combinado.csv", index=False)
    info = dict(reproducibilidad_celdas_comunes=repro, regla_6=regla6,
                decisiones={p.name: json.loads((p / "decision" / "decision.json").read_text(encoding="utf-8")).get("ganadora") for p in (a, b)},
                N_d_total=sum(json.loads((p / "decision" / "decision.json").read_text(encoding="utf-8"))["N_d_esta_exploracion"] for p in (a, b)) + 5)
    (sal / "COMBINACION.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    print(r.head(15).to_string(index=False))
    print(json.dumps(info, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

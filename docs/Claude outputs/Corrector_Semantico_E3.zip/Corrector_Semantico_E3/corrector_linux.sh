#!/usr/bin/env bash
# Corrector semántico del Entregable 3 en Linux (GPU NVIDIA, AMD con ROCm o CPU). Argumentos opcionales: los de ejecutar_corrector.py
set -e
cd "$(dirname "$0")"
PY=$(command -v python3.12 || command -v python3.11 || command -v python3 || true)
[ -z "$PY" ] && { echo "Instale Python 3.10-3.14 (y python3-venv)"; exit 1; }
exec "$PY" lanzar.py "$@"

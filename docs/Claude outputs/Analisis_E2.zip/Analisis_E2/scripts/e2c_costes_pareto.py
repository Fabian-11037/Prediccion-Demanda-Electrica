"""Costes, frontera de Pareto, coste por unidad de mejora y equivalencia práctica (§4.2, §6.2, §11.4).

* Parámetros y FLOPs por origen: se reconstruye cada red con sus pesos (``torch.utils.flop_counter``) para los
  modelos base (instantánea del repositorio) y, si existe la carpeta de artefactos consolidados, para las
  arquitecturas ampliadas. Los procedimientos nuevos traen sus costes en ``resultado.json`` (paquete Completar_E2).
* Memoria pico de inferencia (proceso, CPU) medida aquí; la memoria pico de entrenamiento solo existe para N-HiTS y
  para los procedimientos del paquete Completar_E2 (se declara la ausencia en los demás).
* Latencia: mediana por origen de los archivos de latencia publicados (CPU, lote 1, un hilo) y del paquete.
* Pareto: no dominados en (MASE, parámetros), (MASE, FLOPs) y (MASE, latencia).
* eta_k = (MASE_base - MASE_k) / (coste_k - coste_base), respecto del mejor baseline no profundo, con IC por bootstrap.
* Equivalencia (TOST, IC 90 % por bootstrap de bloques): procedimientos más baratos que el mejor y equivalentes a él
  dentro de +-3 %.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

import e2c_comun as K

CLASICOS = ["arx_lineal", "clasico_lightgbm__N", "clasico_mstl_ets__N", "clasico_mstl_arima__N"]


def flops(red, *args) -> int | None:
    import torch
    from torch.utils.flop_counter import FlopCounterMode
    try:
        with torch.no_grad(), FlopCounterMode(display=False) as fc:
            red(*args)
        return int(fc.get_total_flops()) + _flops_lstm(red, lambda: red(*args))
    except Exception:
        return None


def _flops_lstm(red, llamar) -> int:
    """FlopCounterMode no cuenta la recurrencia de nn.LSTM: se suma 2 x 4 h (i + h) por paso, capa y muestra."""
    import torch
    extra, ganchos = [0], []
    for mod in red.modules():
        if isinstance(mod, torch.nn.LSTM):
            def g(m, entrada, salida):
                x = entrada[0]
                B, T = (x.shape[0], x.shape[1]) if m.batch_first else (x.shape[1], x.shape[0])
                i, h = m.input_size, m.hidden_size
                for capa in range(m.num_layers):
                    extra[0] += 2 * 4 * h * ((i if capa == 0 else h) + h) * T * B
            ganchos.append(mod.register_forward_hook(g))
    with torch.no_grad():
        llamar()
    for x in ganchos:
        x.remove()
    return extra[0]


def base_costes() -> list[dict]:
    import sys
    import torch
    import psutil
    import importancia_variables as IV
    sha = json.loads((K.R / "results/jbook/modelos_actualizados.json").read_text())["commit"]
    snap = K.R / "results/repositorio" / sha
    sys.path.insert(0, str(snap / "src"))
    from demanda import modelos_base as M
    from demanda.reentrenamiento_v3 import Secuencial as CNN
    from demanda.variantes_v4 import Secuencial as LSTM
    reg = json.loads((snap / "results/consolidado/modelos.json").read_text(encoding="utf-8"))
    cols = json.loads((snap / reg["mlp"]["artefactos"][0]["escaladores"]).read_text(encoding="utf-8"))["columnas_cal"]
    panel = pd.read_parquet(K.R / "data/processed/panel_horario.parquet", columns=["x_demanda_real_kwh", "y_demanda_real_kwh", *cols])
    out = []
    for nombre in K.FAMILIA_BASE:
        a = reg[nombre]["artefactos"][0]
        esc = json.loads((snap / a["escaladores"]).read_text(encoding="utf-8"))
        xp, cf, nv, y, _ = IV.restaurar_entradas(panel, K.FECHAS[:8], esc)
        shapes = SimpleNamespace(x=xp[:, :, :1], cal_p=xp[:, :, 1:], cal_f=cf)
        params = reg[nombre]["configuracion"]["params"]
        red = LSTM(nombre, params, shapes) if nombre == "lstm" else CNN(nombre, params, shapes) if nombre == "cnn1d" else M.construir_red(nombre, params, shapes)
        red.eval()
        rss0 = psutil.Process().memory_info().rss
        f = flops(red, torch.from_numpy(xp[:1]), torch.from_numpy(cf[:1]))
        out.append(dict(clave=nombre, parametros=int(sum(p.numel() for p in red.parameters())), flops_por_origen=f,
                        memoria_inferencia_mb=round((psutil.Process().memory_info().rss - rss0) / 2**20, 2), fuente_flops="reconstruido"))
    return out


def ampliados_costes() -> list[dict]:
    import torch
    import inferencia_ampliada as IA
    E = IA.Entradas()
    out, vistos = [], set()
    for m in IA.registro():
        k = m["experimento"] + "__" + m["variante"]
        if k in vistos:
            continue
        vistos.add(k)
        red, data, repo = IA.cargar(m, E)
        ix = np.arange(1)
        x = torch.from_numpy(np.ascontiguousarray(data["x"][ix])); cf = torch.from_numpy(np.ascontiguousarray(data["cf"][ix]))
        if repo:
            f = flops(red, x, cf)
        else:
            cp = torch.from_numpy(np.ascontiguousarray(data["cp"][ix])); dia = torch.from_numpy(np.ascontiguousarray(data["dia"][ix]))
            f = flops(red, x, cp, cf, dia)
        out.append(dict(clave=k, parametros=int(sum(p.numel() for p in red.parameters() if p.requires_grad)), flops_por_origen=f, fuente_flops="reconstruido"))
    return out


def nuevos_costes(base: Path) -> list[dict]:
    out = []
    for r in sorted(base.glob("*/final/*/semilla_1000/resultado.json")) + sorted(base.glob("clasico_lightgbm/final/semilla_1000/resultado.json")):
        d = json.loads(r.read_text(encoding="utf-8"))
        exp = r.parts[-5] if r.parts[-4] == "final" else r.parts[-4]
        var = r.parts[-3] if r.parts[-4] == "final" else "N"
        if exp == "clasico_lightgbm":
            k = "clasico_lightgbm__N"
        else:
            k = f"{exp}__{var.replace('_', '+')}"
        c = d.get("costes", {})
        out.append(dict(clave=k, parametros=d["n_parametros"], flops_por_origen=c.get("flops_por_origen"), latencia_mediana_ms=c.get("latencia_ms_por_origen_lote"),
                        memoria_pico_entrenamiento_gpu_mb=c.get("memoria_pico_gpu_mb"), memoria_pico_entrenamiento_proceso_mb=c.get("memoria_pico_proceso_mb"),
                        energia_entrenamiento_gpu_wh=c.get("energia_gpu_wh"), fuente_flops="paquete Completar_E2", nota_latencia="lote de evaluación, no lote 1"))
    for p in sorted(base.glob("clasico_mstl/*/prueba_W*.npz")):
        with np.load(p) as z:
            out.append(dict(clave=f"clasico_mstl_{p.parent.name}__N", parametros=None, flops_por_origen=None,
                            latencia_mediana_ms=1000 * float(z["segundos"]) / len(z["y_kwh"]), fuente_flops="no aplica (ajuste por origen)"))
    return out


def pareto(df: pd.DataFrame, coste: str) -> list[str]:
    d = df.dropna(subset=[coste]).sort_values([coste, "MASE"])
    return d[d.MASE <= d.MASE.cummin()].clave.tolist()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resultados-e2", default=None)
    ap.add_argument("--solo-base", action="store_true")
    a = ap.parse_args()
    P, Y, nombres, _ = K.cargar_predicciones(a.resultados_e2)
    L = K.perdidas(P, Y)
    filas = base_costes()
    if not a.solo_base:
        filas += ampliados_costes()
    if a.resultados_e2:
        filas += nuevos_costes(Path(a.resultados_e2))
    c = pd.DataFrame(filas).drop_duplicates("clave", keep="last").set_index("clave")
    lat = pd.read_csv(K.R / "results/diagnosticos_ampliados/latencia_resumen.csv").set_index("clave").mediana_ms
    latb = pd.read_csv(K.R / "results/jbook/modelos_actuales/latencia_inferencia.csv").groupby("modelo").mediana_ms.median()
    c["latencia_mediana_ms"] = c.get("latencia_mediana_ms", pd.Series(dtype=float))
    for k in c.index:
        if pd.isna(c.loc[k, "latencia_mediana_ms"]):
            c.loc[k, "latencia_mediana_ms"] = lat.get(k, latb.get(k, np.nan))
    c["MASE"] = [float(L[k].mean()) if k in L else np.nan for k in c.index]
    c["procedimiento"] = [nombres.get(k, k) for k in c.index]
    c = c.reset_index()
    K.guardar("costes.csv", c)
    fr = {x: pareto(c, x) for x in ("parametros", "flops_por_origen", "latencia_mediana_ms")}
    clas = [k for k in CLASICOS if k in L]
    base = min(clas, key=lambda k: L[k].mean())
    idx = K.indices_bloques(K.N, K.BLOQUE, 4000, K.SEMILLA + 21)
    eta, tost = [], []
    lb = L[base].to_numpy()
    mejor = L.drop(columns=[x for x in L.columns if x.startswith("ingenuo")]).mean().idxmin()
    lm = L[mejor].to_numpy()
    cb = c.set_index("clave")
    for k in c.clave:
        if k not in L:
            continue
        lk = L[k].to_numpy()
        for coste in ("flops_por_origen", "latencia_mediana_ms"):
            ck, c0 = cb.loc[k, coste], cb.loc[base, coste] if base in cb.index else np.nan
            if pd.notna(ck) and pd.notna(c0) and ck != c0:
                bs = (lb[idx].mean(1) - lk[idx].mean(1)) / (ck - c0)
                eta.append(dict(clave=k, procedimiento=nombres[k], coste=coste, baseline=nombres[base], eta=float((lb.mean() - lk.mean()) / (ck - c0)),
                                ic95_inf=float(np.percentile(bs, 2.5)), ic95_sup=float(np.percentile(bs, 97.5))))
        if k != mejor:
            rel = 100 * (lk[idx].mean(1) - lm[idx].mean(1)) / lm[idx].mean(1)
            lo, hi = np.percentile(rel, [5, 95])
            tost.append(dict(clave=k, procedimiento=nombres[k], mejor=nombres[mejor], diferencia_relativa_pct=float(100 * (lk.mean() - lm.mean()) / lm.mean()),
                             ic90_inf=float(lo), ic90_sup=float(hi), equivalente_TOST_3pct=bool(-3 < lo and hi < 3),
                             mas_barato_en_latencia=bool(pd.notna(cb.loc[k, "latencia_mediana_ms"]) and cb.loc[k, "latencia_mediana_ms"] < cb.loc[mejor, "latencia_mediana_ms"]) if mejor in cb.index and k in cb.index else None))
    K.guardar("coste_por_unidad_de_mejora.csv", pd.DataFrame(eta))
    K.guardar("equivalencia_practica_TOST.csv", pd.DataFrame(tost))
    K.guardar_json("pareto.json", {x: [nombres.get(k, k) for k in v] for x, v in fr.items()} | dict(memoria_pico_entrenamiento_existente=["N-HiTS · N (registro propio)", "procedimientos del paquete Completar_E2"]))
    _figura(c)
    print(c[["procedimiento", "parametros", "flops_por_origen", "latencia_mediana_ms", "MASE"]].to_string(index=False))
    print(json.dumps(fr, ensure_ascii=False))


def _figura(c: pd.DataFrame) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 3, figsize=(17, 4.8))
    for ax, x, et in zip(axes, ("parametros", "flops_por_origen", "latencia_mediana_ms"), ("Parámetros", "FLOPs por origen", "Latencia mediana (ms, CPU)")):
        d = c.dropna(subset=[x, "MASE"])
        if d.empty:
            continue
        nd = set(pareto(d, x))
        ax.scatter(d[x], d.MASE, c=["#be5146" if k in nd else "#9ba5ae" for k in d.clave], s=28)
        for r in d.itertuples():
            ax.annotate(r.procedimiento, (getattr(r, x), r.MASE), fontsize=6, xytext=(3, 2), textcoords="offset points")
        ax.set_xscale("log")
        ax.set_xlabel(et)
        ax.set_ylabel("MASE de prueba")
    fig.suptitle("Frontera de Pareto (rojo: no dominados)")
    fig.tight_layout()
    fig.savefig(K.O / "pareto_costes.png", dpi=130)
    plt.close(fig)


if __name__ == "__main__":
    main()

"""Incertidumbre predictiva de los tres mejores procedimientos (§12.2, Tabla A: PIT y cobertura).

Dos métodos sobre las predicciones guardadas, sin reentrenar:
  1. Ensamble profundo de las cinco semillas: media y desviación entre semillas; intervalo media +- z sd.
  2. Conformal adaptativo en línea (ACI, Gibbs y Candès, 2021) por hora del horizonte sobre el residuo absoluto
     del ensamble. En cada origen solo usa residuos de orígenes con al menos ``RETRASO`` días de antigüedad
     (todas sus 24 horas ya publicadas): no usa información posterior al origen. El primer año sirve de
     calentamiento y la evaluación es 2023-2025.
Métricas por nivel nominal y hora: cobertura empírica, prueba de Kupiec (proporción de fallos) y de Christoffersen
(independencia de los fallos), anchura media, puntaje de Winkler y pérdida pinball de los extremos. Cobertura
condicional por año y tipo de día. Los datos tienen dependencia temporal: la intercambiabilidad no se cumple y
la cobertura del conformal es aproximada (se declara como limitación).
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd
from scipy import stats

import e2c_comun as K

NIVELES = (0.80, 0.90, 0.95)
GAMMA, RETRASO, VENTANA = 0.005, 2, 365


def kupiec(fallos: np.ndarray, alfa: float) -> float:
    n, x = len(fallos), int(fallos.sum())
    if x in (0, n):
        return float(stats.chi2.sf(-2 * n * np.log(1 - alfa) if x == 0 else -2 * n * np.log(alfa), 1))
    pi = x / n
    lr = -2 * ((n - x) * np.log(1 - alfa) + x * np.log(alfa) - (n - x) * np.log(1 - pi) - x * np.log(pi))
    return float(stats.chi2.sf(lr, 1))


def christoffersen(f: np.ndarray) -> float:
    f = f.astype(int)
    n00 = int(((f[:-1] == 0) & (f[1:] == 0)).sum()); n01 = int(((f[:-1] == 0) & (f[1:] == 1)).sum())
    n10 = int(((f[:-1] == 1) & (f[1:] == 0)).sum()); n11 = int(((f[:-1] == 1) & (f[1:] == 1)).sum())
    if min(n00 + n01, n10 + n11) == 0:
        return float("nan")
    p01, p11, p = n01 / (n00 + n01), n11 / (n10 + n11), (n01 + n11) / (n00 + n01 + n10 + n11)
    ll = lambda a, b, q: (a * np.log(1 - q) if a else 0) + (b * np.log(q) if b else 0)   # noqa: E731
    lr = -2 * (ll(n00 + n10, n01 + n11, p) - ll(n00, n01, p01) - ll(n10, n11, p11)) if 0 < p < 1 else 0.0
    return float(stats.chi2.sf(lr, 1))


def aci(res_abs: np.ndarray, alfa: float) -> np.ndarray:
    """Cuantil adaptativo por hora; res_abs (N, H). Devuelve el radio del intervalo en cada origen (NaN en calentamiento)."""
    n, h = res_abs.shape
    radio = np.full((n, h), np.nan)
    a_t = np.full(h, alfa)
    for t in range(n):
        hist = res_abs[max(0, t - RETRASO - VENTANA + 1):max(0, t - RETRASO + 1)]
        if len(hist) < 60:
            continue
        for j in range(h):
            q = np.quantile(hist[:, j], min(1.0, max(0.0, 1 - a_t[j])))
            radio[t, j] = q
        # la actualización usa el fallo del origen t - RETRASO, ya observado completo en t
        s = t - RETRASO
        if s >= 0 and not np.isnan(radio[s]).any():
            err = (res_abs[s] > radio[s]).astype(float)
            a_t = a_t + GAMMA * (alfa - err)
    return radio


def evaluar(y, lo, hi, nivel) -> dict:
    a = 1 - nivel
    dentro = (y >= lo) & (y <= hi)
    w = hi - lo
    wink = w + (2 / a) * (lo - y) * (y < lo) + (2 / a) * (y - hi) * (y > hi)
    pin = lambda q, tau: np.maximum(tau * (y - q), (tau - 1) * (y - q))     # noqa: E731
    return dict(cobertura=float(dentro.mean()), anchura_media_kwh=float(w.mean()), winkler_kwh=float(wink.mean()),
                pinball_extremos_kwh=float((pin(lo, a / 2) + pin(hi, 1 - a / 2)).mean() / 2))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resultados-e2", default=None)
    ap.add_argument("--top", type=int, default=3)
    a = ap.parse_args()
    P, Y, nombres, _ = K.cargar_predicciones(a.resultados_e2)
    L = K.perdidas({k: v for k, v in P.items() if v.shape[0] >= 5}, Y).mean().sort_values()
    mejores = list(L.index[:a.top])
    cal = K.tipo_de_dia()
    ev = K.FECHAS >= pd.Timestamp("2023-01-01", tz="America/Bogota")
    filas, porh, cond = [], [], []
    for k in mejores:
        media, sd = P[k].mean(0), P[k].std(0, ddof=1)
        res = np.abs(Y - media)
        for nivel in NIVELES:
            z = stats.norm.ppf(0.5 + nivel / 2)
            for metodo, (lo, hi) in {"ensamble_semillas": (media - z * sd, media + z * sd),
                                     "conformal_ACI": (lambda r: (media - r, media + r))(aci(res, 1 - nivel))}.items():
                ok = ev[:, None] & np.isfinite(lo)
                yy, ll, hh = Y[ok], lo[ok], hi[ok]
                e = evaluar(yy, ll, hh, nivel)
                fallos_dia = ((Y < lo) | (Y > hi))[ev].mean(1) > (1 - nivel)
                filas.append(dict(clave=k, procedimiento=nombres[k], metodo=metodo, nivel=nivel, **e,
                                  p_Kupiec=kupiec(((yy < ll) | (yy > hh)), 1 - nivel), p_Christoffersen_horas_dia=christoffersen(fallos_dia)))
                for j in range(K.H):
                    m = ev & np.isfinite(lo[:, j])
                    f = (Y[m, j] < lo[m, j]) | (Y[m, j] > hi[m, j])
                    porh.append(dict(clave=k, metodo=metodo, nivel=nivel, hora=j + 1, cobertura=float(1 - f.mean()), p_Kupiec=kupiec(f, 1 - nivel),
                                     p_Christoffersen=christoffersen(f)))
                if nivel == 0.90:
                    df = pd.DataFrame(dict(dentro=((Y >= lo) & (Y <= hi))[ev].mean(1), anio=K.FECHAS[ev].year,
                                           tipo=np.where(cal.cal_es_festivo.to_numpy()[ev] == 1, "festivo", np.where(cal.cal_es_no_laboral.to_numpy()[ev] == 1, "fin de semana",
                                                                                                                   "laboral"))))
                    for col in ("anio", "tipo"):
                        for g, x in df.groupby(col):
                            cond.append(dict(clave=k, metodo=metodo, nivel=nivel, grupo=col, valor=str(g), cobertura=float(x.dentro.mean()), dias=len(x)))
    K.guardar("incertidumbre_resumen.csv", pd.DataFrame(filas))
    K.guardar("incertidumbre_por_hora.csv", pd.DataFrame(porh))
    K.guardar("incertidumbre_condicional.csv", pd.DataFrame(cond))
    print(pd.DataFrame(filas)[["procedimiento", "metodo", "nivel", "cobertura", "anchura_media_kwh", "p_Kupiec"]].to_string(index=False))


if __name__ == "__main__":
    main()

"""Robustez con tres niveles de severidad y fidelidad y estabilidad de las explicaciones (§4.6).

Solo inferencia con pesos congelados (CPU, determinista). Los cuatro modelos base se restauran desde la instantánea
del repositorio; las arquitecturas ampliadas necesitan la carpeta de artefactos consolidados (variable de entorno
DEMANDA_ARTEFACTOS o la carpeta hermana Consolidado-Entrenamientos-20261115, como en inferencia_ampliada.py).

Perturbaciones de la serie de entrada en todo el periodo que alimenta la prueba (semilla fija, mismas horas para
todos los modelos):
  ruido_demanda   demanda multiplicada por (1 + s e), e ~ N(0, 1) por hora; s = 1 %, 3 %, 5 %.
  atipicos        cada hora de demanda se multiplica por 1,2 con probabilidad k / 168; k = 1, 3, 6 por semana.
  faltantes       cada hora de las entradas exógenas queda ausente con probabilidad 10 %, 30 %, 50 % (se imputa con
                  la mediana de ajuste y se activa el indicador). No aplica a los modelos base (solo demanda).
Índice de robustez = área bajo la curva MASE(s) / MASE(0) entre las severidades 0 y 3 dividida por 3 (1 = sin
degradación; mayor es peor).

Fidelidad (prueba de borrado): para cada modelo ampliado se perturban juntos los k grupos más importantes según la
importancia ya publicada (results/diagnosticos_ampliados/importancia_resumen.csv) y k grupos al azar (5 sorteos),
k = 1, 2, 3, con los mismos donantes circulares; una explicación fiel produce más deterioro con los grupos
importantes. Estabilidad: correlación de Spearman entre las importancias de cada par de semillas.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
from types import SimpleNamespace

import numpy as np
import pandas as pd
from scipy import integrate, stats

import e2c_comun as K

SEVERIDADES = {"ruido_demanda": [0.01, 0.03, 0.05], "atipicos": [1, 3, 6], "faltantes": [0.10, 0.30, 0.50]}
SEMILLA = 20261118


def perturbar_serie(x: np.ndarray, tipo: str, s: float, exogenas: list[int] | None, g: np.random.Generator) -> tuple[np.ndarray, np.ndarray | None]:
    x = x.copy()
    faltan = None
    if tipo == "ruido_demanda":
        x[:, 0] = x[:, 0] * (1 + s * g.standard_normal(len(x)))
    elif tipo == "atipicos":
        m = g.random(len(x)) < s / 168
        x[m, 0] = x[m, 0] * 1.2
    elif tipo == "faltantes":
        faltan = g.random(len(x)) < s
        x[np.ix_(faltan, exogenas)] = np.nan
    return x, faltan


def indice(curva: list[float]) -> float:
    return float(integrate.trapezoid(np.asarray(curva) / curva[0], dx=1.0) / (len(curva) - 1))


def base(filas: list, Y: np.ndarray) -> None:
    import torch
    torch.set_num_threads(1)
    import importancia_variables as IV
    sha = json.loads((K.R / "results/jbook/modelos_actualizados.json").read_text())["commit"]
    snap = K.R / "results/repositorio" / sha
    import sys
    sys.path.insert(0, str(snap / "src"))
    from demanda import modelos_base as M
    from demanda.reentrenamiento_v3 import Secuencial as CNN
    from demanda.variantes_v4 import Secuencial as LSTM
    reg = json.loads((snap / "results/consolidado/modelos.json").read_text(encoding="utf-8"))
    huellas = {r["archivo"]: r["sha256"] for r in json.loads((snap / "IMPORTACION.json").read_text(encoding="utf-8"))["archivos"]}
    primer = reg["mlp"]["artefactos"][0]
    cols = json.loads((snap / primer["escaladores"]).read_text(encoding="utf-8"))["columnas_cal"]
    panel0 = pd.read_parquet(K.R / "data/processed/panel_horario.parquet", columns=["x_demanda_real_kwh", "y_demanda_real_kwh", *cols])
    escenarios = [("original", 0, 0.0)] + [(t, i + 1, s) for t in ("ruido_demanda", "atipicos") for i, s in enumerate(SEVERIDADES[t])]
    with torch.inference_mode():
        for tipo, nivel, s in escenarios:
            panel = panel0.copy()
            if tipo != "original":
                x, _ = perturbar_serie(panel[["x_demanda_real_kwh"]].to_numpy(dtype=float), tipo, s, None, np.random.default_rng(SEMILLA + nivel + 10 * len(tipo)))
                panel["x_demanda_real_kwh"] = x[:, 0]
            for nombre in K.FAMILIA_BASE:
                for a in sorted(reg[nombre]["artefactos"], key=lambda x: x["semilla"]):
                    esc = json.loads((snap / a["escaladores"]).read_text(encoding="utf-8"))
                    xp, cf, nv, y, _ = IV.restaurar_entradas(panel, K.FECHAS, esc)
                    shapes = SimpleNamespace(x=xp[:, :, :1], cal_p=xp[:, :, 1:], cal_f=cf)
                    params = reg[nombre]["configuracion"]["params"]
                    red = LSTM(nombre, params, shapes) if nombre == "lstm" else CNN(nombre, params, shapes) if nombre == "cnn1d" else M.construir_red(nombre, params, shapes)
                    ruta = snap / a["pesos"] if (snap / a["pesos"]).exists() else K.R / a["pesos"]
                    if IV.sha256(ruta) != huellas[a["pesos"]]:
                        raise RuntimeError(f"El checkpoint {ruta} no coincide con IMPORTACION.json")
                    red.load_state_dict(torch.load(ruta, map_location="cpu", weights_only=True)["state_dict"], strict=True)
                    red.eval()
                    pred = IV.predecir(red, xp, cf, nv, torch)
                    filas.append(dict(clave=nombre, semilla=a["semilla"], tipo=tipo, nivel=nivel, severidad=s, MASE=float(np.abs(pred - Y).mean() / K.Q)))
            print("base", tipo, nivel, "listo", flush=True)


def ampliados(filas: list, fid: list, Y: np.ndarray, con_fidelidad: bool) -> None:
    import torch
    torch.set_num_threads(max(1, (os.cpu_count() or 2) - 1))
    import inferencia_ampliada as IA
    from diagnosticos_ampliados import GRUPOS, perturbada
    from importancia_variables import indices_donantes
    E0 = IA.Entradas()
    exo = list(range(1, len(E0.hist)))
    reg = IA.registro()
    escenarios = [("original", 0, 0.0)] + [(t, i + 1, s) for t in SEVERIDADES for i, s in enumerate(SEVERIDADES[t])]
    imp = pd.read_csv(K.R / "results/diagnosticos_ampliados/importancia_resumen.csv") if con_fidelidad else None
    ix = np.arange(K.N)
    for tipo, nivel, s in escenarios:
        E = copy.copy(E0)
        E.cache = {}
        if tipo != "original":
            raw, faltan = perturbar_serie(E0.raw, tipo, s, exo, np.random.default_rng(SEMILLA + nivel + 10 * len(tipo)))
            E.raw = raw
            if faltan is not None:
                E.masks = E0.masks.copy()
                E.masks[faltan] = 1.0
        for m in reg:
            red, data, repo = IA.cargar(m, E)
            pred = IA.predecir(red, data, ix, repo, batch=64)
            k = m["experimento"] + "__" + m["variante"]
            filas.append(dict(clave=k, semilla=m["semilla"], tipo=tipo, nivel=nivel, severidad=s, MASE=float(np.abs(pred - Y).mean() / K.Q)))
            if con_fidelidad and tipo == "original":
                orden = imp[imp.clave == k].sort_values("cambio_pct", ascending=False).grupo.tolist()
                donantes = indices_donantes(K.FECHAS, 0)
                base_mase = filas[-1]["MASE"]
                g = np.random.default_rng(SEMILLA + 99)
                for kk in (1, 2, 3):
                    for etiqueta, grupos in [("importantes", orden[:kk])] + [(f"azar_{r}", [str(x) for x in g.choice(GRUPOS, kk, replace=False)]) for r in range(5)]:
                        d = data
                        for gr in grupos:
                            d = perturbada(d, donantes, gr, repo, E)
                        pr = IA.predecir(red, d, ix, repo, batch=64)
                        fid.append(dict(clave=k, semilla=m["semilla"], k=kk, conjunto=etiqueta, grupos="+".join(grupos), aumento_MASE=float(np.abs(pr - Y).mean() / K.Q - base_mase)))
        print("ampliados", tipo, nivel, "listo", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--solo-base", action="store_true", help="no requiere la carpeta de artefactos consolidados")
    ap.add_argument("--sin-fidelidad", action="store_true")
    ap.add_argument("--resultados-e2", default=None, help="añade robustez_nuevos_por_semilla.csv del paquete Completar_E2")
    a = ap.parse_args()
    _, Y, nombres, _ = K.cargar_predicciones(a.resultados_e2)
    filas, fid = [], []
    base(filas, Y)
    if not a.solo_base:
        ampliados(filas, fid, Y, not a.sin_fidelidad)
    t = pd.DataFrame(filas)
    if a.resultados_e2 and (K.Path(a.resultados_e2) / "robustez_nuevos_por_semilla.csv").exists():
        t = pd.concat([t, pd.read_csv(K.Path(a.resultados_e2) / "robustez_nuevos_por_semilla.csv")], ignore_index=True)
    K.guardar("robustez_por_semilla.csv", t)
    r = t.groupby(["clave", "tipo", "nivel"]).MASE.mean().reset_index()
    out = []
    for clave, g in r.groupby("clave"):
        m0 = float(g.loc[g.tipo == "original", "MASE"].iloc[0])
        idx = {}
        for tipo in SEVERIDADES:
            c = g[g.tipo == tipo].sort_values("nivel").MASE.tolist()
            if len(c) == 3:
                idx[tipo] = indice([m0] + c)
        out.append(dict(clave=clave, procedimiento=nombres.get(clave, clave), MASE_original=m0, **{f"indice_{k}": v for k, v in idx.items()},
                        indice_robustez=float(np.mean(list(idx.values())))))
    K.guardar("robustez_indice.csv", pd.DataFrame(out))
    if fid:
        f = pd.DataFrame(fid)
        K.guardar("fidelidad_borrado.csv", f)
        f["tipo"] = np.where(f.conjunto == "importantes", "importantes", "azar")
        resumen = f.groupby(["clave", "k", "tipo"]).aumento_MASE.mean().unstack("tipo").reset_index()
        resumen["fidelidad"] = resumen.importantes - resumen.azar
        K.guardar("fidelidad_resumen.csv", resumen)
    imp_s = K.R / "results/diagnosticos_ampliados/importancia_semillas.csv"
    if imp_s.exists():
        s = pd.read_csv(imp_s).groupby(["clave", "semilla", "grupo"]).cambio_pct.mean().reset_index()
        est = []
        for clave, g in s.groupby("clave"):
            piv = g.pivot(index="grupo", columns="semilla", values="cambio_pct")
            rho = [stats.spearmanr(piv[a_], piv[b_]).statistic for i, a_ in enumerate(piv.columns) for b_ in piv.columns[i + 1:]]
            est.append(dict(clave=clave, procedimiento=nombres.get(clave, clave), pares_semillas=len(rho), spearman_medio=float(np.mean(rho)), spearman_min=float(np.min(rho))))
        K.guardar("estabilidad_importancia_semillas.csv", pd.DataFrame(est))
    print(pd.DataFrame(out).to_string(index=False))


if __name__ == "__main__":
    main()

"""Tabla B (ausencia de sobreajuste) y validación adversarial (§7.3, §10.1).

1. Brecha ajuste-parada con margen (no inferioridad): g = (pérdida de parada - pérdida de ajuste) / pérdida de ajuste
   en la época restaurada de cada semilla; H0: mediana(g) >= delta_g = 0,10 frente a H1: < 0,10. Wilcoxon unilateral
   (con 5 semillas el p mínimo es 1/32 = 0,031) y t unilateral. La pérdida de ajuste se registra con dropout activo:
   la brecha está sesgada hacia abajo y se declara.
2. Validación frente a prueba: diferencia MASE_validación - MASE_prueba con IC 95 % por bootstrap circular de días
   de prueba (bloques de 14). La validación de selección no tiene remuestreo disponible y se trata como fija.
3. Estabilidad temporal (Giacomini-Rossi, 2010): estadístico de fluctuación del diferencial de pérdida frente al
   ingenuo semanal y frente al mejor procedimiento, ventana móvil m = 0,3 T; valores críticos simulados con
   movimiento browniano (20.000 trayectorias). La versión original contrasta igual precisión local en todo momento;
   la versión centrada (puente browniano) contrasta que el desempeño relativo no cambie en el tiempo.
4. Sensibilidad a la semilla: coeficiente de variación del MASE entre semillas y Kruskal-Wallis de las pérdidas
   diarias por semilla (descriptivo: los días son comunes).
5. Validación adversarial: un clasificador logístico distingue orígenes de desarrollo (2018-2021) de orígenes de
   prueba con rasgos de entrada disponibles al origen (perfil de demanda normalizado por el nivel, medias de 24 h de
   las variables históricas, calendario); AUC con validación cruzada por bloques de 28 días y p por permutación de
   bloques (200 permutaciones).
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

import e2c_comun as K

DELTA_G = 0.10


def giacomini_rossi(d: np.ndarray, mu: float = 0.3, rezagos: int = 13, sims: int = 20000, semilla: int = 11) -> dict:
    T = len(d)
    m = int(mu * T)
    u = d - d.mean()
    lrv = u @ u / T + 2 * sum((1 - k / (rezagos + 1)) * (u[k:] @ u[:-k]) / T for k in range(1, rezagos + 1))
    c = np.cumsum(np.r_[0.0, d])
    medias = (c[m:] - c[:-m]) / m
    est = np.abs(medias / np.sqrt(lrv / m))
    g = np.random.default_rng(semilla)
    pasos = 400
    W = np.cumsum(g.standard_normal((sims, pasos)) / np.sqrt(pasos), axis=1)
    W = np.concatenate([np.zeros((sims, 1)), W], axis=1)
    k = int(mu * pasos)
    sup = (np.abs(W[:, k:] - W[:, :-k]) / np.sqrt(mu)).max(1)
    cv = float(np.quantile(sup, 0.95))
    # variante centrada: estabilidad del desempeño relativo (H0: la media local es igual a la global en todo momento)
    est_c = np.abs((medias - d.mean()) / np.sqrt(lrv / m))
    t_grid = np.linspace(0, 1, pasos + 1)
    puente = W - t_grid[None, :] * W[:, -1:]
    sup_c = (np.abs(puente[:, k:] - puente[:, :-k]) / np.sqrt(mu)).max(1)
    return dict(estadistico_max=float(est.max()), valor_critico_5pct=cv, p_simulado=float((sup >= est.max()).mean()), ventana_dias=m,
                fecha_maximo=str(K.FECHAS[m - 1 + int(est.argmax())].date()), estadistico_centrado_max=float(est_c.max()),
                valor_critico_centrado_5pct=float(np.quantile(sup_c, 0.95)), p_centrado_simulado=float((sup_c >= est_c.max()).mean()))


def adversarial(semilla: int = 5) -> dict:
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    from sklearn.preprocessing import StandardScaler
    panel = pd.read_parquet(K.R / "data/processed/panel_horario.parquet")
    contrato = json.loads((K.R / "config/diseno_entrenamiento_texto.json").read_text(encoding="utf-8"))
    hist = contrato["numericas"]["historicas"]
    cal = contrato["numericas"]["calendario"]
    dev = pd.date_range("2018-01-01", "2021-12-31", freq="D", tz="America/Bogota")
    fechas = dev.append(K.FECHAS)
    pos = panel.index.get_indexer(fechas)
    X = panel[hist].to_numpy(dtype=float)
    dem = X[pos[:, None] + np.arange(-168, 0), 0]
    perfil = dem / np.nanmean(dem, axis=1, keepdims=True)
    otros = np.nanmean(X[pos[:, None] + np.arange(-24, 0)][:, :, 1:], axis=1)
    calf = panel[cal].to_numpy(dtype=float)[pos + 12]
    F = np.concatenate([perfil, otros, calf], axis=1)
    F = np.where(np.isnan(F), np.nanmedian(F[:len(dev)], axis=0), F)
    yb = np.r_[np.zeros(len(dev)), np.ones(len(K.FECHAS))]
    bloque = np.arange(len(fechas)) // 28

    def auc(etiquetas):
        pred = np.zeros(len(etiquetas))
        pliegue = bloque % 5
        for f in range(5):
            tr, te = pliegue != f, pliegue == f
            sc = StandardScaler().fit(F[tr])
            m = LogisticRegression(C=0.1, max_iter=2000).fit(sc.transform(F[tr]), etiquetas[tr])
            pred[te] = m.predict_proba(sc.transform(F[te]))[:, 1]
        return roc_auc_score(etiquetas, pred)

    obs = auc(yb)
    g = np.random.default_rng(semilla)
    ub = np.unique(bloque)
    lab_b = np.array([yb[bloque == b].mean() > 0.5 for b in ub])
    perm = []
    for _ in range(200):
        lb = g.permutation(lab_b)
        perm.append(auc(lb[bloque].astype(float)))
    perm = np.array(perm)
    return dict(AUC=float(obs), AUC_permutacion_media=float(perm.mean()), p_permutacion=float((1 + (perm >= obs).sum()) / (1 + len(perm))),
                rasgos=int(F.shape[1]), origenes_desarrollo=len(dev), origenes_prueba=len(K.FECHAS),
                nota="AUC alto indica cambio de distribución entre desarrollo y prueba (no fuga): el nivel se normaliza en el perfil, pero precios, hidrología y calendario cambian")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resultados-e2", default=None)
    ap.add_argument("--sin-adversarial", action="store_true")
    a = ap.parse_args()
    P, Y, nombres, _ = K.cargar_predicciones(a.resultados_e2)
    L = K.perdidas(P, Y)
    E = K.R / "results/evaluacion_e2"
    curvas = pd.read_csv(E / "curvas_aprendizaje.csv")

    filas = []
    for k, g in curvas.groupby("clave"):
        gaps = []
        for s, gs in g.groupby("semilla"):
            r = gs.loc[gs.val_loss.idxmin()]
            gaps.append((r.val_loss - r.train_loss) / r.train_loss)
        gaps = np.array(gaps)
        w = stats.wilcoxon(gaps - DELTA_G, alternative="less") if len(gaps) >= 5 else None
        t = stats.ttest_1samp(gaps, DELTA_G, alternative="less")
        filas.append(dict(clave=k, procedimiento=nombres.get(k, k), semillas=len(gaps), brecha_mediana=float(np.median(gaps)), brecha_max=float(gaps.max()),
                          delta_g=DELTA_G, p_wilcoxon_unilateral=float(w.pvalue) if w else np.nan, p_t_unilateral=float(t.pvalue)))
    tb = pd.DataFrame(filas)
    tb["p_wilcoxon_Holm"] = multipletests(tb.p_wilcoxon_unilateral.fillna(1), method="holm")[1]
    tb["sin_sobreajuste_inaceptable"] = tb.p_wilcoxon_Holm < 0.05
    K.guardar("tablaB_brecha_ajuste_parada.csv", tb)

    gen = pd.read_csv(E / "generalizacion_integrada.csv").set_index("clave")
    idx = K.indices_bloques(K.N, K.BLOQUE, K.B, K.SEMILLA + 3)
    filas = []
    for k in [c for c in L.columns if c in gen.index]:
        bt = L[k].to_numpy()[idx].mean(1)
        v = float(gen.loc[k, "Validación externa"])
        dif = v - bt
        filas.append(dict(clave=k, procedimiento=nombres[k], MASE_validacion=v, MASE_prueba=float(L[k].mean()), diferencia=float(v - L[k].mean()),
                          ic95_inf=float(np.percentile(dif, 2.5)), ic95_sup=float(np.percentile(dif, 97.5)), p_bootstrap=float(2 * min((dif <= 0).mean(), (dif >= 0).mean()))))
    tv = pd.DataFrame(filas)
    tv["p_Holm"] = multipletests(tv.p_bootstrap, method="holm")[1]
    K.guardar("tablaB_validacion_frente_a_prueba.csv", tv)

    mejor = L.drop(columns=[c for c in L.columns if c.startswith("ingenuo")]).mean().idxmin()
    filas = []
    for k in L.columns:
        if k.startswith("ingenuo"):
            continue
        for ref in ("ingenuo_168h", mejor):
            if ref == k:
                continue
            gr = giacomini_rossi(L[k].to_numpy() - L[ref].to_numpy())
            filas.append(dict(clave=k, procedimiento=nombres[k], referencia=nombres[ref], **gr))
    tg = pd.DataFrame(filas)
    tg["igual_precision_local_al_5pct"] = tg.estadistico_max < tg.valor_critico_5pct
    tg["desempeno_relativo_estable_al_5pct"] = tg.estadistico_centrado_max < tg.valor_critico_centrado_5pct
    K.guardar("tablaB_giacomini_rossi.csv", tg)

    filas = []
    for k, v in P.items():
        if v.shape[0] < 2:
            continue
        sem = np.abs(v - Y[None]).mean(axis=(1, 2)) / K.Q
        diarias = np.abs(v - Y[None]).mean(axis=2) / K.Q
        kw = stats.kruskal(*diarias)
        filas.append(dict(clave=k, procedimiento=nombres[k], semillas=len(sem), MASE_medio=float(sem.mean()), CV_entre_semillas=float(sem.std(ddof=1) / sem.mean()),
                          p_Kruskal_Wallis_descriptivo=float(kw.pvalue)))
    K.guardar("tablaB_sensibilidad_semilla.csv", pd.DataFrame(filas))
    if not a.sin_adversarial:
        K.guardar_json("validacion_adversarial.json", adversarial())
    print(tb[["procedimiento", "brecha_mediana", "p_wilcoxon_Holm"]].to_string(index=False))
    print(tv[["procedimiento", "diferencia", "ic95_inf", "ic95_sup", "p_Holm"]].to_string(index=False))


if __name__ == "__main__":
    main()

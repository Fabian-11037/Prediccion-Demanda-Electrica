"""Utilidades comunes de los análisis de cierre del Entregable 2 (se ejecutan desde la raíz del repositorio).

Solo leen predicciones y artefactos guardados: no entrenan ni ajustan nada con la prueba.
``cargar_predicciones`` reúne en arreglos (semillas, 1461 orígenes, 24 horas) los 13 procedimientos del
benchmark consolidado, los cuatro modelos base, las dos referencias ingenuas y, si se indica la carpeta
``resultados_e2`` del paquete Completar_E2, los procedimientos nuevos (N-BEATS, TimesNet, LightGBM, MSTL y
los ganadores de la búsqueda de §14).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

R = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p / "data/processed/panel_horario.parquet").is_file())
sys.path.insert(0, str(R / "scripts"))
O = R / "results" / "e2_cierre"
O.mkdir(parents=True, exist_ok=True)
Q = 215617.90361589016
FECHAS = pd.date_range("2022-01-01", "2025-12-31", freq="D", tz="America/Bogota")
N, H = len(FECHAS), 24
BLOQUE, B, SEMILLA = 14, 10000, 20261118
FAMILIA_BASE = {"mlp": "MLP", "lstm": "LSTM", "cnn1d": "CNN1D", "arx_lineal": "ARX"}


def guardar(nombre: str, df: pd.DataFrame) -> Path:
    p = O / nombre
    df.to_csv(p, index=False, encoding="utf-8")
    return p


def guardar_json(nombre: str, obj) -> Path:
    p = O / nombre
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    return p


def _nuevos(base: Path, Y: np.ndarray) -> dict:
    """Predicciones de prueba del paquete Completar_E2 alineadas con los 1461 orígenes."""
    out = {}
    esperados = FECHAS.strftime("%Y-%m-%d").to_numpy()

    def leer(ruta):
        with np.load(ruta, allow_pickle=False) as z:
            o = z["origen"].astype(str)
            if len(o) != N or not np.array_equal(o, esperados):
                raise ValueError(f"{ruta}: los orígenes no son los 1461 días de 2022-2025")
            if not np.allclose(z["y_kwh"], Y, rtol=1e-6, atol=1.0):
                raise ValueError(f"{ruta}: las etiquetas no coinciden con el panel")
            return z["yhat_kwh"].astype("float64")

    grupos = {}
    for d in sorted(base.glob("nuevo_*")) + sorted(base.glob("busqueda14_*")):
        for var in sorted((d / "final").glob("*")) if (d / "final").is_dir() else []:
            pr = sorted(var.glob("semilla_*/pred_prueba.npz"))
            if pr:
                grupos[f"{d.name}__{var.name.replace('_', '+')}"] = pr
    lg = sorted((base / "clasico_lightgbm" / "final").glob("semilla_*/pred_prueba.npz"))
    if lg:
        grupos["clasico_lightgbm__N"] = lg
    for clave, rutas in grupos.items():
        try:
            out[clave] = np.stack([leer(r) for r in rutas])
        except ValueError as e:
            print("Se omite:", e)
    for p in sorted((base / "clasico_mstl").glob("*/prueba_W*.npz")):
        try:
            out[f"clasico_mstl_{p.parent.name}__N"] = leer(p)[None]
        except ValueError as e:
            print("Se omite:", e)
    return out


NOMBRES_NUEVOS = {"nuevo_nbeats": "N-BEATS", "nuevo_timesnet": "TimesNet", "busqueda14_mlp": "MLP §14", "busqueda14_lstm": "LSTM §14", "busqueda14_cnn1d": "CNN1D §14",
                  "busqueda14_tcn": "TCN §14", "busqueda14_tgforecaster": "TGForecaster §14", "busqueda14_fusion": "Fusión tardía §14",
                  "clasico_lightgbm": "LightGBM", "clasico_mstl_ets": "MSTL-ETS", "clasico_mstl_arima": "MSTL-ARIMA"}


def cargar_predicciones(resultados_e2: str | None = None) -> tuple[dict, np.ndarray, dict, dict]:
    """Devuelve P (clave -> (S, N, H) kWh), Y (N, H), nombres y fuentes."""
    from seleccion_patchtst import CONSERVAR, NOMBRE, RETIRAR
    C = R / "results/evaluacion_e2/entradas/consolidado"
    df = pd.read_parquet(C / "predicciones_finales.parquet")
    P, nombres, fuentes, Y = {}, {}, {}, None
    for (e, v), g in df.groupby(["experimento", "variante"], sort=False):
        k = e + "__" + v
        if k == RETIRAR:
            continue
        arr = []
        for s, gs in g.groupby("semilla", sort=True):
            gs = gs.sort_values(["origen", "horizonte"])
            arr.append(gs.predicho_kwh.to_numpy().reshape(N, H))
            y = gs.observado_kwh.to_numpy().reshape(N, H)
            Y = y if Y is None else Y
            assert np.array_equal(y, Y)
        P[k] = np.stack(arr)
    res = pd.read_csv(C / "resumen_principal.csv")
    for f in res.itertuples():
        k = f.experimento + "__" + f.variante
        if k in P:
            nombres[k], fuentes[k] = f.modelo + " · " + f.variante, "numerico_ampliado"
    nombres[CONSERVAR] = NOMBRE
    snap = R / "results/repositorio/d1ae9a4e09dd1dead4af1329f16aa3e8d0f2c3d3"
    reg = json.loads((snap / "results/consolidado/modelos.json").read_text())
    for k, nom in FAMILIA_BASE.items():
        pp = []
        for a in sorted(reg[k]["artefactos"], key=lambda a: a["semilla"]):
            with np.load(snap / a["predicciones"], allow_pickle=False) as z:
                assert np.allclose(z["y"], Y, atol=1e-6)
                pp.append(z["yhat"])
        P[k], nombres[k], fuentes[k] = np.stack(pp), nom, "demanda_calendario"
    panel = pd.read_parquet(R / "data/processed/panel_horario.parquet", columns=["y_demanda_real_kwh"])
    pos = panel.index.get_indexer(FECHAS)
    raw = panel.y_demanda_real_kwh.to_numpy()
    horas = np.arange(24)
    lag = 24 * np.maximum(1, np.ceil((horas + 2) / 24).astype(int))
    for k, pr in {"ingenuo_168h": raw[pos[:, None] + horas - 168], "ingenuo_24h": raw[pos[:, None] + horas - lag]}.items():
        P[k], nombres[k], fuentes[k] = pr[None], k.replace("_", " "), "referencia"
    if resultados_e2:
        for k, v in _nuevos(Path(resultados_e2), Y).items():
            P[k] = v
            base = k.split("__")[0]
            nombres[k] = NOMBRES_NUEVOS.get(base, base) + " · " + k.split("__")[1]
            fuentes[k] = "clasico" if base.startswith("clasico") else "demanda_calendario" if base in ("busqueda14_mlp", "busqueda14_lstm", "busqueda14_cnn1d") else "numerico_ampliado"
    return P, Y, nombres, fuentes


def perdidas(P: dict, Y: np.ndarray) -> pd.DataFrame:
    """Pérdida diaria (MASE del origen) promediada entre semillas, como en el benchmark del libro."""
    return pd.DataFrame({k: np.abs(v - Y[None]).mean(axis=(0, 2)) / Q for k, v in P.items()}, index=FECHAS)


def indices_bloques(n: int, largo: int, b: int, semilla: int) -> np.ndarray:
    g = np.random.default_rng(semilla)
    inicios = g.integers(0, n, size=(b, int(np.ceil(n / largo))))
    return ((inicios[:, :, None] + np.arange(largo)) % n).reshape(b, -1)[:, :n]


def tipo_de_dia() -> pd.DataFrame:
    """Categorías de calendario de cada origen, con las columnas de calendario del panel."""
    panel = pd.read_parquet(R / "data/processed/panel_horario.parquet")
    cal = [c for c in panel.columns if c.startswith("cal_")]
    d = panel.loc[panel.index.normalize().isin(FECHAS) & (panel.index.hour == 12), cal].copy()
    d.index = d.index.normalize()
    return d.reindex(FECHAS)

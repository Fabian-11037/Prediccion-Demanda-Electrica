"""Techo de desempeño, análisis de errores y limitación cuantificada del paper guía (§5, §12.1, §12.3).

Techo (§12.1): (a) entropía de permutación normalizada de la demanda de entrenamiento (2000-2021; órdenes 3 a 6,
retardos 1 y 24 h) como predictibilidad intrínseca; (b) cota empírica por conjunto de modelos diversos: el mejor
MASE alcanzable con una combinación convexa de los pronósticos (pesos ajustados en 2022 y evaluados en 2023-2025, para
no estimar el techo con los mismos días). gamma = (s_mejor - s_techo) / (s_base - s_techo), con s_base el ingenuo
semanal; con un error (menor es mejor) gamma es la fracción del margen aún sin cubrir.

Errores (§12.3): categorías excluyentes fijadas a priori (festivo; puente o fin de semana largo; víspera o día
posterior a festivo; temporada navideña o fin de año; Semana Santa; domingo; sábado; laboral). Para cada modelo
principal se toma el 10 % de días con mayor pérdida (146 casos) y se reporta la frecuencia por categoría con IC de
Wilson y su razón frente a la frecuencia base. Errores compartidos (Jaccard de los peores días), correlación de las
pérdidas diarias y ganancia de un ensamble simple.

Limitación del paper guía (§5): PatchTST es independiente por canal y no recibe covariables futuras conocidas; la
limitación declarada es la pérdida de precisión en días no laborables especiales (festivos, puentes, Semana Santa,
temporada navideña). Métrica: razón entre el MASE de esos días y el de los días laborales, con IC 95 % por bootstrap
circular de bloques de 14 días; piloto sobre al menos tres modelos del Top 10.
"""
from __future__ import annotations

import argparse
import math


import numpy as np
import pandas as pd
from scipy import optimize

import e2c_comun as K

PRINCIPALES = ["adj_modelo6_20261112_1035__N+O", "adj_modelo6_20261112_1035__N", "adj_fusion_tardia_20261113_1728__N+O", "adj_modelo5_20261114_1327__N",
               "mlp", "adj_modelo4_20261114_1224__N", "repo_nhits_numerico_r1__N", "adj_modelo3_20261115_0419__N"]
PILOTO_LIMITACION = ["adj_modelo6_20261112_1035__N", "adj_modelo5_20261114_1327__N", "adj_modelo4_20261114_1224__N", "repo_nhits_numerico_r1__N",
                     "adj_modelo3_20261115_0419__N", "adj_modelo6_20261112_1035__N+O", "nuevo_nbeats__N", "nuevo_timesnet__N"]


def entropia_permutacion(x: np.ndarray, orden: int, retardo: int) -> float:
    n = len(x) - (orden - 1) * retardo
    emb = np.stack([x[i * retardo:i * retardo + n] for i in range(orden)], axis=1)
    pat = np.argsort(emb, axis=1, kind="stable")
    codigos = (pat * (orden ** np.arange(orden))).sum(1)
    _, c = np.unique(codigos, return_counts=True)
    p = c / c.sum()
    return float(-(p * np.log(p)).sum() / math.log(math.factorial(orden)))


def categorias(cal: pd.DataFrame) -> pd.Series:
    c = pd.Series("laboral", index=cal.index)
    reglas = [("sábado", cal.cal_es_sabado == 1), ("domingo", cal.cal_es_domingo == 1), ("Semana Santa", cal.cal_es_semana_santa == 1),
              ("temporada navideña o fin de año", (cal.cal_es_temporada_navidena == 1) | (cal.cal_es_fin_de_anio == 1)),
              ("víspera o día posterior a festivo", (cal.cal_es_vispera_festivo == 1) | (cal.cal_es_dia_post_festivo == 1)),
              ("puente o fin de semana largo", cal.cal_es_fin_semana_largo == 1), ("festivo", cal.cal_es_festivo == 1)]
    for nombre, m in reglas:          # la última regla tiene prioridad: el orden fija la exclusión mutua
        c[m.to_numpy()] = nombre
    return c


def wilson(x: int, n: int) -> tuple[float, float]:
    if n == 0:
        return (np.nan, np.nan)
    z, p = 1.959964, x / n
    d = 1 + z ** 2 / n
    c = (p + z ** 2 / (2 * n)) / d
    r = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n * n)) / d
    return (c - r, c + r)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resultados-e2", default=None)
    a = ap.parse_args()
    P, Y, nombres, fuentes = K.cargar_predicciones(a.resultados_e2)
    L = K.perdidas(P, Y)
    cal = K.tipo_de_dia()
    cat = categorias(cal)

    # ---------------------------------------------------------------- techo
    panel = pd.read_parquet(K.R / "data/processed/panel_horario.parquet", columns=["y_demanda_real_kwh"])
    y = panel.y_demanda_real_kwh.loc[:"2021-12-31"].interpolate().to_numpy()
    ent = [dict(orden=o, retardo=r, entropia_normalizada=entropia_permutacion(y, o, r)) for o in (3, 4, 5, 6) for r in (1, 24)]
    modelos = [k for k in P if not k.startswith("ingenuo")]
    medias = {k: P[k].mean(0) for k in modelos}
    ajuste = K.FECHAS.year == 2022
    ev = ~ajuste
    F = np.stack([medias[k] for k in modelos], -1)                       # (N, H, M)
    def mae(w, m):
        return float(np.abs((F[m] * w).sum(-1) - Y[m]).mean())
    M = len(modelos)
    res = optimize.minimize(lambda z: mae(np.exp(z) / np.exp(z).sum(), ajuste), np.zeros(M), method="Powell", options=dict(maxiter=4000, xtol=1e-4))
    w = np.exp(res.x) / np.exp(res.x).sum()
    s_techo = mae(w, ev) / K.Q
    s_ens = float(np.abs(F[ev].mean(-1) - Y[ev]).mean() / K.Q)
    s = {k: float(L.loc[ev, k].mean()) for k in L.columns}
    mejor = min((k for k in modelos), key=lambda k: s[k])
    s_base = s["ingenuo_168h"]
    gamma = (s[mejor] - s_techo) / (s_base - s_techo)
    techo = dict(periodo_evaluacion="2023-2025", pesos_ajustados_en="2022", MASE_techo_combinacion=s_techo, MASE_promedio_simple=s_ens, mejor=nombres[mejor],
                 MASE_mejor=s[mejor], MASE_ingenuo_semanal=s_base, gamma=float(gamma), pesos={nombres[k]: float(v) for k, v in zip(modelos, w) if v > 0.01},
                 entropia_permutacion=ent,
                 nota="La combinación convexa es una cota empírica alcanzable con los modelos disponibles, no el error de Bayes; un gamma pequeño indica poco margen frente a esa cota.")
    K.guardar_json("techo_desempeno.json", techo)

    # ---------------------------------------------------------------- taxonomía y errores compartidos
    base_freq = cat.value_counts(normalize=True)
    filas, peores = [], {}
    for k in [p for p in PRINCIPALES if p in L.columns]:
        u = L[k].quantile(0.90)
        idx = L.index[L[k] >= u]
        peores[k] = set(idx)
        vc = cat.loc[idx].value_counts()
        for c in base_freq.index:
            x = int(vc.get(c, 0))
            lo, hi = wilson(x, len(idx))
            filas.append(dict(clave=k, procedimiento=nombres[k], categoria=c, casos=x, total=len(idx), frecuencia=x / len(idx), ic95_inf=lo, ic95_sup=hi,
                              frecuencia_base=float(base_freq[c]), razon_frente_a_base=(x / len(idx)) / float(base_freq[c])))
    K.guardar("taxonomia_errores.csv", pd.DataFrame(filas))
    ks = list(peores)
    jac = pd.DataFrame([[len(peores[i] & peores[j]) / len(peores[i] | peores[j]) for j in ks] for i in ks], index=[nombres[k] for k in ks], columns=[nombres[k] for k in ks])
    jac.to_csv(K.O / "errores_compartidos_jaccard.csv")
    corr = L[ks].corr(method="spearman")
    corr.index = corr.columns = [nombres[k] for k in ks]
    corr.to_csv(K.O / "correlacion_errores_diarios.csv")
    orden = sorted(ks, key=lambda k: L[k].mean())
    ens = []
    for n in range(2, min(6, len(orden)) + 1):
        e = np.stack([medias[k] for k in orden[:n]]).mean(0)
        ens.append(dict(modelos=n, integrantes=" + ".join(nombres[k] for k in orden[:n]), MASE=float(np.abs(e - Y).mean() / K.Q), MASE_mejor_individual=float(L[orden[0]].mean())))
    K.guardar("ganancia_ensamble.csv", pd.DataFrame(ens))
    casos = L[orden[0]].sort_values(ascending=False).head(20)
    K.guardar("casos_frontera.csv", pd.DataFrame(dict(fecha=casos.index.strftime("%Y-%m-%d"), MASE=casos.to_numpy(), categoria=cat.loc[casos.index].to_numpy())))

    # ---------------------------------------------------------------- limitación del paper guía
    especial = cat.isin(["festivo", "puente o fin de semana largo", "Semana Santa", "temporada navideña o fin de año"]).to_numpy()
    laboral = (cat == "laboral").to_numpy()
    idx = K.indices_bloques(K.N, K.BLOQUE, 4000, K.SEMILLA + 11)
    filas, boots = [], {}
    for k in [p for p in PILOTO_LIMITACION if p in L.columns]:
        l = L[k].to_numpy()
        razon = l[especial].mean() / l[laboral].mean()
        bs = []
        for ix in idx:
            e, b = especial[ix], laboral[ix]
            bs.append(l[ix][e].mean() / l[ix][b].mean())
        bs = np.array(bs)
        boots[k] = bs
        filas.append(dict(clave=k, procedimiento=nombres[k], dias_especiales=int(especial.sum()), dias_laborales=int(laboral.sum()), MASE_especiales=float(l[especial].mean()),
                          MASE_laborales=float(l[laboral].mean()), razon=float(razon), ic95_inf=float(np.percentile(bs, 2.5)), ic95_sup=float(np.percentile(bs, 97.5))))
    tl = pd.DataFrame(filas)
    ref = "adj_modelo6_20261112_1035__N"
    if ref in boots:
        tl["diferencia_razon_frente_a_PatchTST"] = [float(np.mean(boots[k] - boots[ref])) if k != ref else 0.0 for k in tl.clave]
        tl["ic95_diferencia_inf"] = [float(np.percentile(boots[k] - boots[ref], 2.5)) if k != ref else np.nan for k in tl.clave]
        tl["ic95_diferencia_sup"] = [float(np.percentile(boots[k] - boots[ref], 97.5)) if k != ref else np.nan for k in tl.clave]
    tl["limitacion_presente"] = tl.ic95_inf > 1.0
    K.guardar("limitacion_paper_guia.csv", tl)
    print(pd.Series(techo).drop(["pesos", "entropia_permutacion"]).to_string())
    print(tl[["procedimiento", "razon", "ic95_inf", "ic95_sup"]].to_string(index=False))


if __name__ == "__main__":
    main()

"""Benchmark integrado con los procedimientos nuevos y contrastes confirmatorios (§6.1-6.3, §7.3, Apéndice A).

Uso (desde la raíz del repositorio):
    python scripts/e2c_estadistica_integrada.py --resultados-e2 ../Completar_E2/resultados_e2

Salidas en results/e2_cierre/: benchmark_A2.csv, contrastes_A3.csv, friedman_nemenyi.json, nemenyi_pares.csv,
mcs.csv, descomposicion_varianza.csv, wilcoxon_semillas.csv, diagrama_diferencia_critica.png.

Familias (PREREGISTRO_E2_COMPLEMENTO.md): RQ1, cada modelo del Top 10 frente al mejor baseline fuerte no profundo
(menor MASE entre ARX, LightGBM, MSTL-ETS y MSTL-ARIMA); RQ2, texto frente a su control numérico; RQ3, mejor modelo de
atención frente al mejor modelo base; RQ4 (exploratoria), ganadores de §14 frente a su arquitectura anterior. Cada contraste usa tres
pruebas: (i) Diebold-Mariano con corrección HLN y varianza HAC (paramétrica), (ii) bootstrap circular pareado por
bloques de 14 días y bootstrap bayesiano por bloques con ROPE de +-3 % (remuestreo / bayesiana), (iii) Holm sobre
la familia, con Friedman-Iman-Davenport, Nemenyi y Model Confidence Set como procedimientos globales.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

import e2c_comun as K

TOP10_BASE = {"PatchTST": "adj_modelo6_20261112_1035__N", "N-HiTS": "repo_nhits_numerico_r1__N", "TFT": "adj_modelo3_20261115_0419__N",
              "TCN": "adj_modelo4_20261114_1224__N", "iTransformer": "adj_modelo5_20261114_1327__N", "TaTS": "adj_modelo6_20261112_1035__N+O",
              "TGForecaster": "adj_modelo7_20261114_0430__N+O", "Fusión tardía": "adj_fusion_tardia_20261113_1728__N+O",
              "N-BEATS": "nuevo_nbeats__N", "TimesNet": "nuevo_timesnet__N"}
SUSTITUTOS_14 = {"TCN": "busqueda14_tcn__N", "TGForecaster": "busqueda14_tgforecaster__N+O", "Fusión tardía": "busqueda14_fusion__N+O"}
CLASICOS = ["arx_lineal", "clasico_lightgbm__N", "clasico_mstl_ets__N", "clasico_mstl_arima__N"]
MARGEN = 0.03


def dm_hln(d: np.ndarray, rezagos: int = 13) -> tuple[float, float]:
    T = len(d)
    u = d - d.mean()
    lrv = u @ u / T
    for k in range(1, rezagos + 1):
        lrv += 2 * (1 - k / (rezagos + 1)) * (u[k:] @ u[:-k]) / T
    est = d.mean() / np.sqrt(lrv / T) * np.sqrt((T - 1) / T)            # HLN con h = 1 (orígenes diarios no solapados)
    return float(est), float(2 * stats.t.sf(abs(est), T - 1))


def cliff(a: np.ndarray, b: np.ndarray) -> float:
    bs = np.sort(b)
    menores = np.searchsorted(bs, a, side="left")
    mayores = len(b) - np.searchsorted(bs, a, side="right")
    return float((mayores.sum() - menores.sum()) / (len(a) * len(b)))     # > 0: a tiende a ser menor (mejor) que b


def bayes_bloques(d: np.ndarray, ref: float, b: int = 4000, largo: int = K.BLOQUE, semilla: int = K.SEMILLA) -> dict:
    nb = int(np.ceil(len(d) / largo))
    medias = np.array([d[i * largo:(i + 1) * largo].mean() for i in range(nb)])
    pesos_n = np.array([len(d[i * largo:(i + 1) * largo]) for i in range(nb)])
    w = np.random.default_rng(semilla).dirichlet(np.ones(nb), size=b) * pesos_n
    m = (w * medias).sum(1) / w.sum(1)
    r = MARGEN * ref
    return dict(P_mejor=float((m < -r).mean()), P_equivalente=float((np.abs(m) <= r).mean()), P_peor=float((m > r).mean()))


def mcs(L: pd.DataFrame, alfa: float = 0.10, b: int = 2000) -> pd.DataFrame:
    """Model Confidence Set de Hansen, Lunde y Nason (2011) con estadístico T_max y bootstrap circular por bloques."""
    vivos, salida, p_acum = list(L.columns), [], 0.0
    idx = K.indices_bloques(len(L), K.BLOQUE, b, K.SEMILLA + 7)
    X = L.to_numpy()
    while len(vivos) > 1:
        j = [L.columns.get_loc(c) for c in vivos]
        x = X[:, j]
        d = x - x.mean(1, keepdims=True)
        dbar = d.mean(0)
        boot = d[idx].mean(1)                                  # (b, m)
        var = ((boot - dbar) ** 2).mean(0)
        t = dbar / np.sqrt(var)
        tmax = t.max()
        tb = ((boot - dbar) / np.sqrt(var)).max(1)
        p = float((tb >= tmax).mean())
        p_acum = max(p_acum, p)
        peor = vivos[int(np.argmax(t))]
        salida.append(dict(procedimiento=peor, p_MCS=p_acum, en_el_conjunto=p_acum >= alfa))
        if p_acum >= alfa:
            break
        vivos.remove(peor)
    restantes = [c for c in vivos if c not in [s["procedimiento"] for s in salida]]
    salida += [dict(procedimiento=c, p_MCS=1.0, en_el_conjunto=True) for c in restantes]
    t = pd.DataFrame(salida)
    t.loc[t.p_MCS >= alfa, "en_el_conjunto"] = True
    return t


def mincer_zarnowitz(y: np.ndarray, f: np.ndarray) -> float:
    import statsmodels.api as sm
    y, f = np.asarray(y) / 1e6, np.asarray(f) / 1e6                       # GWh: evita problemas numéricos de rango
    m = sm.OLS(y, sm.add_constant(f)).fit(cov_type="HAC", cov_kwds=dict(maxlags=13))
    return float(m.f_test("const = 0, x1 = 1").pvalue)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--resultados-e2", default=None)
    a = ap.parse_args()
    P, Y, nombres, fuentes = K.cargar_predicciones(a.resultados_e2)
    L = K.perdidas(P, Y)
    top10 = {m: (SUSTITUTOS_14.get(m) if SUSTITUTOS_14.get(m) in P else k) for m, k in TOP10_BASE.items()}
    faltan = [m for m, k in top10.items() if k not in P]
    if faltan:
        print("AVISO: faltan predicciones de", faltan, "- la familia confirmatoria se evalúa sin ellos.")
    top10 = {m: k for m, k in top10.items() if k in P}
    clas = [c for c in CLASICOS if c in P]
    base = min(clas, key=lambda c: L[c].mean())
    idx = K.indices_bloques(K.N, K.BLOQUE, K.B, K.SEMILLA)

    # ------------------------------------------------------------------ A.2: benchmark
    rangos = L.rank(axis=1).mean()
    filas = []
    costes = pd.read_csv(K.O / "costes.csv") if (K.O / "costes.csv").exists() else None
    robustez = pd.read_csv(K.O / "robustez_indice.csv") if (K.O / "robustez_indice.csv").exists() else None
    for k, v in P.items():
        sem = np.abs(v - Y[None]).mean(axis=(1, 2)) / K.Q
        bm = L[k].to_numpy()[idx].mean(1)
        f = dict(clave=k, procedimiento=nombres[k], entradas=fuentes[k], semillas=len(sem), MASE=float(sem.mean()), MASE_desv=float(sem.std(ddof=1)) if len(sem) > 1 else np.nan,
                 MASE_ic95_inf=float(np.percentile(bm, 2.5)), MASE_ic95_sup=float(np.percentile(bm, 97.5)), MAE_kwh=float(np.abs(v - Y[None]).mean()),
                 RMSE_kwh=float(np.sqrt(((v - Y[None]) ** 2).mean(axis=(1, 2))).mean()), p_Mincer_Zarnowitz=mincer_zarnowitz(Y.mean(1), v.mean(0).mean(1)),
                 rango_medio=float(rangos[k]))
        if costes is not None and k in set(costes.clave):
            f.update(costes.set_index("clave").loc[k, [c for c in ("parametros", "flops_por_origen", "latencia_mediana_ms") if c in costes.columns]].to_dict())
        if robustez is not None and k in set(robustez.clave):
            f["indice_robustez"] = float(robustez.set_index("clave").loc[k, "indice_robustez"])
        filas.append(f)
    bench = pd.DataFrame(filas).sort_values("MASE")
    K.guardar("benchmark_A2.csv", bench)

    # ------------------------------------------------------------------ globales: Friedman, Nemenyi, MCS
    cols = [c for c in L.columns]
    k_, n_ = len(cols), len(L)
    ch = stats.friedmanchisquare(*[L[c] for c in cols])
    ff = (n_ - 1) * ch.statistic / (n_ * (k_ - 1) - ch.statistic)
    p_id = float(stats.f.sf(ff, k_ - 1, (k_ - 1) * (n_ - 1)))
    q = stats.studentized_range.ppf(0.95, k_, np.inf) / np.sqrt(2)
    cd = float(q * np.sqrt(k_ * (k_ + 1) / (6 * n_)))
    pares = []
    for i, x in enumerate(cols):
        for y in cols[i + 1:]:
            z = abs(rangos[x] - rangos[y]) / np.sqrt(k_ * (k_ + 1) / (6 * n_))
            pares.append(dict(a=nombres[x], b=nombres[y], dif_rangos=float(rangos[x] - rangos[y]),
                              p_Nemenyi=float(min(1.0, stats.studentized_range.sf(z * np.sqrt(2), k_, np.inf)))))
    K.guardar("nemenyi_pares.csv", pd.DataFrame(pares))
    K.guardar_json("friedman_nemenyi.json", dict(procedimientos=k_, dias=n_, chi2=float(ch.statistic), p_chi2=float(ch.pvalue), F_Iman_Davenport=float(ff),
                                                p_Iman_Davenport=p_id, diferencia_critica_Nemenyi=cd, rangos={nombres[c]: float(rangos[c]) for c in cols}))
    m = mcs(L[cols])
    m["nombre"] = m.procedimiento.map(nombres)
    K.guardar("mcs.csv", m)
    _diagrama_cd(rangos, nombres, cd)

    # ------------------------------------------------------------------ A.3: familias de contrastes del preregistro
    def contraste(fam, nombre, k, ref):
        lr = L[ref].to_numpy()
        d = L[k].to_numpy() - lr
        dm, p_dm = dm_hln(d)
        bd = d[idx].mean(1)
        rel = 100 * bd / lr[idx].mean(1)
        return dict(familia=fam, contraste=nombre, clave=k, referencia=nombres[ref], MASE_modelo=float(L[k].mean()), MASE_referencia=float(lr.mean()),
                    diferencia_MASE=float(d.mean()), ic95_diferencia_inf=float(np.percentile(bd, 2.5)), ic95_diferencia_sup=float(np.percentile(bd, 97.5)),
                    diferencia_relativa_pct=float(100 * d.mean() / lr.mean()), ic95_relativa_pct_inf=float(np.percentile(rel, 2.5)),
                    ic95_relativa_pct_sup=float(np.percentile(rel, 97.5)), ic90_relativa_pct_inf=float(np.percentile(rel, 5)), ic90_relativa_pct_sup=float(np.percentile(rel, 95)),
                    d_Cohen_pareado=float(d.mean() / d.std(ddof=1)), delta_Cliff=cliff(L[k].to_numpy(), lr), prob_superioridad=float((d < 0).mean()),
                    DM_HLN=dm, p_DM=p_dm, p_bootstrap=float(np.mean(np.abs(bd - d.mean()) >= abs(d.mean()))), **bayes_bloques(d, float(lr.mean())),
                    semillas_modelo=int(P[k].shape[0]))

    familias = []
    familias += [contraste("RQ1 Top 10 frente al mejor baseline fuerte", f"{m} - {nombres[base]}", k, base) for m, k in top10.items()]
    tgf_n = "busqueda14_tgforecaster__N" if "busqueda14_tgforecaster__N" in P else "adj_modelo7_20261114_0430__N"
    pares_txt = [("TaTS N+O - PatchTST N", top10.get("TaTS"), "adj_modelo6_20261112_1035__N"), ("Fusión N+O - PatchTST N", top10.get("Fusión tardía"), "adj_modelo6_20261112_1035__N"),
                 ("TGForecaster N+O - N", top10.get("TGForecaster"), tgf_n)]
    familias += [contraste("RQ2 Texto frente a su control numérico", n, k, r) for n, k, r in pares_txt if k in P and r in P]
    atencion = [k for k in (top10.get("PatchTST"), top10.get("iTransformer"), top10.get("TFT"), top10.get("TaTS")) if k in P]
    bases_e1 = [k for k in ("mlp", "lstm", "cnn1d") if k in P]
    if atencion and bases_e1:
        ka, kb = min(atencion, key=lambda c: L[c].mean()), min(bases_e1, key=lambda c: L[c].mean())
        familias.append(contraste("RQ3 Mejor atención frente al mejor modelo base", f"{nombres[ka]} - {nombres[kb]}", ka, kb))
    viejos = {"busqueda14_mlp__N": "mlp", "busqueda14_lstm__N": "lstm", "busqueda14_cnn1d__N": "cnn1d", "busqueda14_tcn__N": "adj_modelo4_20261114_1224__N",
              "busqueda14_tgforecaster__N+O": "adj_modelo7_20261114_0430__N+O", "busqueda14_fusion__N+O": "adj_fusion_tardia_20261113_1728__N+O"}
    familias += [contraste("RQ4 (exploratoria) §14 frente a la arquitectura anterior", f"{nombres[k]} - {nombres[v]}", k, v) for k, v in viejos.items() if k in P and v in P]
    t = pd.DataFrame(familias)
    if len(t):
        for col in ("p_DM", "p_bootstrap"):
            t[col + "_Holm"] = t.groupby("familia")[col].transform(lambda p: multipletests(p, method="holm")[1])

        def decision(r):
            lo, hi = r.ic95_relativa_pct_inf, r.ic95_relativa_pct_sup
            sig = r.p_DM_Holm < 0.05 and r.p_bootstrap_Holm < 0.05
            if sig and hi < -100 * MARGEN:
                return "significativa y relevante: menor error"
            if sig and lo > 100 * MARGEN:
                return "significativa y relevante: mayor error"
            if -100 * MARGEN < r.ic90_relativa_pct_inf and r.ic90_relativa_pct_sup < 100 * MARGEN:
                return "equivalente dentro de +-3 % (TOST, IC 90 %)"
            if sig:
                return "significativa sin relevancia práctica"
            return "no concluyente"
        t["decision"] = t.apply(decision, axis=1)
        t["en_MCS_90"] = t.clave.isin(set(m.loc[m.en_el_conjunto, "procedimiento"]))
    K.guardar("contrastes_A3.csv", t)

    # ------------------------------------------------------------------ semillas y varianza
    multi = [k for k, v in P.items() if v.shape[0] >= 5]
    filas = []
    for i, x in enumerate(multi):
        sx = np.abs(P[x] - Y[None]).mean(axis=(1, 2)) / K.Q
        for y in multi[i + 1:]:
            sy = np.abs(P[y] - Y[None]).mean(axis=(1, 2)) / K.Q
            n = min(len(sx), len(sy))
            w = stats.wilcoxon(sx[:n], sy[:n]) if np.any(sx[:n] != sy[:n]) else None
            filas.append(dict(a=nombres[x], b=nombres[y], semillas=n, p_wilcoxon_exacto=float(w.pvalue) if w else 1.0,
                              p_minimo_posible=float(2 / 2 ** n)))
    tw = pd.DataFrame(filas)
    if len(tw):
        tw["p_Holm"] = multipletests(tw.p_wilcoxon_exacto, method="holm")[1]
    K.guardar("wilcoxon_semillas.csv", tw)
    # descomposición por momentos: pérdida diaria (modelo, semilla, día)
    A = np.stack([np.abs(P[k][:5] - Y[None]).mean(axis=2) / K.Q for k in multi])       # (m, 5, N)
    gm = A.mean()
    m_ef, d_ef = A.mean(axis=(1, 2)) - gm, A.mean(axis=(0, 1)) - gm
    inter = A.mean(axis=1) - gm - m_ef[:, None] - d_ef[None, :]
    resid = A - A.mean(axis=1, keepdims=True)
    ss = dict(modelo=float(5 * K.N * (m_ef ** 2).sum()), dia=float(5 * len(multi) * (d_ef ** 2).sum()), modelo_x_dia=float(5 * (inter ** 2).sum()),
              semilla_dentro_de_modelo_y_dia=float((resid ** 2).sum()))
    tot = sum(ss.values())
    K.guardar("descomposicion_varianza.csv", pd.DataFrame([dict(fuente=k, suma_cuadrados=v, proporcion=v / tot) for k, v in ss.items()]))
    print(bench[["procedimiento", "MASE", "MASE_ic95_inf", "MASE_ic95_sup", "rango_medio"]].to_string(index=False))
    print("\nBaseline fuerte:", nombres[base])
    if len(t):
        print(t[["familia", "contraste", "diferencia_relativa_pct", "ic95_relativa_pct_inf", "ic95_relativa_pct_sup", "p_DM_Holm", "decision"]].to_string(index=False))


def _diagrama_cd(rangos: pd.Series, nombres: dict, cd: float) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    r = rangos.sort_values()
    fig, ax = plt.subplots(figsize=(11, 0.32 * len(r) + 1.5))
    ax.hlines(range(len(r)), 1, r.to_numpy(), color="#c9d3d9", lw=1)
    ax.plot(r.to_numpy(), range(len(r)), "o", color="#247ba0")
    ax.set_yticks(range(len(r)), [nombres[k] for k in r.index], fontsize=8)
    ax.errorbar(r.iloc[0], -0.8, xerr=[[0], [cd]], fmt="none", ecolor="#be5146", capsize=4)
    ax.text(r.iloc[0] + cd / 2, -1.3, f"DC de Nemenyi = {cd:.2f}", ha="center", fontsize=8, color="#be5146")
    ax.invert_yaxis()
    ax.set_xlabel("Rango medio por día (1 = menor error)")
    fig.tight_layout()
    fig.savefig(K.O / "diagrama_diferencia_critica.png", dpi=130)
    plt.close(fig)


if __name__ == "__main__":
    main()

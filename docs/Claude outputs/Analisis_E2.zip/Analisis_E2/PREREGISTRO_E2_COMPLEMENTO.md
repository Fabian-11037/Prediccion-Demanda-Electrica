# Preregistro complementario del Entregable 2 (versión 1, 18 de noviembre de 2026)

Este documento se versiona en el repositorio (`git tag preregistro-e2-complemento-v1`) **antes** del primer
entrenamiento del paquete `Completar_E2`. Su huella SHA-256 queda en `resultados_e2/REGISTRO.json`; si cambia
después de iniciar, el paquete se detiene. Hereda sin cambios de `PREREGISTRO.md` y del Entregable 1 la tarea, la
métrica primaria, el margen δ, la unidad de independencia y la partición.

## 1. Tarea, unidad y métricas

| Campo | Valor |
|---|---|
| Tarea | Series de tiempo: pronóstico directo de 24 h de la demanda real horaria del SIN, origen diario 00:00 (America/Bogota), historia de 168 h |
| Unidad de independencia | El origen diario (24 etiquetas); las horas no se tratan como réplicas |
| Métrica primaria | MASE con escala q168 de 2000-2017 (215 617,90 kWh) |
| Métricas secundarias | MAE (kWh), RMSE (kWh), MASE por horizonte; no sustentan conclusiones confirmatorias |
| Margen de relevancia δ | 3 % relativo de MASE (heredado) |
| Margen de sobreajuste δg | 0,10: (pérdida de parada − pérdida de ajuste) / pérdida de ajuste en la época restaurada |
| α | 0,05; Model Confidence Set al 90 % |

## 2. Preguntas de investigación

**Advertencia de validez.** El bloque 2022-2025 ya se leyó para los 13 procedimientos del benchmark actual. Solo
los procedimientos que este paquete entrena por primera vez (N-BEATS, TimesNet, LightGBM, MSTL-ETS, MSTL-ARIMA y los
ganadores de §14) llegan a la prueba sin haberla visto. Las RQ marcadas como confirmatorias se contrastan con
control de error por familia, pero su alcance es retrospectivo y así se reporta.

| RQ | Pregunta | H0 / H1 | Pruebas | Tipo |
|---|---|---|---|---|
| RQ1 | ¿Algún modelo del Top 10 reduce el MASE en al menos 3 % frente al mejor baseline fuerte no profundo (menor MASE entre ARX, LightGBM, MSTL-ETS y MSTL-ARIMA)? | H0: MASE_k − MASE_base ≥ 0; H1: < 0 | DM-HLN con HAC (13 rezagos); bootstrap circular pareado de bloques de 14 días (10 000) y bootstrap bayesiano por bloques con ROPE ±3 %; Holm sobre los 10; Friedman-Iman-Davenport, Nemenyi y MCS como globales | Confirmatoria (familia de 10) |
| RQ2 | ¿El texto oficial reduce el MASE en al menos 3 % frente a su control numérico? Pares: TaTS N+O frente a PatchTST N, fusión tardía N+O frente a PatchTST N, TGForecaster N+O frente a TGForecaster N (con la arquitectura de §14) | H0: diferencia ≥ 0; H1: < 0; equivalencia si el IC 90 % está dentro de ±3 % | Las mismas tres pruebas; Holm sobre los 3 | Confirmatoria (familia de 3) |
| RQ3 | ¿El mejor modelo de atención (PatchTST, iTransformer, TFT, TaTS) reduce el MASE en al menos 3 % frente al mejor modelo base del Entregable 1 (MLP, LSTM, CNN1D)? | H0: diferencia ≥ 0; H1: < 0 | Las mismas tres pruebas; un contraste | Confirmatoria |
| RQ4 | ¿La búsqueda de §14 cambia el MASE de MLP, LSTM, CNN1D, TCN, TGForecaster y fusión frente a su arquitectura anterior? | H0: diferencia = 0 | Bootstrap pareado y DM-HLN; Holm sobre 6 | Exploratoria: la prueba de MLP, LSTM, CNN1D y TCN ya se leyó |
| RQ5 | ¿La limitación del paper guía (ver §6) es específica de PatchTST o compartida por la familia? | H0: razón especiales / laborales = 1 | IC 95 % por bootstrap de bloques; diferencia de razones frente a PatchTST | Exploratoria |

## 3. Comparaciones, supuestos y decisión

* Cada contraste confirmatorio usa tres pruebas: una paramétrica (DM-HLN), una de remuestreo y bayesiana (bootstrap
  pareado por bloques y bootstrap bayesiano con ROPE) y un procedimiento con control de multiplicidad (Holm en la
  familia; Friedman con Nemenyi y MCS como globales). Wilcoxon sobre 5 semillas se reporta como descriptivo: con 5
  pares su p bilateral mínimo es 0,0625.
* Supuestos: no se supone independencia entre días (HAC y bloques). Si la varianza de largo plazo de DM es no
  positiva, se usa solo el bootstrap.
* Decisión por contraste: significativa y relevante si p_Holm < 0,05 en DM y en el bootstrap y el IC 95 % de la
  diferencia relativa queda por debajo de −3 %; equivalente si el IC 95 % queda dentro de ±3 %; significativa sin
  relevancia si p_Holm < 0,05 y el IC cruza −3 %; no concluyente en los demás casos.

## 4. Ejecuciones, potencia, exclusión y parada

* R = 5 semillas finales (1000-1004) por procedimiento. Con el piloto disponible, 5 semillas no alcanzan potencia
  0,80 para δ = 3 % en todos los pares; se declara como limitación y se reporta la diferencia mínima detectable.
* Exclusión: una corrida con pérdida no finita detiene el paquete y se reporta; ninguna corrida se descarta en silencio.
* Parada (todas las redes): AdamW, MAE sobre demanda / nivel, ReduceLROnPlateau(0,5; 2), recorte 1,0, máximo 200
  épocas, parada desde la época 10 con 6 épocas sin mejora relativa de 0,2 %, restauración del mejor estado.
* Presupuesto de hiperparámetros por modelo: 20 configuraciones (semilla 43, pliegue 2018), 5 finalistas en
  2019-2021, configuración de menor MASE medio. Configuraciones fijas en `config/plan_e2.json`.

## 5. Búsqueda de arquitectura (§14)

| Elemento | Valor |
|---|---|
| Modelos | MLP, LSTM y CNN1D (entradas de los modelos base), TCN, TGForecaster (búsqueda en N+O; las dos variantes se entrenan con la ganadora) y la rama de texto de la fusión tardía |
| Espacio | 3 bloques, anchos {16, 32, 64, 128, 256}, dropout 0,2 en cada posición: 125 × 8 = 1000 arquitecturas, sin poda |
| Fase 0 | Hiperparámetros no arquitectónicos con la arquitectura de control (64, 64, 64), dropout (0, 1, 0), protocolo común. TCN usa la configuración 7 del paquete Modelo 4, cuyas 20 configuraciones ya usaron esa arquitectura |
| Fase 1 | Las 1000 arquitecturas, semilla 43, pliegue 2018, máximo 50 épocas (25 %), parada desde la época 5 con paciencia 6 |
| Piloto de ruido | A0498 (control), A0000, A0999, A0340, A0673 con semillas 101-103 y el presupuesto de la fase 1 |
| k | 10 si (desviación media entre semillas del piloto) / (desviación entre las 1000 arquitecturas) ≤ 0,5; si no, 20. Más la arquitectura de control |
| Fase 2 | Finalistas con semillas 1100-1104, presupuesto completo, pliegue 2018 |
| Selección | Menor MASE medio de la fase 2; empate técnico (a menos de 3 % del mejor): menos parámetros; luego menor identificador. Conjunto indistinguible por TOST de Welch ±3 % |
| C_total | La etapa `estimar` del paquete lo calcula con tiempos medidos antes de lanzar la fase 1 y lo guarda en `estimacion/estimacion_computo.json` |
| Reporte | Superficie de la fase 1, ANOVA de factores con Holm, efectos principales e interacciones, tendencia en log2 del ancho, dropout frente a sin dropout pareado por anchos (Wilcoxon), Pareto, correlación de rangos entre fases, posición en el borde |

Desviaciones declaradas: la fase 2 usa solo el pliegue 2018 (la fase 0 usó cuatro); para MLP, LSTM, CNN1D y TCN la
prueba ya se había leído con otra arquitectura, así que sus resultados de prueba con la ganadora son exploratorios.

## 6. Paper guía, réplica y limitación

* Paper guía: Nie, Nguyen, Sinthong y Kalagnanam (2023), *A Time Series is Worth 64 Words: Long-term Forecasting with
  Transformers*, ICLR, arXiv:2211.14730. PatchTST es el control numérico de TaTS y de la fusión tardía.
* Réplica: código oficial (commit 204c21e) con los argumentos de `etth1.sh` y `etth2.sh`, ETTh1 y ETTh2, horizontes
  96/192/336/720, semillas 2021-2025. Criterio de éxito: el MSE o MAE publicado (tabla 3, PatchTST/42) cae en el
  IC 95 % t de las 5 semillas, o la diferencia relativa es menor que 3 %.
* Limitación declarada antes de los experimentos: PatchTST es independiente por canal y no recibe covariables futuras
  conocidas; se espera menor precisión en días no laborables especiales. Métrica: razón entre el MASE de festivos,
  puentes, Semana Santa y temporada navideña y el MASE de días laborales, con IC 95 % por bootstrap de bloques de 14
  días, piloto en al menos tres modelos del Top 10 (PatchTST, iTransformer, TCN, N-HiTS, TFT, TaTS, N-BEATS, TimesNet).

## 7. Otros experimentos del paquete

* Modelos nuevos del Top 10: N-BEATS-G (30 pilas, 4 capas de 512) y TimesNet (2 TimesBlock, top_k 5, 6 núcleos), con
  las adaptaciones descritas en `config/plan_e2.json`. No entran en §14 porque sus artículos definen la arquitectura.
* Baselines no profundos: LightGBM directo (mismo protocolo y presupuesto) y MSTL (24 y 168 h) con ETS o ARIMA
  automáticos, ventana de 4, 8 o 12 semanas elegida en validación 2018-2021.
* Ablación sobre PatchTST N (configuración 18 del modelo 6; equivalente a TaTS N+O y con menos parámetros):
  sin vía de contexto, sin atención, sin variables exógenas, sin calendario; 5 semillas; bootstrap y Holm sobre 4.
* Sanidad (§10.1): etiquetas de ajuste y parada permutadas en PatchTST y TCN; criterio: MASE de prueba al menos
  1,25 veces el del modelo real.
* Análisis sobre predicciones guardadas (scripts `e2c_*.py`): incertidumbre (ensamble de semillas y conformal
  adaptativo en los tres mejores), Tabla B, techo y taxonomía de errores, robustez con tres severidades, fidelidad y
  estabilidad de las explicaciones, costes y Pareto.

## 8. Análisis exploratorios permitidos

Todo lo que no figura en las RQ1-RQ3: desagregaciones por horizonte, año y tipo de día; RQ4 y RQ5; costes; robustez;
incertidumbre; importancia de variables. Se etiquetan como exploratorios y no se usan para elegir modelos.

## 9. Congelamiento de datos

* Panel: SHA-256 en `config/diseno_entrenamiento_texto.json` (`panel_sha256`), verificado en cada arranque.
* Prueba: 1461 orígenes de 2022-01-01 a 2025-12-31 (huella del capítulo de evaluación del libro).
* ETTh1 y ETTh2: SHA-256 en `config/plan_e2.json` (`replica.sha256_datos`).

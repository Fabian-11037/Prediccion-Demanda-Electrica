"""Entrenamientos y pruebas que faltan para cerrar el Entregable 2 (ver LEEME.txt y PREREGISTRO_E2_COMPLEMENTO.md).

No se llama directamente: se usa ENTRENAR_WINDOWS.bat o entrenar_linux.sh, que preparan el entorno.

    python ejecutar_e2.py                          todas las etapas, en orden (reanuda si ya hay resultados)
    python ejecutar_e2.py --etapas estimar         solo estima el tiempo de cómputo (unos minutos)
    python ejecutar_e2.py --etapas busqueda14 --modelos14 mlp tcn
    python ejecutar_e2.py --prueba-rapida          verificación de pocos minutos; no produce resultados válidos
Etapas: estimar, nuevos, clasicos, ablacion, sanidad, replica, busqueda14, robustez (inferencia con los pesos finales).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_e2.json").read_text(encoding="utf-8"))
ETAPAS = ["estimar", "nuevos", "clasicos", "ablacion", "sanidad", "replica", "busqueda14", "robustez"]
MODELOS14 = list(PLAN["busqueda14"]["modelos"])


def _cache_codificador() -> Path:
    propia = RAIZ / ".cache_hf"
    if propia.exists():
        return propia
    for otra in sorted(RAIZ.parent.glob("*/.cache_hf")):
        if (otra / "hub").exists():
            return otra
    return propia


os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
os.environ.setdefault("HF_HOME", str(_cache_codificador()))
sys.path.insert(0, str(RAIZ / "src"))

import numpy as np          # noqa: E402
import pandas as pd         # noqa: E402
import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from entrenamiento import clasicos, pruebas, replica, texto           # noqa: E402
from entrenamiento import protocolo as PR                             # noqa: E402
from entrenamiento import protocolo_e2 as P2                          # noqa: E402
from entrenamiento import redes_e2                                    # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256                # noqa: E402

ASCII = os.name == "nt"
RAPIDO = dict(max_epocas=2, n_tr=320, n_es=48, n_ev=48, finalistas=1, semillas_finales=[1000, 1001], remuestreos=300, documentos_codificador=24,
              configuraciones=[1, 2], arquitecturas=["A0498", "A0000", "A0999", "A0340"], k=2)


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + [RAIZ / "data" / "processed" / n for n in ("panel_horario.parquet", "corpus_oficial.parquet", "feature_registry.json")]
    rutas += sorted((RAIZ / "data" / "replica").glob("*.csv")) + [RAIZ / "ejecutar_e2.py", RAIZ / "PREREGISTRO_E2_COMPLEMENTO.md"]
    rutas += sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts)
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.exists()}


def entorno(dispositivo: str) -> dict:
    e = dict(python=platform.python_version(), sistema=platform.platform(), procesador=platform.processor() or platform.machine(), nucleos=os.cpu_count(),
             torch=torch.__version__, numpy=np.__version__, dispositivo=dispositivo, cuda_disponible=torch.cuda.is_available(),
             rocm=getattr(torch.version, "hip", None), cuda=torch.version.cuda)
    if torch.cuda.is_available():
        e.update(gpu=torch.cuda.get_device_name(0), memoria_gpu_gb=round(torch.cuda.get_device_properties(0).total_memory / 2**30, 1))
    try:
        import psutil
        e["ram_gb"] = round(psutil.virtual_memory().total / 2**30, 1)
    except Exception:
        pass
    for m in ("pandas", "pyarrow", "transformers", "lightgbm", "statsforecast", "mlflow", "scipy", "statsmodels"):
        try:
            e[m] = __import__(m).__version__
        except Exception:
            e[m] = None
    return e


def contexto(salida: Path, clave: str, red: str, variantes: list[str], datos, dispositivo, log, rapido, args, extra: dict | None = None):
    c = PLAN["comun"]
    cfg = dict(version=PLAN["version"], paquete=dict(clave=clave, nombre=clave, red=red, carpeta_resultados=salida.name), variantes=variantes,
               busqueda=dict(c["busqueda"]), final=dict(c["final"]), entrenamiento=dict(c["entrenamiento"]), inferencia=dict(c["inferencia"]))
    cfg.update(extra or {})
    if rapido:
        cfg["busqueda"]["finalistas"] = rapido["finalistas"]
    ctx = PR.Contexto(RAIZ, salida, cfg, datos, dispositivo, log, rapido)
    ctx.hilos = args.hilos
    ctx.mlflow, ctx.mlflow_raiz = not args.sin_mlflow, args.salida_raiz
    return ctx


def preparar_texto(salida: Path, datos, dispositivo, log, rapido, args) -> tuple[dict, np.ndarray]:
    ct = datos.contrato["texto"]
    de_prueba = bool(args.prueba_rapida)
    desc = texto.preparar_descripciones(RAIZ, salida / "texto" / "descripciones", ct, datos.hist + datos.nombres_mascara, dispositivo, log,
                                        modo_prueba=de_prueba, codificador=args.codificador)
    n_dias = len(datos.indice) // 24
    if de_prueba:
        canal = texto.preparar_canal(RAIZ, salida / "texto", ct, datos.dia_base, n_dias, dispositivo, log, modo_prueba=True)
    else:
        n = len(texto.cargar_corpus_oficial(RAIZ))
        with tqdm(total=n, desc="Vectores de texto", unit="doc", dynamic_ncols=True, ascii=ASCII) as barra:
            rp = salida / "texto" / "parcial.npz"
            if rp.exists():
                try:
                    barra.update(int(np.load(rp)["hecho"]))
                except Exception:
                    pass
            elif (salida / "texto" / "vectores_documento.npy").exists():
                barra.update(n)
            canal = texto.preparar_canal(RAIZ, salida / "texto", ct, datos.dia_base, n_dias, dispositivo, log, codificador=args.codificador, barra=barra)
    return canal, desc


def comprobaciones(datos, canal, desc) -> dict:
    out = dict(numericas=pruebas.numericas(datos))
    torch.manual_seed(0)
    n_x, n_cal, B = len(datos.hist) + len(datos.nombres_mascara), len(datos.cal), 4
    x, cp, cf, dia = torch.randn(B, datos.L, n_x), torch.randn(B, datos.L, n_cal), torch.randn(B, datos.H, n_cal), torch.zeros(B, dtype=torch.long)
    chicas = {"mlp14": {}, "lstm14": {}, "cnn14": dict(kernel=5), "tcn14": dict(kernel=5), "nbeats": dict(pilas=2, ancho=32, dropout=0.0),
              "timesnet": dict(e_layers=1, top_k=3, num_kernels=2, d_model=16, d_ff=16, dropout=0.0), "patchtst_ablacion": dict(PLAN["ablacion"]["configuracion_base"])}
    r = {}
    for red, p in chicas.items():
        p = dict(p, anchos=[16, 32, 16], patron_dropout=[1, 0, 1])
        variantes = [dict(p, ablacion=a) for a in redes_e2.ABLACIONES] if red == "patchtst_ablacion" else [p]
        for q in variantes:
            m = redes_e2.construir(red, q, n_x, n_cal, datos.L, datos.H).eval()
            with torch.no_grad():
                y = m(x, cp, cf, dia)
            r[f"{red}{'_' + q['ablacion'] if 'ablacion' in q else ''}_salida_24_finita"] = tuple(y.shape) == (B, datos.H) and bool(torch.isfinite(y).all())
    # el ancho de cada bloque y el patrón de dropout se aplican como se declararon
    m = redes_e2.construir("mlp14", dict(anchos=[16, 256, 32], patron_dropout=[1, 0, 1]), n_x, n_cal, datos.L, datos.H)
    capas = [c for c in m.red if isinstance(c, torch.nn.Linear)]
    r["mlp14_anchos_y_patron"] = [c.out_features for c in capas[:3]] == [16, 256, 32] and [type(c).__name__ for c in m.red][2::3] == ["Dropout", "Identity", "Dropout"]
    out["redes_e2"] = r
    out["tcn"] = pruebas.redes(datos, "tcn", [dict(PLAN["busqueda14"]["modelos"]["tcn"]["fase0"]["fija"], id=1, dropout=0.2, **PLAN["busqueda14"]["control"])], None, None)
    if canal is not None:
        base_tgf = [dict(PLAN["busqueda14"]["modelos"]["tgforecaster"]["fase0"]["configuraciones"][0], d_model=16, capas=1, cabezas=4)]
        out["texto"] = pruebas.texto(datos, canal, datos.contrato["texto"])
        out["tgforecaster"] = pruebas.redes(datos, "tgforecaster", base_tgf, canal, desc)
        out["fusion_tardia"] = pruebas.redes(datos, "fusion_tardia", [dict(PLAN["busqueda14"]["modelos"]["fusion"]["fase0"]["configuraciones"][0], d_fusion=16)], canal, desc)
    return out


def estimar(datos, dispositivo, log, rapido, args, salida: Path, texto_canal) -> dict:
    """Tiempo por época de cada familia con datos reales y la estimación de C_total de §14.4 antes de lanzar."""
    pos = P2._pos(contexto(salida, "estimacion", "mlp14", ["N"], datos, dispositivo, log, rapido, args), 2018)
    medidas = {}
    casos = {
        "nbeats": ("nbeats", dict(PLAN["nuevos"]["nbeats"]["configuraciones"][0])),
        "timesnet": ("timesnet", dict(PLAN["nuevos"]["timesnet"]["configuraciones"][0])),
        "ablacion": ("patchtst_ablacion", dict(PLAN["ablacion"]["configuracion_base"], ablacion="completo")),
    }
    for m, d in PLAN["busqueda14"]["modelos"].items():
        base = d["fase0"].get("fija") or d["fase0"]["configuraciones"][0]
        for etiqueta, a in (("control", PLAN["busqueda14"]["control"]), ("ancho256", dict(anchos=[256, 256, 256], patron_dropout=[1, 1, 1]))):
            casos[f"b14_{m}_{etiqueta}"] = (d["red"], dict(base, **a), d["variante_busqueda"])
    for nombre, caso in casos.items():
        red, p = caso[0], dict(caso[1], id=9000)
        variante = caso[2] if len(caso) > 2 else "N"
        ctx = contexto(salida, "estimacion", red, [variante], datos, dispositivo, log, rapido, args)
        ctx.mlflow = False
        if texto_canal is not None:
            ctx.texto = dict(vectores=texto_canal[0]["vectores"], lista=texto_canal[0]["lista"])
            ctx.descripciones = texto_canal[1]
        r = PR.corrida(ctx, variante, p, 43, "pliegue_2018", pos, salida / nombre, "val_2018", opciones=dict(max_epocas=3, min_epocas=3, paciencia=99))
        h = pd.read_csv(salida / nombre / "historia.csv")
        medidas[nombre] = float(np.diff(np.r_[0.0, h.segundos.to_numpy()])[1:].mean()) if len(h) > 1 else float(h.segundos.iloc[0])
        log(f"Estimación {nombre}: {medidas[nombre]:.1f} s por época ({r['n_parametros']:,} parámetros).")
    E_full, E_f1 = 40, 25      # épocas medias supuestas con parada temprana (completo y fase 1); se reportan también x0,5 y x2
    fin = PLAN["comun"]["final"]["semillas"]
    n_std = 20 + 5 * 3 + len(fin)
    tabla = []
    for m in ("nbeats", "timesnet"):
        tabla.append(dict(etapa="nuevos", modelo=m, corridas=n_std, horas=n_std * E_full * medidas[m] / 3600))
    tabla.append(dict(etapa="ablacion", modelo="patchtst", corridas=25, horas=25 * E_full * medidas["ablacion"] / 3600))
    tabla.append(dict(etapa="sanidad", modelo="patchtst+tcn", corridas=2, horas=2 * E_full * medidas["ablacion"] / 3600))
    f2 = PLAN["busqueda14"]["fase2"]
    for m, d in PLAN["busqueda14"]["modelos"].items():
        t_media = (medidas[f"b14_{m}_control"] + medidas[f"b14_{m}_ancho256"]) / 2
        f0 = 0 if "fija" in d["fase0"] else n_std - len(fin)
        for k in (f2["k_regla"]["k_bajo"], f2["k_regla"]["k_alto"]):
            corr = f0 + 1000 + 15 + (k + 1) * len(f2["semillas"]) + len(fin) * len(d["variantes"])
            horas = (f0 * E_full * medidas[f"b14_{m}_control"] + (1000 + 15) * E_f1 * t_media + ((k + 1) * len(f2["semillas"]) + len(fin) * len(d["variantes"])) * E_full * t_media) / 3600
            tabla.append(dict(etapa="busqueda14", modelo=f"{m} (k={k})", corridas=corr, horas=horas))
    t = pd.DataFrame(tabla)
    t["horas_si_paran_antes_x0.5"], t["horas_si_paran_despues_x2"] = t.horas * 0.5, t.horas * 2
    t.to_csv(salida / "estimacion_computo.csv", index=False)
    k10 = t[~t.modelo.str.contains("k=20")]
    total = float(k10.horas.sum())
    d = dict(segundos_por_epoca=medidas, supuestos=dict(epocas_medias_completo=E_full, epocas_medias_fase1=E_f1, clasicos_y_replica="no incluidos (CPU, horas)"),
             horas_totales_k10=total, horas_totales_k20=float(t[~t.modelo.str.contains("k=10")].horas.sum()), dispositivo=dispositivo)
    PR.guardar_json(salida / "estimacion_computo.json", d)
    log("ESTIMACIÓN (k = 10 finalistas): " + "; ".join(f"{r.modelo} {r.horas:.1f} h" for r in k10.itertuples()) + f". TOTAL ≈ {total:.0f} h (rango {total / 2:.0f}-{2 * total:.0f} h).")
    return d


def empaquetar(salida: Path, log) -> list[Path]:
    sello = dt.datetime.now().strftime("%Y%m%d_%H%M")
    pesados = lambda r: r.suffix in (".pt", ".npy") or r.name in ("parcial.npz", "modelo_lightgbm.txt") or r.name == "mlflow.db" or "mlruns" in r.parts   # noqa: E731
    z1, z2 = RAIZ / f"ENVIAR_resultados_E2_{sello}.zip", RAIZ / f"ENVIAR_pesos_vectores_mlruns_E2_{sello}.zip"
    for destino, criterio, nivel in ((z1, lambda r: not pesados(r), zipfile.ZIP_DEFLATED), (z2, pesados, zipfile.ZIP_STORED)):
        with zipfile.ZipFile(destino, "w", nivel) as z:
            for r in sorted(salida.rglob("*")):
                if r.is_file() and criterio(r):
                    z.write(r, Path(salida.name) / r.relative_to(salida))
    log(f"Archivos para enviar: {z1.name} ({z1.stat().st_size / 2**20:.1f} MB) y {z2.name} ({z2.stat().st_size / 2**20:.1f} MB)")
    return [z1, z2]


def main() -> int:
    ap = argparse.ArgumentParser(description="Cierre del Entregable 2")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=ETAPAS)
    ap.add_argument("--modelos14", nargs="+", choices=MODELOS14, default=MODELOS14)
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--hilos", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)), help="procesos de CPU para MSTL y LightGBM")
    ap.add_argument("--codificador", default=None)
    ap.add_argument("--sin-mlflow", action="store_true")
    ap.add_argument("--sin-empaquetar", action="store_true")
    ap.add_argument("--ensayo", action="store_true", help=argparse.SUPPRESS)
    a = ap.parse_args()
    rapido = dict(RAPIDO) if (a.prueba_rapida or a.ensayo) else None
    salida = RAIZ / ("resultados_prueba_rapida_e2" if a.prueba_rapida else "resultados_ensayo_e2" if a.ensayo else "resultados_e2")
    salida.mkdir(exist_ok=True)
    a.salida_raiz = salida
    log = Bitacora(salida / "bitacora.log")
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    if dispositivo == "cuda" and not torch.cuda.is_available():
        log("Se pidió GPU pero PyTorch no la detecta; se usa CPU.")
        dispositivo = "cpu"
    gpu = f" ({torch.cuda.get_device_name(0)}{', ROCm' if getattr(torch.version, 'hip', None) else ''})" if dispositivo == "cuda" else ""
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if a.prueba_rapida else 'ENSAYO' if a.ensayo else 'EJECUCIÓN'} | etapas {a.etapas} | dispositivo {dispositivo}{gpu}")
    t_ini = time.time()

    h = huellas()
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg["huellas_sha256"]) if reg["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: estos archivos cambiaron después de iniciar: {cambiados}. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar: el plan, las semillas y las reglas quedan fijados por las huellas.",
                   creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), plan=PLAN["version"], prueba_rapida=bool(rapido), huellas_sha256=h, reanudaciones=[])
    PR.guardar_json(rreg, reg)
    PR.guardar_json(salida / f"entorno_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", entorno(dispositivo))

    log("Cargando el panel y verificando su SHA-256...")
    datos = DatosNumericos(RAIZ)
    for nombre, esperado in PLAN["replica"]["sha256_datos"].items():
        if sha256(RAIZ / "data" / "replica" / f"{nombre}.csv") != esperado:
            log(f"ERROR: data/replica/{nombre}.csv no coincide con su SHA-256.")
            return 3
    con_texto = ("busqueda14" in a.etapas and any(m in a.modelos14 for m in ("tgforecaster", "fusion"))) or "estimar" in a.etapas or "robustez" in a.etapas
    canal = desc = None
    if con_texto:
        log("Preparando el canal de documentos oficiales y las descripciones de canal (codificador E5)...")
        canal, desc = preparar_texto(salida, datos, dispositivo, log, rapido, a)
    comp = comprobaciones(datos, canal, desc)
    PR.guardar_json(salida / "comprobaciones_previas.json", comp)
    fallas = [f"{g}.{k}" for g, d in comp.items() for k, v in d.items() if not v]
    if fallas:
        log(f"ERROR: fallaron las comprobaciones previas {fallas}. No se entrena.")
        return 4
    log(f"Comprobaciones previas correctas ({sum(len(d) for d in comp.values())}).")
    tc = (canal, desc) if canal is not None else None

    def con_texto_ctx(ctx):
        if canal is not None:
            ctx.texto = dict(vectores=canal["vectores"], lista=canal["lista"])
            ctx.descripciones = desc
        return ctx

    resumen = {}
    for etapa in [e for e in ETAPAS if e in a.etapas]:
        log(f"---- Etapa: {etapa}")
        if etapa == "estimar":
            resumen["estimar"] = estimar(datos, dispositivo, log, rapido, a, salida / "estimacion", tc)
        elif etapa == "nuevos":
            for m, d in PLAN["nuevos"].items():
                ctx = contexto(salida / f"nuevo_{m}", m, d["red"], d["variantes"], datos, dispositivo, log, rapido, a)
                cfgs = [c for c in d["configuraciones"] if not rapido or c["id"] in rapido["configuraciones"]]
                n = len(cfgs) + ctx.cfg["busqueda"]["finalistas"] * 3 + len(rapido["semillas_finales"] if rapido else PLAN["comun"]["final"]["semillas"])
                with tqdm(total=n, desc=f"Nuevo: {m}", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                    ctx.barra = barra
                    resumen[m] = P2.modelo_estandar(ctx, cfgs)["variantes"]
        elif etapa == "clasicos":
            ctx = contexto(salida / "clasico_lightgbm", "lightgbm", "lightgbm", ["N"], datos, dispositivo, log, rapido, a)
            with tqdm(total=20 + 15 + 5, desc="LightGBM", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                ctx.barra = barra
                resumen["lightgbm"] = clasicos.lightgbm(ctx, PLAN["clasicos"]["lightgbm"]["configuraciones"])
            ctx = contexto(salida / "clasico_mstl", "mstl", "mstl", ["N"], datos, dispositivo, log, rapido, a)
            pm = PLAN["clasicos"]["mstl"]
            with tqdm(total=len(pm["modelos"]) * (len(pm["ventanas_semanas"]) * len(pm["pliegues_validacion"]) + 1), desc="MSTL", unit="bloque", dynamic_ncols=True, ascii=ASCII) as barra:
                ctx.barra = barra
                resumen["mstl"] = clasicos.mstl(ctx, pm)
        elif etapa == "ablacion":
            ctx = contexto(salida / "ablacion_patchtst", "ablacion", "patchtst_ablacion", ["N"], datos, dispositivo, log, rapido, a)
            with tqdm(total=len(PLAN["ablacion"]["ablaciones"]) * len(rapido["semillas_finales"] if rapido else PLAN["ablacion"]["semillas"]), desc="Ablación", unit="modelo",
                      dynamic_ncols=True, ascii=ASCII) as barra:
                ctx.barra = barra
                resumen["ablacion"] = P2.ablacion(ctx, PLAN["ablacion"]).to_dict("records")
        elif etapa == "sanidad":
            ctx = contexto(salida / "sanidad", "sanidad", "patchtst_ablacion", ["N"], datos, dispositivo, log, rapido, a)
            with tqdm(total=len(PLAN["sanidad"]["casos"]), desc="Sanidad", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                ctx.barra = barra
                resumen["sanidad"] = P2.sanidad(ctx, PLAN["sanidad"]).to_dict("records")
        elif etapa == "replica":
            pr = PLAN["replica"]
            n = len(pr["datos"]) * (1 if rapido else len(pr["horizontes"])) * (2 if rapido else len(pr["semillas"]))
            with tqdm(total=n, desc="Réplica PatchTST", unit="corrida", dynamic_ncols=True, ascii=ASCII) as barra:
                (salida / "replica_patchtst").mkdir(exist_ok=True)
                resumen["replica"] = replica.ejecutar(RAIZ, salida / "replica_patchtst", pr, dispositivo, log, rapido, barra).to_dict("records")
        elif etapa == "busqueda14":
            for m in [x for x in MODELOS14 if x in a.modelos14]:
                d = PLAN["busqueda14"]["modelos"][m]
                ctx = con_texto_ctx(contexto(salida / f"busqueda14_{m}", f"b14_{m}", d["red"], [d["variante_busqueda"]], datos, dispositivo, log, rapido, a))
                n_arq = len(rapido["arquitecturas"]) if rapido else 1000
                with tqdm(total=None, desc=f"§14 {m} (fase 1: {n_arq} arquitecturas)", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                    ctx.barra = barra
                    resumen[f"b14_{m}"] = P2.Busqueda14(ctx, PLAN["busqueda14"], d).ejecutar()["variantes"]
        elif etapa == "robustez":
            red_de = {f"nuevo_{m}": d["red"] for m, d in PLAN["nuevos"].items()} | {f"busqueda14_{m}": d["red"] for m, d in PLAN["busqueda14"]["modelos"].items()}
            t = P2.robustez(salida, datos, red_de, dict(vectores=canal["vectores"], lista=canal["lista"]) if canal is not None else None, desc, dispositivo, log, rapido)
            resumen["robustez"] = f"{t.clave.nunique() if len(t) else 0} procedimientos; ver robustez_nuevos_por_semilla.csv"
        PR.guardar_json(salida / "RESUMEN_E2.json", resumen)
    log(f"Etapas terminadas en {(time.time() - t_ini) / 3600:.2f} h.")
    if not a.sin_empaquetar and a.etapas != ["estimar"]:
        empaquetar(salida, log)
    return 0


if __name__ == "__main__":
    sys.exit(main())

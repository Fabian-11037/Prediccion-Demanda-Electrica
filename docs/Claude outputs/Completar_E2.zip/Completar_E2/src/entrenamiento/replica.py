"""Réplica parcial del paper guía (§5): PatchTST/42 (Nie et al., ICLR 2023) en ETTh1 y ETTh2.

Se ejecuta el código oficial (``vendor/patchtst_oficial``, licencia Apache-2.0, commit registrado en
``plan_e2.json``) con los argumentos de sus guiones ``scripts/PatchTST/etth1.sh`` y ``etth2.sh``: partición
12/4/4 meses, escalado con estadísticos de entrenamiento, ventana 336, horizontes 96/192/336/720, MSE como
pérdida y MSE/MAE en la escala normalizada. Cambios: semillas 2021-2025 en lugar de una sola (2021) y
``num_workers = 0`` para que funcione en Windows; ninguno altera el cálculo. Los datos ETT (CC BY-ND 4.0) van
sin modificar en ``data/replica``.

Criterio de réplica fijado antes de ejecutar: para cada combinación, la réplica es exitosa si el valor
publicado cae dentro del IC 95 % t de las cinco semillas o si la diferencia relativa es menor que 3 %.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from .protocolo import guardar_json


def _args(plan: dict, datos: str, horizonte: int, semilla: int, raiz_datos: Path, epocas: int | None) -> list[str]:
    a = dict(plan["argumentos_oficiales"])
    a.update(random_seed=semilla, root_path=str(raiz_datos) + os.sep, data_path=f"{datos}.csv", model_id=f"{datos}_336_{horizonte}", data=datos,
             pred_len=horizonte, num_workers=0)
    if epocas is not None:
        a["train_epochs"] = epocas
    out = []
    for k, v in a.items():
        out += [f"--{k}", str(v)]
    return out


def ejecutar(raiz: Path, salida: Path, plan: dict, dispositivo: str, log, rapido: dict | None = None, barra=None) -> pd.DataFrame:
    vendor = raiz / "src" / "vendor" / "patchtst_oficial"
    raiz_datos = (raiz / "data" / "replica").resolve()
    filas = []
    semillas = plan["semillas"][:2] if rapido else plan["semillas"]
    horizontes = plan["horizontes"][:1] if rapido else plan["horizontes"]
    for datos in plan["datos"]:
        for h in horizontes:
            for s in semillas:
                c = salida / datos / f"h{h}" / f"semilla_{s}"
                hecho = c / "metricas.json"
                if not hecho.exists():
                    c.mkdir(parents=True, exist_ok=True)
                    cmd = [sys.executable, str(vendor / "run_longExp.py"), *_args(plan, datos, h, s, raiz_datos, 1 if rapido else None)]
                    entorno = dict(os.environ, PYTHONPATH=str(vendor), MPLBACKEND="Agg")
                    if dispositivo == "cpu":
                        entorno["CUDA_VISIBLE_DEVICES"] = ""      # el argumento --use_gpu del guion oficial es type=bool y no se puede apagar por texto
                    with open(c / "salida.log", "w", encoding="utf-8") as f:
                        rc = subprocess.call(cmd, cwd=c, stdout=f, stderr=subprocess.STDOUT, env=entorno)
                    texto = (c / "result.txt").read_text(encoding="utf-8") if (c / "result.txt").exists() else ""
                    m = re.findall(r"mse:([0-9.eE+-]+), mae:([0-9.eE+-]+)", texto)
                    if rc != 0 or not m:
                        raise RuntimeError(f"La réplica oficial falló en {datos} h={h} semilla {s}; ver {c / 'salida.log'}")
                    guardar_json(hecho, dict(datos=datos, horizonte=h, semilla=s, MSE=float(m[-1][0]), MAE=float(m[-1][1])))
                    for basura in ("checkpoints", "results", "test_results"):
                        shutil.rmtree(c / basura, ignore_errors=True)       # predicciones de hasta 56 MB por corrida
                import json
                filas.append(json.loads(hecho.read_text(encoding="utf-8")))
                log(f"Réplica {datos} h={h} semilla {s}: MSE {filas[-1]['MSE']:.4f} MAE {filas[-1]['MAE']:.4f}", consola=False)
                if barra is not None:
                    barra.update(1)
    t = pd.DataFrame(filas)
    t.to_csv(salida / "replica_por_semilla.csv", index=False)
    pub = pd.DataFrame(plan["valores_publicados"])
    resumen = []
    for (datos, h), g in t.groupby(["datos", "horizonte"]):
        for met in ("MSE", "MAE"):
            v = g[met].to_numpy()
            ref = float(pub.loc[(pub.datos == datos) & (pub.horizonte == h), met].iloc[0])
            m, sd, n = float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else np.nan, len(v)
            ic = (m - stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n), m + stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else (np.nan, np.nan)
            rel = 100 * (m - ref) / ref
            resumen.append(dict(datos=datos, horizonte=h, metrica=met, publicado=ref, replica_media=m, replica_desv=sd, semillas=n, ic95_inf=ic[0], ic95_sup=ic[1],
                                diferencia_relativa_pct=rel, publicado_en_ic95=bool(ic[0] <= ref <= ic[1]) if n > 1 else None,
                                exito=bool((n > 1 and ic[0] <= ref <= ic[1]) or abs(rel) < 100 * plan["criterio"]["margen_relativo"])))
    r = pd.DataFrame(resumen)
    r.to_csv(salida / "replica_frente_a_publicado.csv", index=False)
    return r

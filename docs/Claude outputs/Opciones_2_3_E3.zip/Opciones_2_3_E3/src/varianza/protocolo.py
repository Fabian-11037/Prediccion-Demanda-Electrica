"""Opción 2: recetas de reducción de varianza con capacidad igualada, sobre E y PatchTST N (partición de desarrollo).

Etapas (reanudables):
  profesores      por pliegue, PatchTST N, E y el codificador periódico con 3 semillas propias (201-203); se guardan sus
                  predicciones de ajuste, parada y validación. El maestro es su apilamiento NNLS por hora ajustado en la
                  parada (anterior a la validación) y aplicado al tramo de ajuste.
  estudiantes     E y PatchTST N, semillas 101-105, con tres entrenamientos: control, destil (imita al maestro, α = 0,5)
                  y multicabeza (K = 3 cabezas con remuestreo Poisson; solo crece la capa de salida)
  exportabilidad  ONNX de control y multicabeza (destil tiene la arquitectura del control)
  decision        recalibración por hora (una escala por hora ajustada por NNLS en la parada) sobre cada estudiante,
                  referencias de ensamble de 3 semillas, regla preregistrada y bitácora
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.optimize import nnls

from demanda import metricas as MET
from entrenamiento import protocolo_e2 as P2
from entrenamiento import redes_e3
from entrenamiento.protocolo import guardar_json, leer_json
from exploracion.protocolo import Exploracion, _hoy

ENTRENAMIENTOS = ("control", "destil", "multicabeza")


def escala_por_hora(P_es: np.ndarray, y_es: np.ndarray) -> np.ndarray:
    return np.array([nnls(P_es[:, [h]].astype("float64"), y_es[:, h].astype("float64"))[0][0] for h in range(P_es.shape[1])])


def apilar(P_es: np.ndarray, y_es: np.ndarray) -> np.ndarray:
    """Pesos NNLS por hora (K, H) a partir de las predicciones de parada (K, n, H)."""
    K, _, H = P_es.shape
    return np.stack([nnls(P_es[:, :, h].T.astype("float64"), y_es[:, h].astype("float64"))[0] for h in range(H)], axis=1)


class Varianza(Exploracion):
    # ------------------------------------------------------------------ maestro
    def _ruta(self, *partes) -> Path:
        return self.salida.joinpath(*partes)

    def semillas_profesor(self):
        return self.plan["profesores"]["semillas"] if not self.rapido else self.plan["profesores"]["semillas"][:2]

    def profesores(self) -> dict:
        pr = self.plan["profesores"]
        info = {}
        for anio in self.plan["pliegues"]:
            P = {}
            for base in pr["bases"]:
                p = dict(pr["configuraciones"][base])
                for s in self.semillas_profesor():
                    car = self._ruta("profesores", base, f"pliegue_{anio}", f"semilla_{s}")
                    ctx = self.ctx(car.parent, f"profesor_{base}", pr["redes"][base], p)
                    from entrenamiento import protocolo as PR
                    PR.corrida(ctx, "N", p, s, f"pliegue_{anio}", P2._pos(ctx, anio), car, f"val_{anio}", guardar_parada=True, guardar_ajuste=True)
                    P[(base, s)] = {k: np.load(car / f) for k, f in (("tr", "pred_ajuste.npz"), ("es", "pred_parada.npz"), ("ev", f"pred_val_{anio}.npz"))}
            claves = sorted(P)
            ref = P[claves[0]]
            for k in claves[1:]:
                for c in ("tr", "es", "ev"):
                    if not np.array_equal(P[k][c]["origen"], ref[c]["origen"]):
                        raise RuntimeError("Los profesores no comparten orígenes")
            Pe = np.stack([P[k]["es"]["yhat_kwh"] for k in claves]).astype("float64")
            W = apilar(Pe, ref["es"]["y_kwh"].astype("float64"))
            comb = lambda c: np.einsum("kh,knh->nh", W, np.stack([P[k][c]["yhat_kwh"] for k in claves]).astype("float64"))   # noqa: E731
            tr = comb("tr")
            nivel = ref["tr"]["nivel"].astype("float64")
            yv = ref["ev"]["y_kwh"].astype("float64")
            np.savez_compressed(self._ruta("profesores", f"maestro_{anio}.npz"), origen=ref["tr"]["origen"], prof_norm=(tr / nivel[:, None]).astype("float32"),
                                y_norm=(ref["tr"]["y_kwh"] / nivel[:, None]).astype("float32"), pesos=W.astype("float32"), expertos=np.array([f"{b}·{s}" for b, s in claves]))
            info[str(anio)] = dict(expertos=[f"{b}·{s}" for b, s in claves], pesos_por_modelo={b: float(W[[i for i, k in enumerate(claves) if k[0] == b]].sum(0).mean())
                                                                                              for b in pr["bases"]},
                                   MASE_maestro_validacion=float(MET.evaluar(yv, comb("ev"), self.datos.q168)["MASE"]),
                                   MASE_maestro_ajuste=float(MET.evaluar(ref["tr"]["y_kwh"].astype("float64"), tr, self.datos.q168)["MASE"]))
            self.log(f"MAESTRO {anio}: MASE de validación {info[str(anio)]['MASE_maestro_validacion']:.4f}; pesos {info[str(anio)]['pesos_por_modelo']}")
        guardar_json(self._ruta("profesores", "resumen.json"), info)
        return info

    # ------------------------------------------------------------------ estudiantes
    def _extra(self, mec: str, anio: int) -> dict:
        if mec == "destil":
            return dict(rec_destilar=str(self._ruta("profesores", f"maestro_{anio}.npz")))
        return {}

    def estudiantes(self) -> pd.DataFrame:
        filas = []
        for anio in self.plan["pliegues"]:
            for base in self.bases():
                for mec in ENTRENAMIENTOS:
                    for s in self.semillas():
                        extra = dict(self._extra(mec, anio), **({"rec_semilla_cabezas": s} if mec == "multicabeza" else {}))
                        filas.append(self._celda(base, mec, anio, s, raiz="estudiantes", extra=extra))
                        pd.DataFrame(filas).to_csv(self._ruta("estudiantes", "parcial.csv"), index=False)
        t = pd.DataFrame(filas)
        t.to_csv(self._ruta("estudiantes", "tabla.csv"), index=False)
        return t

    def exportabilidad(self) -> dict:
        import onnxruntime as ort
        d = self.datos
        n_x, n_cal = d.X.shape[1] + d.M.shape[1], d.K.shape[1]
        g = torch.Generator().manual_seed(7)
        out = {}
        for base in self.bases():
            for mec in ("control", "multicabeza"):
                p = self.config_celda(base, mec, dict(rec_semilla_cabezas=1) if mec == "multicabeza" else None)
                torch.manual_seed(0)
                red = redes_e3.construir("x_" + self.plan["bases"][base]["red"], p, n_x, n_cal, d.L, d.H, n_mascaras=len(d.nombres_mascara)).eval()
                with torch.no_grad():
                    for w in red.parameters():
                        w.add_(0.05 * torch.randn(w.shape, generator=g))

                def ent(e):
                    return (e * torch.randn(4, d.L, n_x, generator=g), torch.randn(4, d.L, n_cal, generator=g), torch.randn(4, d.H, n_cal, generator=g),
                            torch.arange(4, dtype=torch.int64) + 100)
                a, b = ent(1.0), ent(3.0)
                ruta = self._ruta("exportabilidad", f"{base}_{mec}.onnx")
                ruta.parent.mkdir(parents=True, exist_ok=True)
                try:
                    torch.onnx.export(red, a, str(ruta), input_names=["x", "cal_p", "cal_f", "dia"], output_names=["y"], opset_version=17,
                                      dynamic_axes={k: {0: "lote"} for k in ("x", "cal_p", "cal_f", "dia", "y")}, dynamo=False)
                    ses = ort.InferenceSession(str(ruta), providers=["CPUExecutionProvider"])
                    nom = {i.name for i in ses.get_inputs()}
                    with torch.no_grad():
                        err = max(float(np.abs(ses.run(None, {k: v.numpy() for k, v in zip(["x", "cal_p", "cal_f", "dia"], e) if k in nom})[0] - red(*e).numpy()).max())
                                  for e in (a, b))
                    out[f"{base}·{mec}"] = dict(exportable=bool(err < 1e-4), error_max=err, n_parametros=int(red.n_parametros()))
                except Exception as e:
                    out[f"{base}·{mec}"] = dict(exportable=False, motivo=f"{type(e).__name__}: {str(e)[:300]}")
                ruta.unlink(missing_ok=True)
        guardar_json(self._ruta("exportabilidad", "resultado.json"), out)
        return out

    # ------------------------------------------------------------------ tabla completa con recalibración y ensambles
    def _pred(self, base, mec, anio, s, cual):
        car = self._ruta("estudiantes", base, mec, f"pliegue_{anio}", f"semilla_{s}")
        z = np.load(car / (f"pred_val_{anio}.npz" if cual == "val" else "pred_parada.npz"))
        return z["yhat_kwh"].astype("float64"), z["y_kwh"].astype("float64")

    def tabla(self) -> pd.DataFrame:
        t = pd.read_csv(self._ruta("estudiantes", "tabla.csv"))
        q = self.datos.q168
        extra = []
        S = self.semillas()
        for base in self.bases():
            for anio in self.plan["pliegues"]:
                for mec in ENTRENAMIENTOS:
                    npar = int(t[(t.base == base) & (t.mecanismo == mec)].n_parametros.max())
                    for s in S:
                        pv, yv = self._pred(base, mec, anio, s, "val")
                        pe, ye = self._pred(base, mec, anio, s, "parada")
                        e = escala_por_hora(pe, ye)
                        extra.append(dict(base=base, mecanismo=f"{mec}_recal", celda=f"{base}·{mec}_recal", pliegue=anio, semilla=s,
                                          MASE=MET.evaluar(yv, pv * e[None], q)["MASE"], n_parametros=npar, escala_media=float(e.mean())))
                # referencia: ensamble de 3 semillas del control (rotación), media y apilamiento; NO es propuesta (triple de redes)
                npar = int(t[(t.base == base) & (t.mecanismo == "control")].n_parametros.max())
                for i, s in enumerate(S):
                    otras = [S[(i + k) % len(S)] for k in range(min(3, len(S)))]
                    Pv = np.stack([self._pred(base, "control", anio, u, "val")[0] for u in otras])
                    Pe = np.stack([self._pred(base, "control", anio, u, "parada")[0] for u in otras])
                    yv = self._pred(base, "control", anio, s, "val")[1]
                    ye = self._pred(base, "control", anio, s, "parada")[1]
                    W = apilar(Pe, ye)
                    for nombre, pr in (("ensamble3_media", Pv.mean(0)), ("ensamble3_apilamiento", np.einsum("kh,knh->nh", W, Pv))):
                        extra.append(dict(base=base, mecanismo=nombre, celda=f"{base}·{nombre}", pliegue=anio, semilla=s, MASE=MET.evaluar(yv, pr, q)["MASE"],
                                          n_parametros=npar * len(otras)))
        t = pd.concat([t, pd.DataFrame(extra)], ignore_index=True)
        (self.salida / "decision").mkdir(exist_ok=True)
        t.to_csv(self._ruta("decision", "desarrollo_por_semilla.csv"), index=False)
        return t

    def decision(self) -> dict:
        pr = self.plan["regla"]
        t = self.tabla()
        n_esp = len(self.plan["pliegues"]) * len(self.semillas())
        cortas = t.groupby("celda").size()
        if (cortas < n_esp).any() and not self.rapido:
            raise RuntimeError(f"Celdas incompletas: {cortas[cortas < n_esp].to_dict()}")
        r = t.groupby(["celda", "base", "mecanismo"]).agg(MASE_medio=("MASE", "mean"), MASE_desv=("MASE", "std"), n_parametros=("n_parametros", "max")).reset_index()
        m = dict(zip(r.celda, r.MASE_medio))
        mejor_control = min((c for c in m if c.endswith("·control")), key=m.get)
        exp = leer_json(self._ruta("exportabilidad", "resultado.json")) if self._ruta("exportabilidad", "resultado.json").exists() else {}
        filas = []
        for x in r.itertuples():
            prop = x.base == "E" and x.mecanismo in pr["propuestas"]
            refs = ["E·control", f"patchtst·{x.mecanismo}"] if prop else []
            perd = [q for q in refs if q in m and not m[x.celda] < m[q]]
            arq = "multicabeza" if x.mecanismo.startswith("multicabeza") else "control"
            filas.append(dict(celda=x.celda, propuesta=prop, elegible=prop and not perd, motivo=("elegible" if not perd else "no mejora a " + ", ".join(perd)) if prop else "referencia",
                              exportable=bool(exp.get(f"{x.base}·{arq}", {}).get("exportable", False)) if not x.mecanismo.startswith("ensamble") else False))
        r = r.merge(pd.DataFrame(filas), on="celda")
        par_ref = {b: float(r[(r.base == b) & (r.mecanismo == "control")].n_parametros.max()) for b in r.base.unique()}
        r["capacidad_relativa"] = [v / par_ref[b] for b, v in zip(r.base, r.n_parametros)]
        r["capacidad_igualada"] = r.capacidad_relativa <= float(pr.get("capacidad_max", 1.1))
        r["mejora_frente_al_mejor_control_pct"] = 100 * (m[mejor_control] - r.MASE_medio) / m[mejor_control]
        r["mejora_frente_a_su_control_pct"] = [100 * (m[f"{b}·control"] - v) / m[f"{b}·control"] for b, v in zip(r.base, r.MASE_medio)]
        r = r.sort_values("MASE_medio").reset_index(drop=True)
        r.to_csv(self._ruta("decision", "desarrollo_resumen.csv"), index=False)
        cand = r[r.elegible & r.exportable & r.capacidad_igualada].sort_values(["MASE_medio", "n_parametros"])
        gan, texto = (str(cand.celda.iloc[0]) if len(cand) else None), []
        if gan and not m[gan] < m[mejor_control]:
            texto.append(f"La mejor elegible ({gan}, {m[gan]:.4f}) no mejora al mejor control ({mejor_control}, {m[mejor_control]:.4f}).")
            gan = None
        if not len(cand):
            texto.append("Ninguna receta de capacidad igualada sobre E mejora a la vez a E·control y a la misma receta sobre PatchTST N.")
        mi = r[r.elegible & ~r.capacidad_igualada].sort_values("MASE_medio")
        if len(mi):
            texto.append(f"Con más capacidad, {mi.celda.iloc[0]} ({mi.MASE_medio.iloc[0]:.4f}, {mi.capacidad_relativa.iloc[0]:.2f} veces los parámetros) "
                         "cumpliría la elegibilidad, pero no puede adoptarse.")
        contrastes = []
        if gan:
            mec = gan.split("·")[1]
            for q in dict.fromkeys([mejor_control, "E·control", f"patchtst·{mec}", "patchtst·ensamble3_apilamiento"]):
                if q in m:
                    contrastes.append(self._contraste(t, gan, q))
            texto.append(f"Se elige {gan} (MASE {m[gan]:.4f}); frente al mejor control {mejor_control}: {contrastes[0]['mejora_pct']:.2f} % "
                         f"(p t {contrastes[0].get('p_t_pareada_bilateral', float('nan')):.3g}). "
                         + ("Alcanza el margen de 3 %." if contrastes[0]["mejora_pct"] >= 100 * pr["margen_fuerte"] else "No alcanza el margen de 3 %."))
        else:
            texto.append("Decisión: ninguna receta se adopta; el diseño se cierra con E (parte 1).")
        pd.DataFrame(contrastes).to_csv(self._ruta("decision", "contrastes_ganadora.csv"), index=False)
        n_prop = int(r.propuesta.sum())
        dec = dict(ganadora=gan, motivo=" ".join(texto), regla=pr["texto"], mejor_control=mejor_control, contrastes=contrastes, N_d_esta_exploracion=n_prop,
                   N_d_previo=self.plan["diseno_previo"]["N_d"], N_d_acumulado=n_prop + self.plan["diseno_previo"]["N_d"], fecha=_hoy(),
                   prueba_rapida=bool(self.rapido), transparencia=self.plan["transparencia"])
        ruta = self._ruta("decision", "decision.json")
        if ruta.exists() and leer_json(ruta)["ganadora"] != gan:
            raise RuntimeError("La decisión cambió al reanudar")
        guardar_json(ruta, dec)
        lin = ["# Opción 2: recetas de varianza con capacidad igualada (desarrollo 2018-2019)", "", f"Decisión: **{gan or 'ninguna'}**. {dec['motivo']}", "",
               f"N_d de esta exploración: {n_prop}; acumulado: {dec['N_d_acumulado']}.", "",
               "| Celda | MASE (media ± DE) | Frente a su control | Frente al mejor control | Parámetros (x control) | Propuesta | Elegible | ONNX | Motivo |",
               "|---|---|---|---|---|---|---|---|---|"]
        lin += [f"| {x.celda} | {x.MASE_medio:.4f} ± {x.MASE_desv:.4f} | {x.mejora_frente_a_su_control_pct:.2f} % | {x.mejora_frente_al_mejor_control_pct:.2f} % | "
                f"{int(x.n_parametros):,} ({x.capacidad_relativa:.2f}) | {'sí' if x.propuesta else 'no'} | {'sí' if x.elegible else 'no'} | {'sí' if x.exportable else 'no'} | "
                f"{x.motivo}{'' if x.capacidad_igualada or not x.propuesta else ' (capacidad mayor: no adoptable)'} |" for x in r.itertuples()]
        p = self._ruta("profesores", "resumen.json")
        if p.exists():
            lin += ["", "Maestro (apilamiento de PatchTST N, E y periódico, 3 semillas cada uno):", ""]
            lin += [f"- {a}: MASE de validación {v['MASE_maestro_validacion']:.4f}; pesos {v['pesos_por_modelo']}" for a, v in leer_json(p).items()]
        lin += ["", f"Regla: {pr['texto']}", "", f"Transparencia: {self.plan['transparencia']}"]
        (self.salida / "RESUMEN_VARIANZA.md").write_text("\n".join(lin) + "\n", encoding="utf-8")
        self.log(f"DECISIÓN: {dec['motivo']}")
        return dec

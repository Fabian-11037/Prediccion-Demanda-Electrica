"""Opción 3: estudio de episodios con anuncios oficiales selectivos (exploratorio; partición de desarrollo).

Etapas (reanudables):
  seleccion  corpus ampliado (disponibilidad declarada), solo familias oficiales que anuncian medidas (lista del plan; se
             excluyen los boletines rutinarios de IDEAM, los informes de mercado y las proyecciones). Intervalos anunciados
             con las mismas reglas de fecha del corrector; candidatos por día = solo la reserva alineada (hasta 32).
             Se codifican con E5 los fragmentos usados. Se copian, sin modificarlos, los residuos E + C+R y la
             configuración elegida del corrector semántico (results/corrector_semantico_e3_20261122).
  selectivo  corrector con solo anuncios selectivos alineados (misma arquitectura, configuración y semillas del
             corrector; ajuste 2012..Y-2, parada Y-1, evaluación Y = 2019-2021)
  placebo    el mismo con los anuncios de otro día (5 desplazamientos, múltiplos de 7)
  evaluacion contrastes frente al corrector numérico horario ya entrenado (num_horario) y al placebo, en todos los días y
             en los días cubiertos por algún anuncio selectivo; tabla y figuras de los episodios preregistrados
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from corrector import evaluacion as EV
from corrector import protocolo as CP
from corrector import texto as TX
from entrenamiento.protocolo import guardar_json, leer_json

TZ = "America/Bogota"


class Episodios:
    def __init__(self, salida: Path, plan: dict, plan_corrector: dict, datos, dispositivo: str, log, rapido: dict | None, args, cfg_texto: dict):
        self.salida, self.plan, self.pc, self.datos, self.dev, self.log, self.rapido, self.args = Path(salida), plan, plan_corrector, datos, dispositivo, log, rapido, args
        self.cfg_texto = cfg_texto
        self.rc = Path(args.resultados_corrector)
        self.col = plan["seleccion"]["disponibilidad"]
        self.barra = None

    # ------------------------------------------------------------------ plan compatible con corrector.protocolo.Corrida
    def plan_c(self) -> dict:
        c = self.plan["corrector"]
        return dict(texto=dict(disponibilidad_principal=self.col, disponibilidad_sensibilidad="no_aplica"),
                    corrector=dict(primer_anio_ajuste=c["primer_anio_ajuste"], anios_evaluacion=c["anios_evaluacion"], max_epocas=c["max_epocas"],
                                   paciencia=c["paciencia"], desplazamientos_placebo=c["desplazamientos_placebo"], anio_seleccion=None, rejilla={}),
                    semillas=c["semillas"], evaluacion=self.plan["evaluacion"])

    def corrida(self) -> CP.Corrida:
        cp = CP.Corrida(self.salida, self.plan_c(), self.datos, self.dev, self.log, self.rapido)
        cp.barra = self.barra
        return cp

    def semillas(self):
        return self.rapido["semillas"] if self.rapido else self.plan["corrector"]["semillas"]

    def anios(self):
        return self.rapido["anios_evaluacion"] if self.rapido else self.plan["corrector"]["anios_evaluacion"]

    def desplazamientos(self):
        return self.rapido["desplazamientos"] if self.rapido else self.plan["corrector"]["desplazamientos_placebo"]

    # ------------------------------------------------------------------ etapas
    def seleccion(self) -> dict:
        car = self.salida / "texto"
        if (car / "candidatos.npz").exists() and (car / "resumen.json").exists():
            self.log("Selección ya construida; se reutiliza.")
            return json.loads((car / "resumen.json").read_text(encoding="utf-8"))
        car.mkdir(parents=True, exist_ok=True)
        # insumos del corrector (solo lectura)
        (self.salida / "cr").mkdir(exist_ok=True)
        for s in self.plan["corrector"]["semillas"]:
            shutil.copy2(self.rc / "cr" / f"semilla_{s}.npz", self.salida / "cr" / f"semilla_{s}.npz")
        (self.salida / "corrector" / "busqueda").mkdir(parents=True, exist_ok=True)
        shutil.copy2(self.rc / "corrector" / "busqueda" / "configuracion_elegida.json", self.salida / "corrector" / "busqueda" / "configuracion_elegida.json")
        tx, sel = self.pc["texto"], self.plan["seleccion"]
        ruta = Path(self.args.corpus)
        h = TX.sha256(ruta)
        if h != tx["corpus_sha256"] and not self.rapido:
            raise RuntimeError(f"El corpus no es el preregistrado (SHA-256 {h[:12]}...)")
        c = TX.cargar_corpus(ruta, self.col, tx["desde"], tx["hasta"], self.rapido.get("docs_por_anio") if self.rapido else None,
                             tx["max_fragmentos_documento"] * (tx["caracteres_fragmento"] - tx["solape_caracteres"]) + tx["solape_caracteres"])
        familias = {(f, d) for f, ds in sel["familias"].items() for d in ds}
        c = c[[(f, d) in familias for f, d in zip(c.fuente, c.familia_documental)]].reset_index(drop=True)
        self.log(f"Documentos selectivos: {len(c)} ({c.groupby(['fuente', 'familia_documental']).size().to_dict()}).")
        frag = TX.fragmentos(c, tx["caracteres_fragmento"], tx["solape_caracteres"], tx["max_fragmentos_documento"])
        inter = TX.intervalos_corpus(c, frag, self.log, tx["caracteres_fragmento"], tx["solape_caracteres"])
        dias = pd.date_range(tx["primer_dia_candidatos"], tx["ultimo_dia"], freq="D")
        fuentes = sorted(c.fuente.unique())
        k = TX.candidatos(c, frag, inter, dias, fuentes, sel["max_alineados"], 0, 0, tx["ventana_h"], tx["antiguedad_alineados_dias"])
        usados = np.unique(k["cand"][k["cand"] >= 0])
        mapa = np.full(len(frag), -1, dtype="int64")
        mapa[usados] = np.arange(len(usados))
        compacto = np.where(k["cand"] >= 0, mapa[np.maximum(k["cand"], 0)], -1)
        textos = [TX.contenido(c, int(frag.doc.iat[u]))[int(frag.c0.iat[u]):int(frag.c1.iat[u])] for u in usados]
        self.log(f"Intervalos anunciados selectivos: {len(inter)}; fragmentos usados: {len(usados)}.")
        emb = TX.codificar(textos, self.cfg_texto, self.salida / "texto_vectores" / "vectores_selectivos.npy", self.dev, self.log, prueba=bool(self.rapido))
        del emb
        np.savez_compressed(car / "candidatos.npz", dias=dias.strftime("%Y-%m-%d").to_numpy().astype("U10"), cand=compacto.astype("int32"),
                            feat=k["feat"].astype("float16"), fuente=k["fuente"], rasgos=np.array(TX.RASGOS))
        (car / "vectores.txt").write_text(str(self.salida / "texto_vectores" / "vectores_selectivos.npy"), encoding="utf-8")
        meta = c[["id", "fuente", "familia_documental", "titulo"]].assign(disp=c.disp.dt.tz_convert(TZ).dt.strftime("%Y-%m-%d %H:%M"))
        inter.join(meta, on="doc").drop(columns=["doc"]).to_parquet(car / "intervalos.parquet", index=False)
        cub = (compacto >= 0).any(1)
        res = dict(disponibilidad=self.col, corpus_sha256=h, documentos=int(len(c)), por_familia={f"{a}|{b}": int(v) for (a, b), v in c.groupby(["fuente", "familia_documental"]).size().items()},
                   intervalos=int(len(inter)), fragmentos_usados=int(len(usados)), fuentes=fuentes, reservas=k["reservas"],
                   dias_cubiertos_pct={str(a): float(100 * cub[dias.year == a].mean()) for a in sorted(set(dias.year))},
                   intervalos_por_fuente=inter.join(meta, on="doc").fuente.value_counts().to_dict() if len(inter) else {})
        (car / "resumen.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        self.log(f"Días cubiertos por anuncios selectivos (%): { {a: round(v, 1) for a, v in res['dias_cubiertos_pct'].items()} }")
        return res

    def _config(self) -> dict:
        return leer_json(self.salida / "corrector" / "busqueda" / "configuracion_elegida.json")

    def selectivo(self):
        cp, p = self.corrida(), self._config()
        for anio in self.anios():
            for s in self.semillas():
                cp._una("selectivo", "selectivo", p, s, anio, self.col, 0, modelo="oficial")

    def placebo(self):
        cp, p = self.corrida(), self._config()
        for d in self.desplazamientos():
            for anio in self.anios():
                for s in self.semillas():
                    cp._una("placebo", f"selectivo_desalineado_{d}", p, s, anio, self.col, d, modelo="oficial")

    # ------------------------------------------------------------------ evaluación y episodios
    def _delta(self, raiz: Path, etapa: str, variante: str, s: int) -> np.ndarray:
        return np.concatenate([np.load(raiz / "corrector" / etapa / variante / f"anio_{a}" / f"semilla_{s}" / "delta.npy") for a in self.anios()])

    def evaluacion(self) -> dict:
        q = self.datos.q168
        acum = {k: [] for k in ["E", "C+R", "num_horario", "selectivo"] + [f"d{d}" for d in self.desplazamientos()]}
        resid, deltas = [], {"num_horario": [], "selectivo": []}
        base = None
        for s in self.semillas():
            z = np.load(self.salida / "cr" / f"semilla_{s}.npz")
            m = np.isin(z["anio"], self.anios())
            if base is None:
                base = dict(dias=z["dia"][m], anio=z["anio"][m])
            elif not np.array_equal(base["dias"], z["dia"][m]):
                raise RuntimeError("Las semillas no comparten orígenes")
            y, ycr = z["y"][m].astype("float64"), z["yhat_cr"][m].astype("float64")
            d_num = self._delta(self.rc, "variantes", "num_horario", s)
            d_sel = self._delta(self.salida, "selectivo", "selectivo", s)
            acum["E"].append(np.abs(y - z["yhat_e"][m]) / q)
            acum["C+R"].append(np.abs(y - ycr) / q)
            acum["num_horario"].append(np.abs(y - ycr * (1 + d_num)) / q)
            acum["selectivo"].append(np.abs(y - ycr * (1 + d_sel)) / q)
            for d in self.desplazamientos():
                acum[f"d{d}"].append(np.abs(y - ycr * (1 + self._delta(self.salida, "placebo", f"selectivo_desalineado_{d}", s))) / q)
            resid.append(((y - ycr) / ycr).mean(1))
            deltas["num_horario"].append(d_num.mean(1))
            deltas["selectivo"].append(d_sel.mean(1))
        err = {k: np.mean(v, axis=0).mean(1) for k, v in acum.items()}
        err["desalineado"] = np.mean([err[f"d{d}"] for d in self.desplazamientos()], axis=0)
        an = np.asarray(base["anio"])
        dias = pd.to_datetime(base["dias"])
        cand = np.load(self.salida / "texto" / "candidatos.npz")
        pos = {d: i for i, d in enumerate(cand["dias"])}
        cub = (cand["cand"][[pos[d] for d in base["dias"]]] >= 0).any(1)
        B = self.plan["evaluacion"]["remuestreos"] if not self.rapido else 199
        filas = []
        for nombre, msk in (("global", np.ones(len(an), dtype=bool)), ("dias_cubiertos", cub)):
            if msk.sum() < 20:
                continue
            idx = EV.indices_bootstrap(an[msk], B, self.plan["evaluacion"]["bloque_dias"], 20261122)
            for a, b in (("selectivo", "num_horario"), ("selectivo", "desalineado")):
                filas.append(dict(subconjunto=nombre, A=a, B=b, n_origenes=int(msk.sum()), **EV.contraste(err[a][msk], err[b][msk], idx)))
        t = pd.DataFrame(filas)
        if len(t):
            t["p_holm"] = EV.holm(t.p_unilateral.tolist())
        out = self.salida / "evaluacion"
        out.mkdir(exist_ok=True)
        t.to_csv(out / "contrastes.csv", index=False)
        # episodios
        r_med = np.mean(resid, axis=0)
        dmed = {k: np.mean(v, axis=0) for k, v in deltas.items()}
        inter = pd.read_parquet(self.salida / "texto" / "intervalos.parquet")
        ep_filas, docs = [], []
        for ep in self.plan["episodios"]:
            dd = pd.DatetimeIndex(sorted({x for a, b in ep["rangos"] for x in pd.date_range(a, b)}))
            msk = dias.isin(dd)
            fila = dict(episodio=ep["nombre"], dias_en_evaluacion=int(msk.sum()), dias_cubiertos=int((cub & msk).sum()))
            if msk.any():
                fila.update({f"MASE_{k}": float(err[k][msk].mean()) for k in ("E", "C+R", "num_horario", "selectivo", "desalineado")})
                fila["reduccion_selectivo_vs_num_horario_pct"] = float(100 * (err["num_horario"][msk].mean() - err["selectivo"][msk].mean()) / err["num_horario"][msk].mean())
                fila["residuo_medio_CR_pct"] = float(100 * r_med[msk].mean())
                fila["correccion_media_selectivo_pct"] = float(100 * dmed["selectivo"][msk].mean())
                fila["correccion_media_num_horario_pct"] = float(100 * dmed["num_horario"][msk].mean())
            ep_filas.append(fila)
            ini = dd.min()
            cubre = inter[(pd.to_datetime(inter.fin) >= ini) & (pd.to_datetime(inter.inicio) <= dd.max())]
            for x in cubre.itertuples():
                disp = pd.Timestamp(x.disp)
                docs.append(dict(episodio=ep["nombre"], fuente=x.fuente, familia=x.familia_documental, titulo=str(x.titulo)[:160], disponible=str(disp),
                                 inicio_anunciado=str(x.inicio), fin_anunciado=str(x.fin), antelacion_dias=int((ini - disp.normalize()).days)))
            self._figura(ep, dias, r_med, dmed, cub, out)
        pd.DataFrame(ep_filas).to_csv(out / "episodios.csv", index=False)
        pd.DataFrame(docs).to_csv(out / "episodios_documentos.csv", index=False)
        res = dict(contrastes=t.to_dict("records"), episodios=ep_filas, MASE={k: float(v.mean()) for k, v in err.items()},
                   dias_cubiertos=int(cub.sum()), n_origenes=int(len(an)), prueba_rapida=bool(self.rapido), alcance=self.plan["evaluacion"]["alcance"])
        guardar_json(out / "resultado.json", res)
        self._informe(t, ep_filas, docs, res)
        return res

    def _figura(self, ep: dict, dias, r, dmed, cub, out: Path):
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        dd = [pd.date_range(a, b) for a, b in ep["rangos"]]
        lo, hi = min(x.min() for x in dd) - pd.Timedelta(days=21), max(x.max() for x in dd) + pd.Timedelta(days=21)
        m = (dias >= lo) & (dias <= hi)
        if not m.any():
            return
        fig, ax = plt.subplots(figsize=(9, 3.6))
        for x in dd:
            ax.axvspan(x.min(), x.max() + pd.Timedelta(days=1), color="#999999", alpha=0.25, lw=0)
        ax.axhline(0, color="#444444", lw=0.8)
        ax.plot(dias[m], 100 * r[m], color="#1f4e79", lw=1.6, label="residuo de E + C+R")
        ax.plot(dias[m], 100 * dmed["num_horario"][m], color="#c55a11", lw=1.2, label="corrección numérica horaria")
        ax.plot(dias[m], 100 * dmed["selectivo"][m], color="#548235", lw=1.2, ls="--", label="corrección con anuncios selectivos")
        ax.scatter(dias[m][cub[m]], np.full(int(cub[m].sum()), ax.get_ylim()[0]), marker="|", color="#548235", s=40, label="día con anuncio")
        ax.set_ylabel("% de la demanda (media del día)")
        ax.set_title(ep["titulo"], fontsize=11)
        ax.legend(fontsize=8, loc="best", frameon=False)
        fig.autofmt_xdate()
        fig.tight_layout()
        fig.savefig(out / f"episodio_{ep['nombre']}.png", dpi=140)
        plt.close(fig)

    def _informe(self, t, ep, docs, res):
        lin = ["# Opción 3: episodios con anuncios oficiales selectivos (exploratorio, desarrollo 2019-2021)", "",
               f"Orígenes: {res['n_origenes']}; días cubiertos por algún anuncio selectivo: {res['dias_cubiertos']}.", "",
               "| Subconjunto | A frente a B | MASE A | MASE B | Reducción | IC 95 % | p Holm |", "|---|---|---|---|---|---|---|"]
        lin += [f"| {x.subconjunto} | {x.A} frente a {x.B} | {x.MASE_A:.4f} | {x.MASE_B:.4f} | {x.reduccion_pct:.2f} % | [{x.ic95_inf:.2f}; {x.ic95_sup:.2f}] | {x.p_holm:.4f} |"
                for x in t.itertuples()]
        lin += ["", "Episodios (descriptivos, sin inferencia):", "", "| Episodio | Días | Con anuncio | MASE C+R | MASE num. horario | MASE selectivo | Residuo medio | Corrección selectiva |",
                "|---|---|---|---|---|---|---|---|"]
        for e in ep:
            if "MASE_C+R" in e:
                lin.append(f"| {e['episodio']} | {e['dias_en_evaluacion']} | {e['dias_cubiertos']} | {e['MASE_C+R']:.4f} | {e['MASE_num_horario']:.4f} | {e['MASE_selectivo']:.4f} | "
                           f"{e['residuo_medio_CR_pct']:.2f} % | {e['correccion_media_selectivo_pct']:.2f} % |")
        lin += ["", f"Documentos que anunciaban algún día de un episodio: {len(docs)} (lista en evaluacion/episodios_documentos.csv).", "", f"Alcance: {res['alcance']}"]
        (self.salida / "RESUMEN_EPISODIOS.md").write_text("\n".join(lin) + "\n", encoding="utf-8")

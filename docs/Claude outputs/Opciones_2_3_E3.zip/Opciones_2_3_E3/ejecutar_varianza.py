"""Opción 2: recetas de reducción de varianza con capacidad igualada (destilación del ensamble, varias cabezas con
remuestreo y recalibración por hora) sobre E y PatchTST N, en la partición de desarrollo. Ver LEEME.txt y config/plan_varianza.json.

No se llama directamente: use EXPLORAR_WINDOWS.bat o explorar_linux.sh, que preparan el entorno.

    python ejecutar_varianza.py                          todas las etapas -> resultados_varianza_e3 (reanudable)
    python ejecutar_varianza.py --etapas profesores   solo entrena los maestros
    python ejecutar_varianza.py --prueba-rapida       todo en minutos con pocos datos; no produce resultados válidos
Etapas: verificar profesores estudiantes exportabilidad decision
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import subprocess
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_varianza.json").read_text(encoding="utf-8"))
ETAPAS = ["verificar", "profesores", "estudiantes", "exportabilidad", "decision"]

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
sys.path.insert(0, str(RAIZ / "src"))

import numpy as np          # noqa: E402
import pandas as pd         # noqa: E402
import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from entrenamiento import protocolo as PR                             # noqa: E402
from entrenamiento import protocolo_e2 as P2                          # noqa: E402
from entrenamiento import pruebas                                      # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256                # noqa: E402
from exploracion import mecanismos as EX                              # noqa: E402
from varianza.protocolo import Varianza                               # noqa: E402

ASCII = os.name == "nt"
RAPIDO = dict(max_epocas=2, n_tr=96, n_es=24, n_ev=32, finalistas=1, semillas_diseno=[101, 102], configuraciones=[1, 2], lote_evaluacion=16)


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + sorted((RAIZ / "data").rglob("*.*"))
    rutas += [RAIZ / "ejecutar_varianza.py"] + sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts)
    rutas += sorted((RAIZ / "tests").glob("*.py"))
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.is_file()}


def entorno(dispositivo: str) -> dict:
    e = dict(python=platform.python_version(), sistema=platform.platform(), procesador=platform.processor() or platform.machine(), nucleos=os.cpu_count(),
             torch=torch.__version__, numpy=np.__version__, dispositivo=dispositivo, cuda_disponible=torch.cuda.is_available(), cuda=torch.version.cuda,
             determinismo=dict(cudnn_deterministic=True, cudnn_benchmark=False, CUBLAS_WORKSPACE_CONFIG=os.environ.get("CUBLAS_WORKSPACE_CONFIG")))
    if torch.cuda.is_available():
        e.update(gpu=torch.cuda.get_device_name(0), memoria_gpu_gb=round(torch.cuda.get_device_properties(0).total_memory / 2**30, 1))
    for m in ("pandas", "scipy", "onnx", "onnxruntime", "mlflow"):
        try:
            e[m] = __import__(m).__version__
        except Exception:
            e[m] = None
    return e


def verificar(salida: Path, log) -> dict:
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", str(RAIZ / "tests"), "-p", "no:cacheprovider"], capture_output=True, text=True, cwd=RAIZ)
    (salida / "pytest.txt").write_text(r.stdout + "\n" + r.stderr, encoding="utf-8")
    ult = (r.stdout.strip().splitlines() or ["sin salida"])[-1]
    log(f"Pruebas unitarias: {ult}")
    return dict(codigo=r.returncode, resumen=ult)


def empaquetar(salida: Path, log) -> list[Path]:
    sello = dt.datetime.now().strftime("%Y%m%d_%H%M")
    pesados = lambda r: r.suffix in (".pt", ".npy", ".onnx") or r.name == "mlflow.db" or "mlruns" in r.parts   # noqa: E731
    z1, z2 = RAIZ / f"ENVIAR_resultados_varianza_{sello}.zip", RAIZ / f"ENVIAR_pesos_varianza_{sello}.zip"
    for destino, criterio, nivel in ((z1, lambda r: not pesados(r), zipfile.ZIP_DEFLATED), (z2, pesados, zipfile.ZIP_STORED)):
        with zipfile.ZipFile(destino, "w", nivel, allowZip64=True) as z:
            for r in sorted(salida.rglob("*")):
                if r.is_file() and criterio(r):
                    z.write(r, Path(salida.name) / r.relative_to(salida))
    log(f"Archivos para enviar: {z1.name} ({z1.stat().st_size / 2**20:.1f} MB) y {z2.name} ({z2.stat().st_size / 2**20:.1f} MB)")
    return [z1, z2]


def main() -> int:
    ap = argparse.ArgumentParser(description="Opción 2: recetas de varianza del Entregable 3 (solo pliegues de desarrollo)")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=None)
    ap.add_argument("--bases", nargs="+", choices=list(PLAN["bases"]), default=None, help="solo estas bases en la rejilla (para repartir el cómputo)")
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--hilos", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)))
    ap.add_argument("--sin-mlflow", action="store_true")
    ap.add_argument("--sin-empaquetar", action="store_true")
    a = ap.parse_args()
    if a.etapas is None:
        a.etapas = list(ETAPAS)
    if a.bases:                       # con un subconjunto de bases solo se entrena; la agregación y la decisión necesitan la rejilla completa
        a.etapas = [e for e in a.etapas if e != "decision"]
    rapido = dict(RAPIDO) if a.prueba_rapida else None
    salida = RAIZ / ("resultados_prueba_rapida_varianza" if rapido else "resultados_varianza_e3")
    salida.mkdir(exist_ok=True)
    log = Bitacora(salida / "bitacora.log")
    if rapido is None and a.dispositivo == "auto" and not torch.cuda.is_available():
        log("AVISO: no se detecta GPU; la exploración completa en CPU puede tardar varios días.")
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    if dispositivo == "cuda" and not torch.cuda.is_available():
        dispositivo = "cpu"
    torch.set_num_threads(a.hilos)
    gpu = f" ({torch.cuda.get_device_name(0)})" if dispositivo == "cuda" else ""
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if rapido else 'EXPLORACIÓN'} -> {salida.name} | etapas {a.etapas} | bases {a.bases or 'todas'} | dispositivo {dispositivo}{gpu}")
    t_ini = time.time()
    h = huellas()
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg["huellas_sha256"]) if reg["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: estos archivos cambiaron después de iniciar: {cambiados}. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar: plan, regla de decisión, semillas y código quedan fijados por las huellas.",
                   creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), plan=PLAN["version"], prueba_rapida=bool(rapido),
                   huellas_sha256=h, reanudaciones=[], prueba_2022_2025="no se lee en ninguna etapa")
    PR.guardar_json(rreg, reg)
    PR.guardar_json(salida / f"entorno_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", entorno(dispositivo))

    log("Cargando el panel principal (SHA-256)...")
    datos = DatosNumericos(RAIZ)
    comp = pruebas.numericas(datos)
    PR.guardar_json(salida / "comprobaciones_previas.json", comp)
    if not all(comp.values()):
        log(f"ERROR: fallaron comprobaciones previas {[k for k, v in comp.items() if not v]}. No se entrena.")
        return 4
    resumen = PR.leer_json(salida / "RESUMEN.json") if (salida / "RESUMEN.json").exists() else {}
    if "verificar" in a.etapas:
        resumen["verificar"] = verificar(salida, log)
        if resumen["verificar"]["codigo"] != 0:
            log("ERROR: fallaron las pruebas unitarias (ver pytest.txt). No se entrena.")
            PR.guardar_json(salida / "RESUMEN.json", resumen)
            return 5
    ex = Varianza(RAIZ, salida, PLAN, datos, dispositivo, log, rapido, a)
    for etapa in [e for e in ETAPAS if e in a.etapas and e != "verificar"]:
        log(f"---- Etapa: {etapa}")
        with tqdm(total=None, desc=f"Exploración {etapa}", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
            ex.barra = barra
            if etapa == "profesores":
                resumen["profesores"] = ex.profesores()
            elif etapa == "estudiantes":
                resumen["estudiantes"] = ex.estudiantes().groupby("celda").MASE.mean().to_dict()
            elif etapa == "exportabilidad":
                resumen["exportabilidad"] = {k: v.get("exportable") for k, v in ex.exportabilidad().items()}
            elif etapa == "decision":
                resumen["decision"] = {k: v for k, v in ex.decision().items() if k != "contrastes"}
        PR.guardar_json(salida / "RESUMEN.json", resumen)
    log(f"Etapas terminadas en {(time.time() - t_ini) / 3600:.2f} h.")
    if not a.sin_empaquetar and "decision" in a.etapas:
        empaquetar(salida, log)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Opción 3: estudio de episodios con anuncios oficiales selectivos (exploratorio). Ver LEEME.txt y config/plan_episodios.json.

No se llama directamente: use EPISODIOS_WINDOWS.bat, que prepara el entorno.

    python ejecutar_episodios.py [--corpus RUTA] [--resultados-corrector RUTA]    todas las etapas -> resultados_episodios_e3
    python ejecutar_episodios.py --prueba-rapida                                   pocos datos y un codificador de prueba
Etapas: verificar seleccion selectivo placebo evaluacion
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_episodios.json").read_text(encoding="utf-8"))
PLAN_C = json.loads((RAIZ / "config" / "plan_corrector.json").read_text(encoding="utf-8"))
ETAPAS = ["verificar", "seleccion", "selectivo", "placebo", "evaluacion"]
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
sys.path.insert(0, str(RAIZ / "src"))

import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from entrenamiento import protocolo as PR                            # noqa: E402
from entrenamiento import pruebas                                    # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256               # noqa: E402
from episodios.protocolo import Episodios                            # noqa: E402

RAPIDO = dict(max_epocas=2, semillas=[101, 102], anios_evaluacion=[2020, 2021], primer_anio_ajuste=2016, desplazamientos=[49], docs_por_anio=300)


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + sorted((RAIZ / "data").rglob("*.*")) + [RAIZ / "ejecutar_episodios.py"]
    rutas += sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts) + sorted((RAIZ / "tests").glob("*.py"))
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.is_file()}


def main() -> int:
    ap = argparse.ArgumentParser(description="Opción 3: episodios con anuncios oficiales selectivos (exploratorio)")
    ap.add_argument("--corpus", default=PLAN_C["texto"]["ruta_por_defecto"])
    ap.add_argument("--resultados-corrector", default=PLAN["resultados_corrector_por_defecto"],
                    help="carpeta resultados_corrector_e3 del corrector semántico (results/corrector_semantico_e3_20261122 del repositorio)")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=None)
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--hilos", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)))
    ap.add_argument("--codificador", default=None)
    ap.add_argument("--sin-empaquetar", action="store_true")
    a = ap.parse_args()
    a.etapas = a.etapas or list(ETAPAS)
    rapido = dict(RAPIDO) if a.prueba_rapida else None
    salida = RAIZ / ("resultados_prueba_rapida_episodios" if rapido else "resultados_episodios_e3")
    salida.mkdir(exist_ok=True)
    log = Bitacora(salida / "bitacora.log")
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    torch.set_num_threads(a.hilos)
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if rapido else 'EPISODIOS'} -> {salida.name} | etapas {a.etapas} | dispositivo {dispositivo}")
    rc = Path(a.resultados_corrector)
    faltan = [str(rc / "cr" / f"semilla_{s}.npz") for s in PLAN["corrector"]["semillas"] if not (rc / "cr" / f"semilla_{s}.npz").exists()]
    if faltan or not (rc / "corrector" / "variantes" / "num_horario").exists():
        log(f"ERROR: no encuentro los resultados del corrector semántico en {rc}. Pase --resultados-corrector \"RUTA\\resultados_corrector_e3\".")
        return 2
    if "seleccion" in a.etapas and not Path(a.corpus).exists():
        log(f"ERROR: no encuentro el corpus en {a.corpus}. Pase --corpus \"RUTA\\corpus_texto.parquet\".")
        return 2
    h = huellas()
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            log(f"ERROR: cambiaron archivos del paquete después de iniciar. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar.", plan=PLAN["version"], creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"),
                   huellas_sha256=h, resultados_corrector=str(rc), huellas_insumos_corrector={f"cr/semilla_{s}.npz": sha256(rc / "cr" / f"semilla_{s}.npz")
                                                                                         for s in PLAN["corrector"]["semillas"]},
                   prueba_2022_2025="no se lee (ni su texto)", reanudaciones=[], prueba_rapida=bool(rapido))
    PR.guardar_json(rreg, reg)
    t0 = time.time()
    if "verificar" in a.etapas:
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", str(RAIZ / "tests"), "-p", "no:cacheprovider"], capture_output=True, text=True, cwd=RAIZ)
        (salida / "pytest.txt").write_text(r.stdout + "\n" + r.stderr, encoding="utf-8")
        log(f"Pruebas unitarias: {(r.stdout.strip().splitlines() or ['sin salida'])[-1]}")
        if r.returncode != 0:
            return 5
    datos = DatosNumericos(RAIZ)
    if not all(pruebas.numericas(datos).values()):
        log("ERROR: fallaron las comprobaciones previas del panel.")
        return 4
    cfg_texto = dict(datos.contrato["texto"])
    if a.codificador:
        cfg_texto["encoder"] = a.codificador
    ep = Episodios(salida, PLAN, PLAN_C, datos, dispositivo, log, rapido, a, cfg_texto)
    for etapa in [e for e in ETAPAS if e in a.etapas and e != "verificar"]:
        log(f"---- Etapa: {etapa}")
        with tqdm(total=None, desc=f"Episodios {etapa}", unit="paso", dynamic_ncols=True, ascii=os.name == "nt") as barra:
            ep.barra = barra
            r = getattr(ep, etapa)()
            if etapa == "evaluacion":
                for x in r["contrastes"]:
                    log(f"{x['subconjunto']}: {x['A']} frente a {x['B']}: {x['reduccion_pct']:.2f} % [{x['ic95_inf']:.2f}; {x['ic95_sup']:.2f}], p Holm {x['p_holm']:.4f}")
    log(f"Etapas terminadas en {(time.time() - t0) / 3600:.2f} h.")
    if not a.sin_empaquetar and "evaluacion" in a.etapas:
        z = RAIZ / f"ENVIAR_resultados_episodios_{dt.datetime.now().strftime('%Y%m%d_%H%M')}.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
            for p in sorted(salida.rglob("*")):
                if p.is_file() and "texto_vectores" not in p.parts and not p.name.endswith(".parcial.npz"):
                    f.write(p, Path(salida.name) / p.relative_to(salida))
        log(f"Archivo para enviar: {z.name} ({z.stat().st_size / 2**20:.1f} MB).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

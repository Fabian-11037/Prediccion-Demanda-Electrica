"""Pruebas de los mecanismos de la exploración (G coherencia, H DRO temporal, I codificador periódico, J agregación) y de
los ganchos que añaden al motor común. Datos sintéticos, salvo la alineación de orígenes, que usa el panel (sin la prueba).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import torch

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "src"))
from entrenamiento import motor, redes_e3                             # noqa: E402
from exploracion import agregacion as AG                              # noqa: E402
from exploracion import mecanismos as EX                              # noqa: E402

L, H, NCAL, NX, NM = 168, 24, 6, 8, 2
BASES = {"tats": dict(id=1, nucleo="patchtst", d_model=16, capas=1, cabezas=4, dropout=0.0, lr=1e-3, weight_decay=0.0, lote=8, d_texto=4),
         "timesnet": dict(id=1, e_layers=1, top_k=2, num_kernels=2, d_model=8, d_ff=8, dropout=0.0, lr=1e-3, weight_decay=0.0, lote=8),
         "original_E": dict(id=1, nucleo="patchtst", d_model=16, capas=1, cabezas=4, dropout=0.0, lr=1e-3, weight_decay=0.0, lote=8, rho=0.05,
                            ancho_correccion=16),
         "periodica": dict(id=1, d_model=8, bloques=2, dropout=0.0, lr=1e-3, weight_decay=0.0, lote=8)}
COH, DRO = dict(mec_mu=1.0, mec_lam=0.5), dict(mec_tau=0.1, mec_vida=3.0, mec_beta=0.9)


def red(base, extra=None):
    torch.manual_seed(0)
    return redes_e3.construir("x_" + base, dict(BASES[base], **(extra or {})), NX, NCAL, L, H, n_mascaras=NM)


def lote(B=6, hc=H, semilla=0):
    g = torch.Generator().manual_seed(semilla)
    x = torch.randn(B, L, NX, generator=g)
    x[:, :, -NM:] = 0.0
    return x, torch.randn(B, L, NCAL, generator=g), torch.randn(B, hc, NCAL, generator=g), torch.arange(B) + 10


def tensores(B=12, hc=H, semilla=0):
    x, cp, cf, d = lote(B, hc, semilla)
    sig = torch.arange(1, B + 1)
    sig[-1] = -1
    sig[5] = -1                                  # un hueco: el origen 6 no sigue al 5
    return dict(x=x, cal_p=cp, cal_f=cf, dia=d, y=1 + 0.05 * torch.randn(B, H), nivel=1 + 0.1 * torch.rand(B), sig=sig,
                grupo=torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3]))


@pytest.mark.parametrize("base", list(BASES))
def test_sin_mecanismo_es_la_base(base):
    assert not isinstance(red(base), EX.Envoltura)


@pytest.mark.parametrize("base", list(BASES))
def test_coherencia_salida_de_H_y_base_de_2H(base):
    m = red(base, COH).eval()
    x, cp, cf, d = lote(hc=2 * H)
    with torch.no_grad():
        o = m(x, cp, cf, d)
        completo = m.base(x, cp, cf, d)
    assert o.shape == (6, H) and completo.shape == (6, 2 * H)
    assert torch.allclose(o, completo[:, :H])
    assert EX.horizonte_calendario(dict(BASES[base], **COH), H) == 2 * H and EX.horizonte_calendario(BASES[base], H) == H


def test_coherencia_usa_solo_pares_validos_y_objetivo_sin_gradiente():
    m = red("tats", dict(mec_mu=0.0, mec_lam=1.0)).train()
    t = tensores(hc=2 * H)
    ix = torch.arange(12)
    usados = []
    orig = m.base.forward

    def espia(x, cp, cf, d):
        usados.append((x.shape[0], torch.is_grad_enabled()))
        return orig(x, cp, cf, d)
    m.base.forward = espia
    m(t["x"][ix], t["cal_p"][ix], t["cal_f"][ix], t["dia"][ix])
    perd = m.perdida_adicional(t, ix)
    assert perd.requires_grad and float(perd) > 0
    assert usados == [(12, True), (10, False)]              # 10 pares válidos; el objetivo del día siguiente va sin gradiente
    assert m.base.training


def test_coherencia_es_cero_si_el_dia_2_coincide_con_el_siguiente():
    class Fija(torch.nn.Module):          # pronóstico que depende solo del día: ŷ_d[H:2H] = ŷ_{d+1}[0:H] por construcción
        def forward(self, x, cp, cf, d):
            v = d.float()[:, None]
            return torch.cat([v.expand(-1, H), (v + 1).expand(-1, H)], dim=1) * 0.01 + x[:, :1, 0] * 0

        def diagnostico(self):
            return {}
    m = EX.Envoltura(Fija(), H, dict(mu=0.0, lam=1.0)).train()
    t = tensores(hc=2 * H)
    t["nivel"] = torch.ones(12)
    t["dia"] = torch.arange(12)
    ix = torch.arange(12)
    m(t["x"], t["cal_p"], t["cal_f"], t["dia"])
    assert float(m.perdida_adicional(t, ix)) < 1e-5


def test_dro_con_prior_uniforme_y_tau_grande_promedia_grupos():
    m = red("tats", dict(mec_tau=1e6, mec_vida=1e9, mec_beta=0.0))
    t = tensores()
    ix = torch.arange(12)
    salida = torch.ones(12, H)
    err = (salida - t["y"]).abs().mean(1)
    esperado = torch.stack([err[t["grupo"] == g].mean() for g in range(4)]).mean()
    assert torch.allclose(m.perdida_principal(salida, t, ix), esperado, atol=1e-6)
    assert abs(float(m._q.sum()) - 1) < 1e-6


def test_dro_pesa_mas_el_grupo_con_mas_error_y_la_recencia():
    m = red("tats", dict(mec_tau=0.1, mec_vida=1e9, mec_beta=0.0))
    t = tensores()
    t["y"] = torch.ones(12, H)
    salida = torch.ones(12, H)
    salida[t["grupo"] == 1] += 0.2
    salida[t["grupo"] != 1] += 0.1
    m.perdida_principal(salida, t, torch.arange(12))
    assert int(m._q.argmax()) == 1
    r = red("tats", dict(mec_tau=1e6, mec_vida=1.0, mec_beta=0.0))
    r.perdida_principal(torch.ones(12, H), t, torch.arange(12))
    assert torch.all(r._q[1:] > r._q[:-1])                    # con pérdidas iguales manda la prior: años recientes pesan más


def test_motor_entrena_con_coherencia_y_dro():
    m = red("tats", dict(COH, **DRO))
    t = tensores(B=12, hc=2 * H)
    info = motor.entrenar(m, t, t, dict(BASES["tats"], lote=6), 1, dict(max_epocas=2, min_epocas=1, paciencia=5, recorte_gradiente=1.0))
    assert info["epocas"] == 2 and np.isfinite(info["mejor_perdida_parada"])
    assert "dro_peso_maximo" in m.diagnostico()


@pytest.mark.parametrize("hh", [H, 2 * H])
def test_periodica_formas_y_gradiente(hh):
    m = EX.Periodica7x24(BASES["periodica"], NX, NCAL, L, hh)
    x, cp, cf, d = lote(hc=hh)
    o = m(x, cp, cf, d)
    assert o.shape == (6, hh) and torch.allclose(o, torch.ones_like(o))      # cabeza en cero: arranca en el nivel
    (o.sum() + sum(p.sum() for p in m.parameters()) * 0).backward()
    with pytest.raises(ValueError):
        EX.Periodica7x24(BASES["periodica"], NX, NCAL, 100, H)


def test_periodica_onnx_con_otra_entrada(tmp_path):
    ort = pytest.importorskip("onnxruntime")
    m = EX.Periodica7x24(BASES["periodica"], NX, NCAL, L, H)
    for p in m.lectura[-1].parameters():
        torch.nn.init.normal_(p)
    m.eval()
    a, b = lote(4, semilla=1), lote(5, semilla=2)
    ruta = tmp_path / "p.onnx"
    torch.onnx.export(m, a, str(ruta), input_names=["x", "cal_p", "cal_f", "dia"], output_names=["y"], opset_version=17,
                      dynamic_axes={k: {0: "lote"} for k in ("x", "cal_p", "cal_f", "dia", "y")}, dynamo=False)
    s = ort.InferenceSession(str(ruta), providers=["CPUExecutionProvider"])
    nombres = {i.name for i in s.get_inputs()}
    feed = {k: v.numpy() for k, v in zip(["x", "cal_p", "cal_f", "dia"], b) if k in nombres}
    with torch.no_grad():
        assert np.abs(s.run(None, feed)[0] - m(*b).numpy()).max() < 1e-4


def _expertos(K=4, n_es=60, n_v=50, semilla=0):
    g = np.random.default_rng(semilla)
    y = 1000 + 100 * g.standard_normal((n_es + n_v, H))
    P = y[None] + g.normal(0, 1, (K, 1, 1)) * 30 + g.normal(0, 40, (K, n_es + n_v, H)) * np.arange(1, K + 1)[:, None, None]
    return P[:, :n_es], y[:n_es], P[:, n_es:], y[n_es:]


@pytest.mark.parametrize("semilla", range(5))
def test_prop_J_anclada_no_empeora_al_ancla_mas_que_beta_por_ewa(semilla):
    Pe, ye, Pv, yv = _expertos(semilla=semilla)
    pron, info = AG.reglas(Pe, ye, Pv, yv, q168=50.0)
    assert all(info["cota_verificada"].values())
    mae = lambda p: np.abs(yv - p).mean()                    # noqa: E731
    for b in (0.25, 0.5):
        assert mae(pron[f"anclada_{b:g}"]) <= mae(pron["mejor"]) + b * (mae(pron["ewa"]) - mae(pron["mejor"])) + 1e-9


def test_ewa_es_causal_con_retraso():
    Pe, ye, Pv, yv = _expertos()
    P, y = np.concatenate([Pe, Pv], 1), np.concatenate([ye, yv])
    _, w = AG.ewa_en_linea(P, y, 50.0, retraso=2, cota=5.0)
    t = 80
    y2 = y.copy()
    y2[t - 1:] += 500.0                                       # cambiar el futuro y el día t - 1 (incompleto) no mueve los pesos de t
    _, w2 = AG.ewa_en_linea(P, y2, 50.0, retraso=2, cota=5.0)
    assert np.allclose(w[: t + 1], w2[: t + 1])
    y3 = y.copy()
    y3[t - 2] += 500.0
    _, w3 = AG.ewa_en_linea(P, y3, 50.0, retraso=2, cota=5.0)
    assert not np.allclose(w[t], w3[t])


def test_alineacion_de_origenes_y_calendario_de_48h():
    from entrenamiento.datos import DatosNumericos
    d = DatosNumericos(RAIZ)
    f = next(x for x in d.pliegues() if x["anio"] == 2018)
    esc = d.ajustar_escalas(f["tr"])
    c = d.construir(f["tr"][-400:], esc, h_cal=48)
    assert c.cal_f.shape[1] == 48 and c.y.shape[1] == 24
    i = np.flatnonzero(c.sig >= 0)
    assert len(i) > 300
    assert ((c.origen[c.sig[i]] - c.origen[i]) == np.timedelta64(1, "D")).all()
    assert np.allclose(c.cal_f[i, 24:], c.cal_f[c.sig[i], :24])         # el calendario del día 2 es el del origen siguiente
    assert np.allclose(c.y[i][:, :0].shape, (len(i), 0))
    c24 = d.construir(f["tr"][-400:], esc)
    assert np.array_equal(c24.cal_f, c.cal_f[:, :24]) and np.array_equal(c24.x, c.x)
    assert c.sig.max() < len(c) and c.grupo.min() == 0

"""Pruebas de las recetas de varianza: destilación alineada, varias cabezas con remuestreo y recalibración por hora."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import torch

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "src"))
sys.path.insert(0, str(RAIZ / "tests"))
from entrenamiento import motor, redes_e3                             # noqa: E402
from exploracion import mecanismos as EX                              # noqa: E402
from test_exploracion import BASES, H, NCAL, NM, NX, L, lote, tensores   # noqa: E402
from varianza import protocolo as VP                                  # noqa: E402


def red(base="tats", extra=None):
    torch.manual_seed(0)
    return redes_e3.construir("x_" + base, dict(BASES[base], **(extra or {})), NX, NCAL, L, H, n_mascaras=NM)


def _maestro(tmp_path, t, desplazar=0.0):
    ruta = tmp_path / "maestro.npz"
    np.savez(ruta, prof_norm=(t["y"].numpy() + 0.01).astype("float32"), y_norm=(t["y"].numpy() + desplazar).astype("float32"))
    return str(ruta)


def test_destilacion_es_la_base_en_inferencia_y_mezcla_las_perdidas(tmp_path):
    t = tensores()
    m = red(extra=dict(rec_destilar=_maestro(tmp_path, t), rec_alfa=0.5))
    assert isinstance(m, EX.Destilacion) and m.n_parametros() == red().n_parametros()
    salida = t["y"].clone()
    ix = torch.arange(12)
    assert float(m.perdida_principal(salida, t, ix)) == pytest.approx(0.5 * 0.01, abs=1e-6)
    info = motor.entrenar(m, t, t, dict(BASES["tats"], lote=4, rec_destilar=m.ruta, rec_alfa=0.5), 1, dict(max_epocas=2, min_epocas=1, paciencia=5, recorte_gradiente=1.0))
    assert info["epocas"] == 2


def test_destilacion_rechaza_un_maestro_desalineado(tmp_path):
    t = tensores()
    m = red(extra=dict(rec_destilar=_maestro(tmp_path, t, desplazar=0.5), rec_alfa=0.5))
    with pytest.raises(RuntimeError):
        m.perdida_principal(t["y"].clone(), t, torch.arange(12))


@pytest.mark.parametrize("base", ["tats", "original_E", "periodica"])
def test_multicabeza_formas_media_y_parametros(base):
    m = red(base, dict(rec_cabezas=3, rec_semilla_cabezas=5)).train()
    x, cp, cf, d = lote()
    o = m(x, cp, cf, d)
    assert o.shape == (6, H) and m._ult.shape == (6, 3, H)
    assert torch.allclose(o, m._ult.mean(1))
    assert m.n_parametros() < 3 * red(base).n_parametros()          # el tronco es compartido


def test_multicabeza_pesos_poisson_fijos_y_perdida_ponderada():
    m = red(extra=dict(rec_cabezas=3, rec_semilla_cabezas=7)).train()
    t = tensores()
    ix = torch.arange(12)
    s = m(t["x"], t["cal_p"], t["cal_f"], t["dia"])
    l1 = m.perdida_principal(s, t, ix)
    w1 = m._w.clone()
    m.perdida_principal(s, t, ix)
    assert torch.equal(w1, m._w) and w1.shape == (12, 3)
    err = (m._ult - t["y"][:, None, :]).abs().mean(2)
    assert float(l1) == pytest.approx(float((w1 * err).sum() / w1.sum()), rel=1e-5)


def test_escala_y_apilamiento():
    rng = np.random.default_rng(0)
    y = 1000 + rng.normal(0, 50, (80, 24))
    p = y / 1.05
    e = VP.escala_por_hora(p, y)
    assert np.allclose(e, 1.05, atol=1e-6)
    W = VP.apilar(np.stack([p, p * 0 + 1000]), y)
    assert W.shape == (2, 24) and (W >= 0).all()

"""Pruebas de las recetas de la exploración de E: media exponencial de pesos, SWA con recalibración de la normalización
por lotes y ponderación fija por recencia."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "src"))
sys.path.insert(0, str(RAIZ / "tests"))
from entrenamiento import motor, redes_e3                             # noqa: E402
from exploracion import mecanismos as EX                              # noqa: E402
from test_exploracion import BASES, H, NCAL, NM, NX, L, tensores      # noqa: E402

OPC = dict(max_epocas=3, min_epocas=3, paciencia=9, recorte_gradiente=1.0)


def red(base="tats", extra=None):
    torch.manual_seed(0)
    return redes_e3.construir("x_" + base, dict(BASES[base], **(extra or {})), NX, NCAL, L, H, n_mascaras=NM)


@pytest.mark.parametrize("receta", [dict(rec_promedio="ema", rec_epocas_ema=1.0), dict(rec_promedio="swa", rec_inicio=1)])
def test_receta_no_cambia_la_arquitectura_y_entrena(receta):
    m = red(extra=receta)
    assert not isinstance(m, EX.Envoltura)
    assert m.n_parametros() == red().n_parametros()
    t = tensores()
    info = motor.entrenar(m, t, t, dict(BASES["tats"], **receta, lote=4), 1, OPC)
    assert info["epocas"] == 3 and all(torch.isfinite(v).all() for v in m.state_dict().values() if v.dtype.is_floating_point)


def test_ema_restaura_un_estado_distinto_del_entrenamiento_sin_promedio():
    t = tensores()
    a, b = red(), red(extra=dict(rec_promedio="ema", rec_epocas_ema=1.0))
    motor.entrenar(a, t, t, dict(BASES["tats"], lote=4), 1, OPC)
    motor.entrenar(b, t, t, dict(BASES["tats"], lote=4, rec_promedio="ema", rec_epocas_ema=1.0), 1, OPC)
    dif = max(float((a.state_dict()[k] - b.state_dict()[k]).abs().max()) for k in a.state_dict() if a.state_dict()[k].dtype.is_floating_point)
    assert dif > 1e-6


def test_swa_es_la_media_de_los_estados_por_epoca():
    lin = torch.nn.Linear(2, 1)
    estados = []

    class Red(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.l = lin

        def forward(self, x, cp, cf, d):
            return self.l(x[:, 0, :2]).expand(-1, H)
    m = Red()
    t = tensores()
    p = dict(lr=0.1, weight_decay=0.0, lote=12, rec_promedio="swa", rec_inicio=1)
    obs = lambda h: None                                          # noqa: E731
    orig = motor._flotantes

    def espia(r):
        e = orig(r)
        estados.append(e)
        return e
    motor._flotantes = espia
    try:
        motor.entrenar(m, t, t, p, 1, dict(OPC, max_epocas=3, min_epocas=3, paciencia=99), obs)
    finally:
        motor._flotantes = orig
    assert len(estados) > 0


def test_recencia_pesa_mas_los_anios_recientes_y_excluye_dro():
    m = red(extra=dict(mec_rec_vida=1.0))
    t = tensores()
    t["y"] = torch.ones(12, H)
    salida = torch.ones(12, H)
    salida[t["grupo"] == 3] += 0.4                                # error solo en el año más reciente
    l_rec = float(m.perdida_principal(salida, t, torch.arange(12)))
    plano = float((salida - t["y"]).abs().mean())
    assert l_rec > plano                                          # ese año pesa más que en el promedio simple
    w = torch.tensor([2.0 ** -3, 2.0 ** -2, 2.0 ** -1, 1.0])
    esperado = float((w[t["grupo"]] * (salida - t["y"]).abs().mean(1)).sum() / w[t["grupo"]].sum())
    assert abs(l_rec - esperado) < 1e-6
    with pytest.raises(ValueError):
        EX.mecanismos_de(dict(mec_rec_vida=3.0, mec_tau=0.1))


def test_recalibracion_bn_usa_media_exacta():
    bn = torch.nn.BatchNorm1d(3)

    class Red(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.bn = bn

        def forward(self, x, cp, cf, d):
            return self.bn(x[:, 0, :3]).mean(1, keepdim=True).expand(-1, H)
    t = tensores()
    motor._recalibrar_bn(Red(), t, lote=5)
    x = t["x"][:, 0, :3]
    esperado = torch.stack([x[0:5].mean(0), x[5:10].mean(0), x[10:12].mean(0)]).mean(0)   # media acumulada por lote, como swa_utils.update_bn
    assert torch.allclose(bn.running_mean, esperado, atol=1e-5)
    assert bn.momentum == 0.1

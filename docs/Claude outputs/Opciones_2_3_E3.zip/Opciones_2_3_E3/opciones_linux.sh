#!/usr/bin/env bash
# Uso: ./opciones_linux.sh varianza|episodios [argumentos]
set -e
cd "$(dirname "$0")"
PY=$(command -v python3.12 || command -v python3.11 || command -v python3 || true)
[ -z "$PY" ] && { echo "Instale Python 3.10-3.14"; exit 1; }
exec "$PY" lanzar.py "$@"

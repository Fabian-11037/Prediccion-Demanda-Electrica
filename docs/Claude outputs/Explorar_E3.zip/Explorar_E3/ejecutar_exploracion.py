"""Exploración de diseño solo numérica del Entregable 3 (ideas G, H, I y J sobre PatchTST N, TimesNet, E y el codificador
periódico), en la partición de desarrollo. Ver LEEME.txt y config/plan_exploracion.json.

No se llama directamente: use EXPLORAR_WINDOWS.bat o explorar_linux.sh, que preparan el entorno.

    python ejecutar_exploracion.py                       todas las etapas -> resultados_exploracion_e3 (reanudable)
    python ejecutar_exploracion.py --etapas estimar      solo estima el tiempo de cómputo
    python ejecutar_exploracion.py --prueba-rapida       todo en minutos con pocos datos; no produce resultados válidos
Etapas: verificar busqueda_periodica estimar exportabilidad rejilla agregacion decision sensibilidad
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import subprocess
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_exploracion.json").read_text(encoding="utf-8"))
ETAPAS = ["verificar", "busqueda_periodica", "estimar", "exportabilidad", "rejilla", "agregacion", "decision", "sensibilidad"]

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
sys.path.insert(0, str(RAIZ / "src"))

import numpy as np          # noqa: E402
import pandas as pd         # noqa: E402
import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from entrenamiento import protocolo as PR                             # noqa: E402
from entrenamiento import protocolo_e2 as P2                          # noqa: E402
from entrenamiento import pruebas                                      # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256                # noqa: E402
from exploracion import mecanismos as EX                              # noqa: E402
from exploracion.protocolo import Exploracion                         # noqa: E402

ASCII = os.name == "nt"
RAPIDO = dict(max_epocas=2, n_tr=96, n_es=24, n_ev=32, finalistas=1, semillas_diseno=[101, 102], configuraciones=[1, 2], lote_evaluacion=16)


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + sorted((RAIZ / "data").rglob("*.*"))
    rutas += [RAIZ / "ejecutar_exploracion.py"] + sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts)
    rutas += sorted((RAIZ / "tests").glob("*.py"))
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.is_file()}


def entorno(dispositivo: str) -> dict:
    e = dict(python=platform.python_version(), sistema=platform.platform(), procesador=platform.processor() or platform.machine(), nucleos=os.cpu_count(),
             torch=torch.__version__, numpy=np.__version__, dispositivo=dispositivo, cuda_disponible=torch.cuda.is_available(), cuda=torch.version.cuda,
             determinismo=dict(cudnn_deterministic=True, cudnn_benchmark=False, CUBLAS_WORKSPACE_CONFIG=os.environ.get("CUBLAS_WORKSPACE_CONFIG")))
    if torch.cuda.is_available():
        e.update(gpu=torch.cuda.get_device_name(0), memoria_gpu_gb=round(torch.cuda.get_device_properties(0).total_memory / 2**30, 1))
    for m in ("pandas", "scipy", "onnx", "onnxruntime", "mlflow"):
        try:
            e[m] = __import__(m).__version__
        except Exception:
            e[m] = None
    return e


def verificar(salida: Path, log) -> dict:
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", str(RAIZ / "tests"), "-p", "no:cacheprovider"], capture_output=True, text=True, cwd=RAIZ)
    (salida / "pytest.txt").write_text(r.stdout + "\n" + r.stderr, encoding="utf-8")
    ult = (r.stdout.strip().splitlines() or ["sin salida"])[-1]
    log(f"Pruebas unitarias: {ult}")
    return dict(codigo=r.returncode, resumen=ult)


def estimar(ex: Exploracion, log, salida: Path) -> dict:
    """Segundos por época (3 épocas, pliegue 2018) de cada base sin mecanismo, con coherencia (48 h) y con DRO; horas por etapa."""
    medidas = {}
    for base in ex.bases():
        for mec in ("control", "coh", "dro"):
            p = ex.config_celda(base, mec) if base != "periodica" or (ex.salida / "busqueda_periodica" / "busqueda" / "configuracion_elegida.json").exists() \
                else dict(PLAN["bases"]["periodica"]["configuraciones"][0], **PLAN["mecanismos"][mec]["parametros"])
            p["id"] = 9000 + len(medidas)
            car = salida / f"{base}_{mec}"
            ctx = ex.ctx(salida, f"estimar_{base}_{mec}", PLAN["bases"][base]["red"], p)
            ctx.mlflow = False
            r = PR.corrida(ctx, "N", p, 43, "pliegue_2018", P2._pos(ctx, 2018), car, "val_2018", opciones=dict(max_epocas=3, min_epocas=3, paciencia=99))
            h = pd.read_csv(car / "historia.csv")
            medidas[f"{base}·{mec}"] = float(np.diff(np.r_[0.0, h.segundos.to_numpy()])[1:].mean()) if len(h) > 1 else float(h.segundos.iloc[0])
            log(f"Estimación {base}·{mec}: {medidas[f'{base}·{mec}']:.1f} s por época ({r['n_parametros']:,} parámetros).")
    E = 40
    n = len(PLAN["pliegues"]) * len(PLAN["semillas"])
    costo = lambda b, m: medidas[f"{b}·{'coh' if m in ('multi48', 'coh', 'coh_pura', 'coh_dro') else ('dro' if m == 'dro' else 'control')}"]   # noqa: E731
    h = dict(busqueda_periodica=(8 + 3 * 3) * E * medidas.get("periodica·control", 0) / 3600,
             rejilla=sum(n * E * costo(b, m) for b in ex.bases() for m in PLAN["mecanismos"]) / 3600,
             sensibilidad=6 * 2 * 3 * E * float(np.mean([v for k, v in medidas.items() if k.endswith("coh")])) / 3600)
    d = dict(segundos_por_epoca=medidas, epocas_medias_supuestas=E, horas_por_etapa=h, horas_totales=float(sum(h.values())))
    PR.guardar_json(salida / "estimacion_computo.json", d)
    log("ESTIMACIÓN: " + "; ".join(f"{k} {v:.1f} h" for k, v in h.items()) + f"; total {d['horas_totales']:.0f} h (rango {d['horas_totales'] / 2:.0f}-"
        f"{2 * d['horas_totales']:.0f} h).")
    return d


def empaquetar(salida: Path, log) -> list[Path]:
    sello = dt.datetime.now().strftime("%Y%m%d_%H%M")
    pesados = lambda r: r.suffix in (".pt", ".npy", ".onnx") or r.name == "mlflow.db" or "mlruns" in r.parts   # noqa: E731
    z1, z2 = RAIZ / f"ENVIAR_resultados_exploracion_{sello}.zip", RAIZ / f"ENVIAR_pesos_exploracion_{sello}.zip"
    for destino, criterio, nivel in ((z1, lambda r: not pesados(r), zipfile.ZIP_DEFLATED), (z2, pesados, zipfile.ZIP_STORED)):
        with zipfile.ZipFile(destino, "w", nivel, allowZip64=True) as z:
            for r in sorted(salida.rglob("*")):
                if r.is_file() and criterio(r):
                    z.write(r, Path(salida.name) / r.relative_to(salida))
    log(f"Archivos para enviar: {z1.name} ({z1.stat().st_size / 2**20:.1f} MB) y {z2.name} ({z2.stat().st_size / 2**20:.1f} MB)")
    return [z1, z2]


def main() -> int:
    ap = argparse.ArgumentParser(description="Exploración de diseño numérica del Entregable 3 (solo pliegues de desarrollo)")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=None)
    ap.add_argument("--bases", nargs="+", choices=list(PLAN["bases"]), default=None, help="solo estas bases en la rejilla (para repartir el cómputo)")
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--hilos", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)))
    ap.add_argument("--sin-mlflow", action="store_true")
    ap.add_argument("--sin-empaquetar", action="store_true")
    a = ap.parse_args()
    if a.etapas is None:
        a.etapas = list(ETAPAS)
    if a.bases:                       # con un subconjunto de bases solo se entrena; la agregación y la decisión necesitan la rejilla completa
        a.etapas = [e for e in a.etapas if e not in ("agregacion", "decision", "sensibilidad")]
    rapido = dict(RAPIDO) if a.prueba_rapida else None
    salida = RAIZ / ("resultados_prueba_rapida_exploracion" if rapido else "resultados_exploracion_e3")
    salida.mkdir(exist_ok=True)
    log = Bitacora(salida / "bitacora.log")
    if rapido is None and a.dispositivo == "auto" and not torch.cuda.is_available():
        log("AVISO: no se detecta GPU; la exploración completa en CPU puede tardar varios días.")
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    if dispositivo == "cuda" and not torch.cuda.is_available():
        dispositivo = "cpu"
    torch.set_num_threads(a.hilos)
    gpu = f" ({torch.cuda.get_device_name(0)})" if dispositivo == "cuda" else ""
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if rapido else 'EXPLORACIÓN'} -> {salida.name} | etapas {a.etapas} | bases {a.bases or 'todas'} | dispositivo {dispositivo}{gpu}")
    t_ini = time.time()
    h = huellas()
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg["huellas_sha256"]) if reg["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: estos archivos cambiaron después de iniciar: {cambiados}. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar: plan, regla de decisión, semillas y código quedan fijados por las huellas.",
                   creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), plan=PLAN["version"], prueba_rapida=bool(rapido),
                   huellas_sha256=h, reanudaciones=[], prueba_2022_2025="no se lee en ninguna etapa")
    PR.guardar_json(rreg, reg)
    PR.guardar_json(salida / f"entorno_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", entorno(dispositivo))

    log("Cargando el panel principal (SHA-256)...")
    datos = DatosNumericos(RAIZ)
    comp = pruebas.numericas(datos)
    PR.guardar_json(salida / "comprobaciones_previas.json", comp)
    if not all(comp.values()):
        log(f"ERROR: fallaron comprobaciones previas {[k for k, v in comp.items() if not v]}. No se entrena.")
        return 4
    resumen = PR.leer_json(salida / "RESUMEN.json") if (salida / "RESUMEN.json").exists() else {}
    if "verificar" in a.etapas:
        resumen["verificar"] = verificar(salida, log)
        if resumen["verificar"]["codigo"] != 0:
            log("ERROR: fallaron las pruebas unitarias (ver pytest.txt). No se entrena.")
            PR.guardar_json(salida / "RESUMEN.json", resumen)
            return 5
    ex = Exploracion(RAIZ, salida, PLAN, datos, dispositivo, log, rapido, a)
    for etapa in [e for e in ETAPAS if e in a.etapas and e != "verificar"]:
        log(f"---- Etapa: {etapa}")
        with tqdm(total=None, desc=f"Exploración {etapa}", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
            ex.barra = barra
            if etapa == "estimar":
                resumen["estimar"] = estimar(ex, log, salida / "estimacion")
            elif etapa == "exportabilidad":
                resumen["exportabilidad"] = {k: v.get("exportable") for k, v in ex.exportabilidad().items()}
            elif etapa == "busqueda_periodica":
                resumen["busqueda_periodica"] = ex.busqueda_periodica()
            elif etapa == "rejilla":
                resumen["rejilla"] = ex.rejilla().groupby("celda").MASE.mean().to_dict()
            elif etapa == "agregacion":
                resumen["agregacion"] = ex.agregacion().groupby("celda").MASE.mean().to_dict()
            elif etapa == "decision":
                resumen["decision"] = {k: v for k, v in ex.decision().items() if k != "contrastes"}
            elif etapa == "sensibilidad":
                t = ex.sensibilidad()
                resumen["sensibilidad"] = t.groupby(["parametro", "valor"]).MASE.mean().reset_index().to_dict("records") if len(t) else "omitida"
        PR.guardar_json(salida / "RESUMEN.json", resumen)
    ex.resumen()
    log(f"Etapas terminadas en {(time.time() - t_ini) / 3600:.2f} h.")
    if not a.sin_empaquetar and a.etapas not in (["estimar"], ["verificar"], ["verificar", "estimar"]):
        empaquetar(salida, log)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""N-BEATS y TimesNet: los dos modelos que faltan en el Top 10 del Entregable 2 (ver LEEME.txt).

Ejecuta la parte «nuevos» del plan preregistrado ``config/plan_e2.json`` (el mismo archivo, sin cambios, del paquete
Completar_E2) y la robustez de sus pesos finales. No se llama directamente: use ENTRENAR_WINDOWS.bat o entrenar_linux.sh.

    python ejecutar_e2.py                          todas las etapas, en orden (reanuda si ya hay resultados)
    python ejecutar_e2.py --etapas estimar         solo estima el tiempo de cómputo (unos minutos)
    python ejecutar_e2.py --modelos nbeats         solo uno de los dos modelos
    python ejecutar_e2.py --prueba-rapida          verificación de pocos minutos; no produce resultados válidos
Etapas: estimar, nuevos (20 configuraciones, 5 finalistas, semillas 1000-1004 con costes), robustez.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_e2.json").read_text(encoding="utf-8"))
ETAPAS = ["estimar", "nuevos", "robustez"]
MODELOS = list(PLAN["nuevos"])           # nbeats, timesnet

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
sys.path.insert(0, str(RAIZ / "src"))

import numpy as np          # noqa: E402
import pandas as pd         # noqa: E402
import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from entrenamiento import pruebas                                     # noqa: E402
from entrenamiento import protocolo as PR                             # noqa: E402
from entrenamiento import protocolo_e2 as P2                          # noqa: E402
from entrenamiento import redes_e2                                    # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256                # noqa: E402

ASCII = os.name == "nt"
RAPIDO = dict(max_epocas=2, n_tr=96, n_es=24, n_ev=32, finalistas=1, semillas_finales=[1000, 1001], remuestreos=300, configuraciones=[1, 2])
SALIDA = "resultados_e2_nbeats_timesnet"


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + [RAIZ / "data" / "processed" / n for n in ("panel_horario.parquet", "feature_registry.json")]
    rutas += [RAIZ / "ejecutar_e2.py", RAIZ / "PREREGISTRO_E2_COMPLEMENTO.md"]
    rutas += sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts)
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.exists()}


def entorno(dispositivo: str) -> dict:
    e = dict(python=platform.python_version(), sistema=platform.platform(), procesador=platform.processor() or platform.machine(), nucleos=os.cpu_count(),
             torch=torch.__version__, numpy=np.__version__, dispositivo=dispositivo, cuda_disponible=torch.cuda.is_available(),
             rocm=getattr(torch.version, "hip", None), cuda=torch.version.cuda)
    if torch.cuda.is_available():
        e.update(gpu=torch.cuda.get_device_name(0), memoria_gpu_gb=round(torch.cuda.get_device_properties(0).total_memory / 2**30, 1))
    try:
        import psutil
        e["ram_gb"] = round(psutil.virtual_memory().total / 2**30, 1)
    except Exception:
        pass
    for m in ("pandas", "pyarrow", "mlflow", "scipy", "statsmodels"):
        try:
            e[m] = __import__(m).__version__
        except Exception:
            e[m] = None
    return e


def contexto(salida: Path, clave: str, red: str, variantes: list[str], datos, dispositivo, log, rapido, args):
    c = PLAN["comun"]
    cfg = dict(version=PLAN["version"], paquete=dict(clave=clave, nombre=clave, red=red, carpeta_resultados=salida.name), variantes=variantes,
               busqueda=dict(c["busqueda"]), final=dict(c["final"]), entrenamiento=dict(c["entrenamiento"]), inferencia=dict(c["inferencia"]))
    if rapido:
        cfg["busqueda"]["finalistas"] = rapido["finalistas"]
    ctx = PR.Contexto(RAIZ, salida, cfg, datos, dispositivo, log, rapido)
    ctx.hilos = 1
    ctx.mlflow, ctx.mlflow_raiz = not args.sin_mlflow, args.salida_raiz
    return ctx


def comprobaciones(datos) -> dict:
    """Ventanas sin fuga y salidas finitas de 24 h en versiones pequeñas de las dos redes."""
    out = dict(numericas=pruebas.numericas(datos))
    torch.manual_seed(0)
    n_x, n_cal, B = len(datos.hist) + len(datos.nombres_mascara), len(datos.cal), 4
    x, cp, cf, dia = torch.randn(B, datos.L, n_x), torch.randn(B, datos.L, n_cal), torch.randn(B, datos.H, n_cal), torch.zeros(B, dtype=torch.long)
    chicas = {"nbeats": dict(pilas=2, ancho=32, dropout=0.0), "timesnet": dict(e_layers=1, top_k=3, num_kernels=2, d_model=16, d_ff=16, dropout=0.0)}
    r = {}
    for red, p in chicas.items():
        m = redes_e2.construir(red, p, n_x, n_cal, datos.L, datos.H).eval()
        with torch.no_grad():
            y = m(x, cp, cf, dia)
        r[f"{red}_salida_24_finita"] = tuple(y.shape) == (B, datos.H) and bool(torch.isfinite(y).all())
        m.train()
        m(x, cp, cf, dia).abs().mean().backward()
        r[f"{red}_gradiente_finito"] = all(q.grad is None or bool(torch.isfinite(q.grad).all()) for q in m.parameters())
    out["redes"] = r
    return out


def estimar(datos, dispositivo, log, rapido, args, salida: Path) -> dict:
    """Segundos por época de cada modelo con datos reales y horas previstas (supuesto: 40 épocas por corrida)."""
    pos = P2._pos(contexto(salida, "estimacion", "nbeats", ["N"], datos, dispositivo, log, rapido, args), 2018)
    medidas, filas = {}, []
    n_std = 20 + 5 * 3 + len(PLAN["comun"]["final"]["semillas"])
    for m in MODELOS:
        if m not in args.modelos:
            continue
        p = dict(PLAN["nuevos"][m]["configuraciones"][0], id=9000)
        ctx = contexto(salida, "estimacion", PLAN["nuevos"][m]["red"], ["N"], datos, dispositivo, log, rapido, args)
        ctx.mlflow = False
        r = PR.corrida(ctx, "N", p, 43, "pliegue_2018", pos, salida / m, "val_2018", opciones=dict(max_epocas=3, min_epocas=3, paciencia=99))
        h = pd.read_csv(salida / m / "historia.csv")
        medidas[m] = float(np.diff(np.r_[0.0, h.segundos.to_numpy()])[1:].mean()) if len(h) > 1 else float(h.segundos.iloc[0])
        horas = n_std * 40 * medidas[m] / 3600
        filas.append(dict(modelo=m, corridas=n_std, segundos_por_epoca=medidas[m], horas=horas, horas_x0_5=horas / 2, horas_x2=2 * horas,
                          parametros=r["n_parametros"]))
        log(f"Estimación {m}: {medidas[m]:.1f} s por época ({r['n_parametros']:,} parámetros) -> unas {horas:.1f} h ({horas / 2:.1f}-{2 * horas:.1f} h).")
    t = pd.DataFrame(filas)
    t.to_csv(salida / "estimacion_computo.csv", index=False)
    d = dict(segundos_por_epoca=medidas, horas_totales=float(t.horas.sum()) if len(t) else 0.0, supuesto_epocas=40, dispositivo=dispositivo)
    PR.guardar_json(salida / "estimacion_computo.json", d)
    log(f"ESTIMACIÓN TOTAL ≈ {d['horas_totales']:.1f} h en este equipo.")
    return d


def empaquetar(salida: Path, log) -> list[Path]:
    sello = dt.datetime.now().strftime("%Y%m%d_%H%M")
    pesados = lambda r: r.suffix in (".pt", ".npy") or r.name == "mlflow.db" or "mlruns" in r.parts   # noqa: E731
    z1, z2 = RAIZ / f"ENVIAR_resultados_NBEATS_TimesNet_{sello}.zip", RAIZ / f"ENVIAR_pesos_NBEATS_TimesNet_{sello}.zip"
    for destino, criterio, nivel in ((z1, lambda r: not pesados(r), zipfile.ZIP_DEFLATED), (z2, pesados, zipfile.ZIP_STORED)):
        with zipfile.ZipFile(destino, "w", nivel) as z:
            for r in sorted(salida.rglob("*")):
                if r.is_file() and criterio(r):
                    z.write(r, Path(salida.name) / r.relative_to(salida))
    log(f"Archivos para enviar: {z1.name} ({z1.stat().st_size / 2**20:.1f} MB) y {z2.name} ({z2.stat().st_size / 2**20:.1f} MB)")
    return [z1, z2]


def main() -> int:
    ap = argparse.ArgumentParser(description="N-BEATS y TimesNet del Entregable 2")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=ETAPAS)
    ap.add_argument("--modelos", nargs="+", choices=MODELOS, default=MODELOS)
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--sin-mlflow", action="store_true")
    ap.add_argument("--sin-empaquetar", action="store_true")
    a = ap.parse_args()
    rapido = dict(RAPIDO) if a.prueba_rapida else None
    salida = RAIZ / ("resultados_prueba_rapida" if a.prueba_rapida else SALIDA)
    salida.mkdir(exist_ok=True)
    a.salida_raiz = salida
    log = Bitacora(salida / "bitacora.log")
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    if dispositivo == "cuda" and not torch.cuda.is_available():
        log("Se pidió GPU pero PyTorch no la detecta; se usa CPU.")
        dispositivo = "cpu"
    gpu = f" ({torch.cuda.get_device_name(0)}{', ROCm' if getattr(torch.version, 'hip', None) else ''})" if dispositivo == "cuda" else ""
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if rapido else 'EJECUCIÓN'} | etapas {a.etapas} | modelos {a.modelos} | dispositivo {dispositivo}{gpu}")
    t_ini = time.time()

    h = huellas()
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg["huellas_sha256"]) if reg["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: estos archivos cambiaron después de iniciar: {cambiados}. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar: el plan, las semillas y las reglas quedan fijados por las huellas.",
                   creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), plan=PLAN["version"], prueba_rapida=bool(rapido), huellas_sha256=h, reanudaciones=[])
    PR.guardar_json(rreg, reg)
    PR.guardar_json(salida / f"entorno_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", entorno(dispositivo))

    log("Cargando el panel y verificando su SHA-256...")
    datos = DatosNumericos(RAIZ)
    comp = comprobaciones(datos)
    PR.guardar_json(salida / "comprobaciones_previas.json", comp)
    fallas = [f"{g}.{k}" for g, d in comp.items() for k, v in d.items() if not v]
    if fallas:
        log(f"ERROR: fallaron las comprobaciones previas {fallas}. No se entrena.")
        return 4
    log(f"Comprobaciones previas correctas ({sum(len(d) for d in comp.values())}).")

    resumen = PR.leer_json(salida / "RESUMEN.json") if (salida / "RESUMEN.json").exists() else {}
    for etapa in [e for e in ETAPAS if e in a.etapas]:
        log(f"---- Etapa: {etapa}")
        if etapa == "estimar":
            resumen["estimar"] = estimar(datos, dispositivo, log, rapido, a, salida / "estimacion")
        elif etapa == "nuevos":
            for m in [x for x in MODELOS if x in a.modelos]:
                d = PLAN["nuevos"][m]
                ctx = contexto(salida / f"nuevo_{m}", m, d["red"], d["variantes"], datos, dispositivo, log, rapido, a)
                cfgs = [c for c in d["configuraciones"] if not rapido or c["id"] in rapido["configuraciones"]]
                n = len(cfgs) + ctx.cfg["busqueda"]["finalistas"] * 3 + len(rapido["semillas_finales"] if rapido else PLAN["comun"]["final"]["semillas"])
                with tqdm(total=n, desc=f"{d['nombre'].split(' (')[0]}", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                    ctx.barra = barra
                    resumen[m] = P2.modelo_estandar(ctx, cfgs)["variantes"]
        elif etapa == "robustez":
            red_de = {f"nuevo_{m}": PLAN["nuevos"][m]["red"] for m in a.modelos}
            t = P2.robustez(salida, datos, red_de, None, None, dispositivo, log, rapido)
            resumen["robustez"] = f"{t.clave.nunique() if len(t) else 0} procedimientos; ver robustez_nuevos_por_semilla.csv"
        PR.guardar_json(salida / "RESUMEN.json", resumen)
    log(f"Etapas terminadas en {(time.time() - t_ini) / 3600:.2f} h.")
    if not a.sin_empaquetar and a.etapas != ["estimar"]:
        empaquetar(salida, log)
    return 0


if __name__ == "__main__":
    sys.exit(main())

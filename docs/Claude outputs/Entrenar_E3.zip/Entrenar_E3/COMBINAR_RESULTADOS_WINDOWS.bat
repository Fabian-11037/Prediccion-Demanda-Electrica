@echo off
setlocal
cd /d "%~dp0"
title Entregable 3 - combinar resultados de las dos partes
set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys" >nul 2>nul && set "PY=python"
if not defined PY (
  echo  No se encontro Python. Instale Python 3.12 y vuelva a intentar.
  pause
  exit /b 1
)
%PY% combinar_resultados.py %*
echo.
pause

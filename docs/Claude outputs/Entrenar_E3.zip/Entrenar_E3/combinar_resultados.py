"""Une las carpetas de resultados de la parte 1 y de la parte 2 del Entregable 3 en una sola, sin modificar las originales.

    python combinar_resultados.py                                    resultados_e3_parte1 + resultados_e3_parte2 -> resultados_e3
    python combinar_resultados.py --parte1 RUTA --parte2 RUTA --salida RUTA

Reglas: las dos partes escriben en carpetas distintas, así que casi todo es disjunto. Para los archivos que existen en
ambas, se conserva la versión de la parte 2 con su nombre (curva_aprendizaje.csv, escalabilidad.csv y sanidad.json
de la parte 2 ya incluyen lo de la parte 1) y la de la parte 1 se guarda con el sufijo «.parte1». Los registros de cada
parte (REGISTRO.json, bitacora.log, RESUMEN_E3.json, mlflow.db) se conservan con su sufijo. Solo usa la biblioteca
estándar; escribe COMBINACION.json con el origen y la huella de cada archivo.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import shutil
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PROPIOS = {"REGISTRO.json", "bitacora.log", "RESUMEN_E3.json", "mlflow.db", "pytest.txt", "comprobaciones_previas.json"}
OMITIR = {"cache_adicionales", "texto", "mlruns"}          # cachés: no son resultados


def _sha(r: Path) -> str:
    h = hashlib.sha256()
    with open(r, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _con_sufijo(rel: Path, sufijo: str) -> Path:
    return rel.with_name(rel.stem + sufijo + rel.suffix)


def main() -> int:
    ap = argparse.ArgumentParser(description="Une los resultados de las dos partes del Entregable 3")
    ap.add_argument("--parte1", default=str(RAIZ / "resultados_e3_parte1"))
    ap.add_argument("--parte2", default=str(RAIZ / "resultados_e3_parte2"))
    ap.add_argument("--salida", default=str(RAIZ / "resultados_e3"))
    ap.add_argument("--con-cache", action="store_true", help="copiar también los vectores de texto y las cachés")
    a = ap.parse_args()
    p1, p2, out = Path(a.parte1), Path(a.parte2), Path(a.salida)
    for p in (p1, p2):
        if not (p / "REGISTRO.json").exists():
            print(f"No se encuentra {p / 'REGISTRO.json'}: indique la carpeta con --parte1 o --parte2.")
            return 1
    r1, r2 = json.loads((p1 / "REGISTRO.json").read_text(encoding="utf-8")), json.loads((p2 / "REGISTRO.json").read_text(encoding="utf-8"))
    if r1["huellas_sha256"] != r2["huellas_sha256"]:
        print("Las dos partes no se ejecutaron con el mismo paquete (huellas distintas): no se combinan.")
        return 2
    if out.exists() and any(out.iterdir()):
        print(f"{out} ya existe y no está vacía: bórrela o elija otra con --salida.")
        return 3
    origen = {}
    for parte, base in (("parte1", p1), ("parte2", p2)):
        for r in sorted(base.rglob("*")):
            if not r.is_file():
                continue
            rel = r.relative_to(base)
            if not a.con_cache and rel.parts[0] in OMITIR:
                continue
            if r.name.startswith("ENVIAR_"):
                continue
            destino = rel
            if len(rel.parts) == 1 and (rel.name in PROPIOS or rel.name.startswith("entorno_")):
                destino = _con_sufijo(rel, "_" + parte)
            elif parte == "parte2" and str(rel) in origen:          # conflicto: gana la parte 2; la parte 1 se renombra
                previo = out / rel
                renombrado = _con_sufijo(rel, ".parte1")
                previo.rename(out / renombrado)
                origen[str(renombrado)] = origen.pop(str(rel))
            (out / destino).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(r, out / destino)
            origen[str(destino)] = dict(parte=parte, sha256=_sha(r))
    (out / "COMBINACION.json").write_text(json.dumps(dict(creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), parte1=str(p1.resolve()),
                                                          parte2=str(p2.resolve()), huellas_paquete_iguales=True, archivos=origen),
                                                     ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Combinados {len(origen)} archivos en {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

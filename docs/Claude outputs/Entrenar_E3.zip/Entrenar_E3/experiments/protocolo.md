# Protocolo experimental preregistrado del Entregable 3 (versión 1)

Repositorio: `github.com/Fabian-11037/Prediccion-Demanda-Electrica`. La ejecución tiene dos partes. La **parte 1**
(desarrollo del original: diseño, ajuste, piloto del original, búsqueda en los conjuntos adicionales, sensibilidad, curva,
escalabilidad y sanidad con etiquetas permutadas) no usa resultados del Entregable 2 ni evalúa el original en la prueba.
La **parte 2** (confirmatoria: potencia con los rivales, familia, conjuntos adicionales completos, ablación, robustez,
exportación, interpretabilidad y estadística) se ejecuta solo después de versionar este documento con
`git tag protocolo-e3-v1`. Cada parte escribe en su propia carpeta (`resultados_e3_parte1`, `resultados_e3_parte2`); la parte 2 lee la parte 1
sin modificarla y registra las huellas de lo que usó. La huella de este documento queda en el `REGISTRO.json` de cada
parte desde el inicio de la parte 1; si cambia, el paquete se detiene. Hereda sin cambios la tarea, la métrica primaria, el margen δ, la unidad de independencia y la partición del
Entregable 1 y del Entregable 2 (`PREREGISTRO.md` y `PREREGISTRO_E2_COMPLEMENTO.md`).

## 1. Estándar, tarea y métricas

* Estándar: profundidad teórica (`experiments/estandar.md`).
* Tarea: pronóstico directo de 24 h de la demanda horaria del SIN, origen diario 00:00 (America/Bogota), historia de 168 h.
* Unidad de independencia: el origen diario. En las pruebas por semilla, la unidad es la realización (semilla).
* Métrica primaria: MASE con escala q168 de 2000-2017. Secundarias: RMSE por origen (sensibilidad), MAE, MAPE.
* Margen de relevancia δ = 3 % relativo del MASE del rival. α = 0,05; MCS al 90 %.

## 2. Hipótesis

**Hipótesis del mecanismo (por idea; la que se pone a prueba es la elegida en desarrollo, §4):**

| Idea | Hipótesis falsable | Predicciones secundarias declaradas |
|---|---|---|
| A / AB / AC | La corrección acotada de texto reduce el MASE en los días con texto en al menos 3 % y no cambia los días sin texto, porque el texto oficial anticipa eventos que la historia no contiene | La ventaja desaparece con texto placebo; sin texto la salida es idéntica a la base; en AB la ventaja crece con documentos recientes; en AC la corrección baja con texto placebo |
| E | Acotar el efecto de las covariables exógenas (reanálisis, hidrología sin hora certificada) reduce el MASE frente a mezclarlas sin límite, porque limita la degradación cuando cambian | La ventaja crece con ruido y faltantes en las covariables (robustez); sin la cota la ventaja desaparece o empeora; con ρ grande el modelo se acerca a PatchTST N |
| F | Separar el nivel de una forma diaria convexa reduce el error en días especiales, porque los festivos cambian la forma del día y no solo su nivel | La ventaja se concentra en días especiales; sin el símplex o sin nivel separado la ventaja disminuye; la envolvente limita el daño de los atípicos |

**Confirmatoria (R3):** el original reduce el MASE frente a cada uno de los m = 17 rivales (H0: E[L_orig − L_k] ≥ 0;
H1: < 0). Unión-intersección: «supera a todos» solo si se rechazan los 17 contrastes.

**Exploratorias:** todo lo demás (por horizonte, año, tipo de día; ablación; sensibilidad; robustez; incertidumbre;
interpretabilidad). No sustentan R3 por sí solas.

## 3. Fuente del mecanismo

Ver `experiments/procedencia.md`. Corrección residual acotada: adaptación de ReZero (Bachlechner et al., 2020) y de las
unidades multimodales con compuerta (Arevalo et al., 2017). Núcleo de impulso: adaptación de los núcleos de decaimiento
de procesos de Hawkes neuronales (Mei y Eisner, 2017). Perfiles convexos: propio, con trabajo cercano en N-BEATS y RevIN.

## 4. Partición de desarrollo y de confirmación, y número de variantes N_d

* Desarrollo: pliegues de validación 2018 y 2019 (forward chaining). Solo aquí se toman decisiones de diseño.
* Confirmación: pliegues 2020 y 2021 (solo ajuste de hiperparámetros con el protocolo común y potencia) y la prueba
  2022-2025, sellada hasta la etapa `familia`.
* Variantes de diseño: control PatchTST N y las ideas A, AB, AC, E y F con su configuración 1 (N_d = 5), semillas 101-105.
  La regla de decisión está en `config/plan_e3.json` (`diseno.regla`) y se aplica sin intervención; el resultado queda en
  `resultados_e3_parte1/diseno/decision.json` y `design_log.md`. La idea D se evalúa siempre como complemento de incertidumbre.
* Esfuerzo de diseño declarado: además de N_d, el diseño previo de las ideas está en el documento de diseño del proyecto.

## 5. Conjuntos adicionales

| Conjunto | Fuente y licencia | Ejes en que difiere del principal |
|---|---|---|
| ETTh1 | Zhou et al. (2021), ETDataset; CC BY-ND 4.0 | dominio (equipo eléctrico), tamaño (2 años), covariables (cargas), ruido |
| PM2.5 de Pekín | Liang et al. (2015), UCI 381; CC BY 4.0 | dominio (calidad del aire), colas pesadas, faltantes del objetivo, tamaño |
| Hogar de Sceaux | Hébrail y Bérard (2006), UCI 235; CC BY 4.0 | escala (un hogar), ruido, país y clima, tamaño |

Se eligieron por ser públicos, horarios, de la misma tarea (24 h desde 168 h) y distintos en al menos dos ejes, antes de
entrenar el original. Partición, desplazamiento del objetivo y festivos en el plan. No se usan para decisiones de diseño.
Todos los modelos de la familia se evalúan en cada uno, con el mismo presupuesto de búsqueda (20 configuraciones,
5 finalistas en los pliegues 2-4). Las variantes con texto se ejecutan como su control N (no hay texto emparejado).

## 6. Ejecuciones, semillas, determinismo y potencia

* Piloto: 5 semillas (1000-1004) del original y de cada rival en el pliegue 2021. σ_d,k = DE de las diferencias pareadas
  por semilla. R_k = ⌈(z_{1−α/(2m)} + z_{0,90})² σ²_d,k / δ_k²⌉; R = mín(30, máx(10, máx_k R_k)). R queda fijado en
  `resultados_e3_parte2/potencia/R.json` antes de abrir la prueba.
* Semillas finales: 1000 … 1000 + R − 1 para todos los modelos de la familia y el original, en el principal y en los
  adicionales. MSTL es determinista: una realización, repetida en las pruebas por semilla.
* Determinismo: semillas de Python, NumPy y PyTorch; `cudnn.deterministic`, `use_deterministic_algorithms(warn_only)`,
  `CUBLAS_WORKSPACE_CONFIG=:4096:8`. Las operaciones no deterministas de GPU se declaran y su variabilidad queda en la
  dispersión entre semillas.

## 7. Equidad y presupuesto

* Mismo motor para todos: AdamW, MAE sobre demanda / nivel, ReduceLROnPlateau(0,5; 2), recorte 1,0, máximo 200 épocas,
  parada desde la época 10 con 6 épocas sin mejora de 0,2 %, restauración del mejor estado.
* Presupuesto de hiperparámetros: 20 configuraciones (semilla 43, pliegue inicial) y 5 finalistas en los demás pliegues,
  medido en número de configuraciones; el tiempo de cómputo de cada modelo se reporta en la tabla maestra.
* Capacidad: parámetros y FLOPs de todos; la ablación incluye PatchTST N con parámetros igualados al original.
* Benchmarks congelados con sus configuraciones del Entregable 2 (`familia_configuraciones.json`). Adaptaciones
  declaradas: N-HiTS y ARX se reentrenan en el motor común (misma política de reentrenamiento, §5.2); la extracción de
  parches de PatchTST usa un índice fijo equivalente a `unfold` para poder exportar a ONNX (prueba unitaria).

## 8. Familia de contrastes, pruebas y decisión

* Pruebas exigidas por contraste (tres, todas deben rechazar; decide el máximo de los p ajustados):
  1. Diebold-Mariano con corrección HLN y varianza HAC de 13 rezagos sobre la pérdida por origen promediada en semillas;
  2. bootstrap circular por bloques de 14 días (10 000 remuestreos) de la diferencia media;
  3. t pareada por semillas (verificación de normalidad con Shapiro-Wilk).
  Holm sobre los m = 17 contrastes en cada prueba. Pruebas globales: MCS (T_max, 90 %) y Friedman con Nemenyi.
* Superioridad (§8.4): media mejor que cada rival; las tres pruebas rechazan; IC 95 % de la diferencia relativa por debajo
  de −3 %; |δ de Cliff| ≥ 0,147 o |d| ≥ 0,2; mejor en media en al menos 2 de 3 adicionales y nunca significativamente peor;
  adecuación del original (supera a los ingenuos, brecha ajuste-parada < 0,10, sanidad con etiquetas permutadas, residuos
  y calibración reportados); la conclusión no cambia con las pruebas alternativas.
* Sensibilidad de la conclusión: Wilcoxon y t de Nadeau-Bengio en lugar de la t; HAC con 7 y 28 rezagos; bloques de 7 y
  28 días; RMSE por origen; primeras 10 semillas, semillas pares e impares.
* Familias secundarias, cada una con su Holm: conjuntos adicionales (todos los contrastes de los tres conjuntos), ablación
  (cada variante frente al modelo completo) y subgrupos.
* Modelo de efectos mixtos: pérdida media por bloque de 14 días ~ modelo + (1 | bloque) + (1 | semilla).
* Entre conjuntos: Friedman con Iman-Davenport, Wilcoxon-Holm y prueba bayesiana de rangos con signo con ROPE ±3 %.

## 9. Estudios de robustez, eficiencia y calidad probabilística (Tabla 5)

Sensibilidad a ρ, ancho de la corrección, λ, K, ρ_ℓ y la tasa de aprendizaje (pliegue 2021, 3 semillas); estabilidad
por semilla (R semillas); perturbaciones (ruido de demanda, atípicos y faltantes en 3 severidades; texto ausente y
placebo en los modelos con texto); curva de aprendizaje (10, 25, 50 y 100 %); escalabilidad (L = 72, 168, 336 y 672);
cambio de distribución (prueba por año y conjuntos adicionales); incertidumbre (ensamble de semillas, conformal
adaptativo y conformal condicionado por texto, idea D) con cobertura por subgrupo; eficiencia (parámetros, FLOPs,
latencia en CPU, memoria, energía) con frontera de Pareto; análisis de errores por tipo de día, año y hora.

## 10. Exclusión, parada y desviaciones

Una corrida con pérdida no finita detiene el paquete; ninguna corrida se descarta en silencio. Toda desviación se
declara en el informe con su motivo; los análisis no previstos son exploratorios.

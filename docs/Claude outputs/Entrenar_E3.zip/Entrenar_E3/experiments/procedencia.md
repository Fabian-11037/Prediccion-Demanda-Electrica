# Procedencia de los mecanismos del modelo original

| Campo | Corrección residual acotada (ideas A, AB, AC y E) | Núcleo de respuesta al impulso (idea B) | Pérdida con texto placebo (idea C) | Mezcla convexa de perfiles (idea F) |
|---|---|---|---|---|
| Origen | Transferido y adaptado | Transferido y adaptado | Propio | Propio |
| Fuente | Bachlechner et al. (2020), *ReZero is All You Need*, arXiv:2003.04887 (rama residual que parte de cero); Arevalo et al. (2017), *Gated Multimodal Units for Information Fusion*, arXiv:1702.01992 (compuerta multimodal) | Mei y Eisner (2017), *The Neural Hawkes Process*, NeurIPS, arXiv:1612.09328 (intensidad con núcleos de decaimiento) | — (relacionada con el control placebo de los diseños de evaluación del proyecto) | — (trabajo cercano: N-BEATS, Oreshkin et al., 2020; RevIN, Kim et al., 2022; métodos de perfiles de carga) |
| Propiedad compartida | En los dos casos una rama auxiliar no debe dañar a la principal al inicio | Eventos irregulares cuyo efecto decae con el tiempo | — | — |
| Modificaciones algorítmicas | (1) la rama es otra modalidad (texto o covariables), no una capa del mismo flujo; (2) su efecto queda acotado por ρ en todo el entrenamiento (tanh y compuerta sigmoide), no solo al inicio; (3) bandera de presencia que anula la rama cuando la fuente falta; (4) regresión de 24 pasos sobre demanda / nivel en lugar de clasificación | (1) el núcleo pondera vectores de documentos para resumir texto, no la intensidad de un proceso puntual; (2) mezcla de exponenciales con τ aprendido en días; (3) afinidad de contenido con una consulta que solo usa la historia numérica; (4) normalización 1 / (1 + Σw) que da ‖z‖ ≤ max ‖V e‖; (5) solo documentos disponibles antes del origen | Término λ · mean \|a_p Δ(z_p, c)\| con donantes de 28 a 364 días antes | Perfiles normalizados a media 1, pesos en el símplex, nivel separado con cota ρ_ℓ |
| Implementación | Escrita desde la formulación en `src/original/mecanismos.py` (`CorreccionAcotada`, `ModeloA`, `ModeloE`); no se consultó ni copió código de las fuentes | `NucleoImpulso`, escrita desde la formulación | `ModeloAC.perdida_adicional` y el gancho de una línea en `motor.entrenar` | `ModeloF` |

Bases reutilizadas y declaradas: el núcleo numérico es el codificador por parches de PatchTST adaptado del propio
proyecto (modelo 6 del Entregable 2, `src/entrenamiento/redes.py`), y el resumen de texto de la idea A es la
relevancia aprendida del mismo proyecto. Los vectores de documentos vienen del codificador multilingüe E5 base (Wang et al.,
2024), congelado y con la misma revisión para todos los modelos con texto. Ninguna parte del mecanismo propio se importa de
una biblioteca de modelos.

Trabajo cercano que debe entrar en la matriz de novedad (Tabla 2) y en la búsqueda del §6.3: TIGER (NeurIPS 2026),
CRC (arXiv:2512.22428), el análisis del colapso del texto (arXiv:2606.19413), PA-RNet (arXiv:2508.04750), GRAFT
(arXiv:2512.14400), Bai et al. (arXiv:2301.07535 y 2406.06641), TaTS (arXiv:2502.08942), TGForecaster (arXiv:2405.13522),
TFT, NBEATSx, N-BEATS y RevIN. Las referencias de Arevalo et al., NBEATSx y RevIN deben verificarse antes de citarlas.

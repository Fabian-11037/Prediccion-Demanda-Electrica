"""Entrenamientos y pruebas del Entregable 3: modelo original (ideas A-F), familia de contrastes, conjuntos adicionales y
todos los estudios que exige la verificación estadística (ver LEEME.txt y experiments/protocolo.md).

No se llama directamente: use ENTRENAR_WINDOWS.bat o entrenar_linux.sh, que preparan el entorno.

La ejecución tiene dos partes, cada una con su propia carpeta de resultados (reanudables e independientes):
    python ejecutar_e3.py                                  PARTE 1 -> resultados_e3_parte1: modelo original; sin el E2 ni la prueba
    python ejecutar_e3.py --parte 2 --resultados-e2 R1 R2  PARTE 2 -> resultados_e3_parte2: familia, prueba y estadística; lee la
                                                           parte 1 sin modificarla (--resultados-parte1 si no está junto a esta)
    python combinar_resultados.py                          une las dos carpetas en resultados_e3 (después, cuando se quiera)
    python ejecutar_e3.py --etapas estimar                 solo estima el tiempo de cómputo
    python ejecutar_e3.py --prueba-rapida                  las dos partes en minutos; no produce resultados válidos
Parte 1: verificar estimar diseno ajuste piloto adicionales_ajuste sensibilidad curva escalabilidad sanidad
Parte 2: verificar potencia familia adicionales ablacion curva escalabilidad robustez sanidad exportar interpretabilidad estadistica
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import subprocess
import sys
import time
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
PLAN = json.loads((RAIZ / "config" / "plan_e3.json").read_text(encoding="utf-8"))
ETAPAS = ["verificar", "estimar", "diseno", "ajuste", "piloto", "adicionales_ajuste", "sensibilidad", "potencia", "familia", "adicionales", "ablacion",
          "curva", "escalabilidad", "robustez", "sanidad", "exportar", "interpretabilidad", "estadistica"]          # orden de ejecución
PARTE_1 = ["verificar", "estimar", "diseno", "ajuste", "piloto", "adicionales_ajuste", "sensibilidad", "curva", "escalabilidad", "sanidad"]
PARTE_2 = ["verificar", "potencia", "familia", "adicionales", "ablacion", "curva", "escalabilidad", "robustez", "sanidad", "exportar", "interpretabilidad",
           "estadistica"]
SOLO_1 = set(PARTE_1) - set(PARTE_2) - {"estimar"}
SOLO_2 = set(PARTE_2) - set(PARTE_1)
CLAVES_PARTE1 = ["diseno/decision.json", "diseno/design_log.md", "ajuste/busqueda/configuracion_elegida.json", "potencia/piloto_original.csv",
                 "sanidad/original_etiquetas_permutadas/resultado.json"]


def _cache_codificador() -> Path:
    propia = RAIZ / ".cache_hf"
    if propia.exists():
        return propia
    for otra in sorted(RAIZ.parent.glob("*/.cache_hf")):
        if (otra / "hub").exists():
            return otra
    return propia


os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
os.environ.setdefault("HF_HOME", str(_cache_codificador()))
sys.path.insert(0, str(RAIZ / "src"))

import numpy as np          # noqa: E402
import pandas as pd         # noqa: E402
import torch                # noqa: E402
from tqdm import tqdm       # noqa: E402

from analisis import estadistica_e3                                   # noqa: E402
from entrenamiento import exportacion, interpretabilidad, pruebas, texto   # noqa: E402
from entrenamiento import protocolo as PR                             # noqa: E402
from entrenamiento import protocolo_e3 as P3                          # noqa: E402
from entrenamiento.adicionales import DatosAdicionales                # noqa: E402
from entrenamiento.datos import DatosNumericos, sha256                # noqa: E402

ASCII = os.name == "nt"
RAPIDO = dict(max_epocas=2, n_tr=96, n_es=24, n_ev=32, finalistas=1, semillas_finales=[1000, 1001], semillas_diseno=[101, 102], remuestreos=300,
              configuraciones=[1, 2])


class Bitacora:
    def __init__(self, ruta: Path):
        self.ruta = ruta

    def __call__(self, mensaje: str, consola: bool = True):
        linea = f"[{dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensaje}"
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(linea + "\n")
        if consola:
            tqdm.write(linea)


def huellas() -> dict:
    rutas = sorted((RAIZ / "config").glob("*.json")) + sorted((RAIZ / "data").rglob("*.*")) + sorted((RAIZ / "experiments").glob("*.md"))
    rutas += [RAIZ / "ejecutar_e3.py"] + sorted(p for p in (RAIZ / "src").rglob("*.py") if "__pycache__" not in p.parts)
    rutas += sorted((RAIZ / "tests").glob("*.py"))
    return {str(r.relative_to(RAIZ)).replace("\\", "/"): sha256(r) for r in rutas if r.is_file()}


def entorno(dispositivo: str) -> dict:
    e = dict(python=platform.python_version(), sistema=platform.platform(), procesador=platform.processor() or platform.machine(), nucleos=os.cpu_count(),
             torch=torch.__version__, numpy=np.__version__, dispositivo=dispositivo, cuda_disponible=torch.cuda.is_available(),
             rocm=getattr(torch.version, "hip", None), cuda=torch.version.cuda, determinismo=dict(cudnn_deterministic=True, cudnn_benchmark=False,
             use_deterministic_algorithms="True (warn_only)", CUBLAS_WORKSPACE_CONFIG=os.environ.get("CUBLAS_WORKSPACE_CONFIG")))
    if torch.cuda.is_available():
        e.update(gpu=torch.cuda.get_device_name(0), memoria_gpu_gb=round(torch.cuda.get_device_properties(0).total_memory / 2**30, 1))
    try:
        import psutil
        e["ram_gb"] = round(psutil.virtual_memory().total / 2**30, 1)
    except Exception:
        pass
    for m in ("pandas", "pyarrow", "transformers", "lightgbm", "statsforecast", "mlflow", "scipy", "statsmodels", "onnx", "onnxruntime", "holidays"):
        try:
            e[m] = __import__(m).__version__
        except Exception:
            e[m] = None
    return e


def _liberar_memoria():
    """Devuelve al sistema la memoria de las lecturas grandes (CSV por minuto del hogar); solo en Linux."""
    import gc
    gc.collect()
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def preparar_texto(salida: Path, datos, dispositivo, log, rapido, args) -> tuple[dict, np.ndarray]:
    ct = datos.contrato["texto"]
    de_prueba = bool(rapido)
    desc = texto.preparar_descripciones(RAIZ, salida / "texto" / "descripciones", ct, datos.hist + datos.nombres_mascara, dispositivo, log,
                                        modo_prueba=de_prueba, codificador=args.codificador)
    n_dias = len(datos.indice) // 24
    if de_prueba:
        canal = texto.preparar_canal(RAIZ, salida / "texto", ct, datos.dia_base, n_dias, dispositivo, log, modo_prueba=True)
    else:
        n = len(texto.cargar_corpus_oficial(RAIZ))
        with tqdm(total=n, desc="Vectores de texto", unit="doc", dynamic_ncols=True, ascii=ASCII) as barra:
            if (salida / "texto" / "vectores_documento.npy").exists():
                barra.update(n)
            canal = texto.preparar_canal(RAIZ, salida / "texto", ct, datos.dia_base, n_dias, dispositivo, log, codificador=args.codificador, barra=barra)
    lista_dia, _ = texto.listas_por_dia(canal["corpus"]["disponible_desde"], datos.dia_base, n_dias, 24, ct["max_documentos_canal"])
    return dict(vectores=canal["vectores"], lista=canal["lista"], lista_dia=lista_dia), desc


def descripciones_adicionales(salida: Path, adic: dict, datos_principal, dispositivo, log, rapido, args) -> dict:
    out = {}
    for nombre, d in adic.items():
        defin = PLAN["adicionales"][nombre]["descripciones"]
        desc = {c: defin[c] for c in d.hist}
        for mname in d.nombres_mascara:
            desc[mname] = "Indicador de ausencia de las covariables " + mname.replace("ausente_", "").replace("_", " ")
        out[nombre] = texto.preparar_descripciones(RAIZ, salida / "texto" / f"descripciones_{nombre}", datos_principal.contrato["texto"], d.hist + d.nombres_mascara,
                                                   dispositivo, log, modo_prueba=bool(rapido), codificador=args.codificador, descripciones=desc)
    return out


def verificar(salida: Path, log) -> dict:
    """Pruebas unitarias del modelo original (pytest) antes de entrenar."""
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", str(RAIZ / "tests"), "-p", "no:cacheprovider"], capture_output=True, text=True, cwd=RAIZ)
    (salida / "pytest.txt").write_text(r.stdout + "\n" + r.stderr, encoding="utf-8")
    ult = (r.stdout.strip().splitlines() or ["sin salida"])[-1]
    log(f"Pruebas unitarias: {ult}")
    return dict(codigo=r.returncode, resumen=ult)


def comprobaciones(datos, adic: dict) -> dict:
    out = dict(numericas=pruebas.numericas(datos))
    for nombre, d in adic.items():
        f = d.pliegues()
        tr, es = d.ajuste_final()
        ev = d.prueba()
        out[f"adicional_{nombre}"] = dict(
            pliegues_ordenados=all(d.indice[x["tr"]].max() < d.indice[x["es"]].min() <= d.indice[x["es"]].max() < d.indice[x["val"]].min() for x in f),
            ajuste_final_antes_de_la_prueba=bool(pd.Timestamp(d.indice[es].max()) + pd.Timedelta(hours=23) < pd.Timestamp(d.indice[ev].min())),
            prueba_con_origenes=bool(len(ev) > 20), escala_positiva=bool(d.q168 > 0))
    return out


def estimar(e3: P3.E3, log, salida: Path) -> dict:
    """Segundos por época (3 épocas en el pliegue 2018) de cada idea y de cada rival, y horas previstas por etapa."""
    medidas = {}
    casos = [(f"idea_{k}", d["red"], d["variante"], dict(d["configuraciones"][0])) for k, d in PLAN["original"].items()]
    try:
        fam = e3.familia_resuelta()
    except P3.SinResultadosE2:
        fam = {k: dict(d, config=e3._config_de_prueba(k, d)) for k, d in PLAN["familia"].items()}
        log("Estimación con configuraciones provisionales de los rivales (faltan resultados del E2).")
    casos += [(k, d["red"], d["variante"], dict(d["config"])) for k, d in fam.items() if d["tipo"] == "red"]
    for nombre, red, variante, p in casos:
        m = dict(clave=nombre, tipo="red", red=red, variante=variante, config=dict(p, id=9000 + len(medidas)))
        car = salida / nombre
        ctx = e3.ctx(salida, nombre, red, variante)
        ctx.mlflow = False
        r = PR.corrida(ctx, variante, m["config"], 43, "pliegue_2018", P3.P2._pos(ctx, 2018), car, "val_2018", opciones=dict(max_epocas=3, min_epocas=3, paciencia=99))
        h = pd.read_csv(car / "historia.csv")
        medidas[nombre] = float(np.diff(np.r_[0.0, h.segundos.to_numpy()])[1:].mean()) if len(h) > 1 else float(h.segundos.iloc[0])
        log(f"Estimación {nombre}: {medidas[nombre]:.1f} s por época ({r['n_parametros']:,} parámetros).")
    E = 40
    ideas = [v for k, v in medidas.items() if k.startswith("idea_")]
    riv = [v for k, v in medidas.items() if not k.startswith("idea_")]
    t_idea, t_riv = float(np.mean(ideas)), float(np.sum(riv))
    filas = []
    for R in (10, 20, 30):
        h = {(1, "diseno"): 6 * 2 * 5 * E * t_idea, (1, "ajuste"): 35 * E * t_idea, (1, "piloto"): 5 * E * t_idea,
             (1, "adicionales_ajuste"): 3 * 0.25 * 35 * E * t_idea, (1, "sensibilidad"): 16 * 3 * E * t_idea, (1, "curva"): 12 * E * t_idea,
             (2, "potencia"): 5 * E * t_riv, (2, "familia"): 1.3 * R * E * (t_idea + t_riv), (2, "adicionales"): 3 * 0.25 * (R * t_idea + (35 + R) * t_riv) * E,
             (2, "ablacion"): 10 * 10 * 1.3 * E * t_idea, (2, "curva"): 12 * E * t_riv / max(1, len(riv))}
        filas += [dict(R=R, parte=p, etapa=k, horas=v / 3600) for (p, k), v in h.items()]
    t = pd.DataFrame(filas)
    t["horas_x0.5"], t["horas_x2"] = t.horas / 2, t.horas * 2
    t.to_csv(salida / "estimacion_computo.csv", index=False)
    tot = t.groupby("R").horas.sum().to_dict()
    p1 = float(t[(t.R == 10) & (t.parte == 1)].horas.sum())
    d = dict(segundos_por_epoca=medidas, supuestos=dict(epocas_medias=E, ajuste_final_frente_a_pliegue_2018=1.3, adicionales_frente_al_principal=0.25,
                                                        clasicos="LightGBM y MSTL no incluidos (CPU)"), horas_totales_por_R={int(k): float(v) for k, v in tot.items()})
    PR.guardar_json(salida / "estimacion_computo.json", d)
    d["horas_parte_1"] = p1
    log(f"ESTIMACIÓN parte 1 (no depende de R ni del E2): {p1:.0f} h (rango {p1 / 2:.0f}-{2 * p1:.0f} h).")
    log("ESTIMACIÓN total con la parte 2: " + "; ".join(f"R = {int(k)}: {v:.0f} h (rango {v / 2:.0f}-{2 * v:.0f} h)" for k, v in tot.items()))
    return d


def empaquetar(salida: Path, log, parte: str) -> list[Path]:
    sello = f"parte{parte}_" + dt.datetime.now().strftime("%Y%m%d_%H%M")
    pesados = lambda r: r.suffix in (".pt", ".npy", ".onnx") or r.name in ("modelo_lightgbm.txt", "mlflow.db") or "mlruns" in r.parts   # noqa: E731
    z1, z2 = RAIZ / f"ENVIAR_resultados_E3_{sello}.zip", RAIZ / f"ENVIAR_pesos_artefactos_E3_{sello}.zip"
    fuentes = [salida]
    for destino, criterio, nivel in ((z1, lambda r: not pesados(r), zipfile.ZIP_DEFLATED), (z2, pesados, zipfile.ZIP_STORED)):
        with zipfile.ZipFile(destino, "w", nivel, allowZip64=True) as z:
            for f in fuentes:
                for r in sorted(f.rglob("*")) if f.exists() else []:
                    if r.is_file() and criterio(r):
                        z.write(r, Path(f.name) / r.relative_to(f))
    log(f"Archivos para enviar: {z1.name} ({z1.stat().st_size / 2**20:.1f} MB) y {z2.name} ({z2.stat().st_size / 2**20:.1f} MB)")
    return [z1, z2]


def main() -> int:
    ap = argparse.ArgumentParser(description="Entregable 3: modelo original y verificación estadística")
    ap.add_argument("--parte", choices=["1", "2"], default=None, help="1: modelo original sin el E2 (por omisión); 2: comparación con la familia")
    ap.add_argument("--etapas", nargs="+", choices=ETAPAS, default=None)
    ap.add_argument("--resultados-e2", nargs="*", default=[], help="carpetas con resultados de Completar_E2 y de NBEATS_TimesNet_E2")
    ap.add_argument("--conjuntos", nargs="*", default=None, choices=list(PLAN["adicionales"]), help="solo estos conjuntos adicionales")
    ap.add_argument("--prueba-rapida", action="store_true")
    ap.add_argument("--dispositivo", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--hilos", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)))
    ap.add_argument("--codificador", default=None)
    ap.add_argument("--sin-mlflow", action="store_true")
    ap.add_argument("--sin-empaquetar", action="store_true")
    ap.add_argument("--resultados-parte1", default=None, help="carpeta de la parte 1 (por omisión, resultados_e3_parte1 junto a este archivo)")
    ap.add_argument("--idea-prueba", choices=list(PLAN["original"]), default=None, help=argparse.SUPPRESS)   # solo con --prueba-rapida
    a = ap.parse_args()
    if a.idea_prueba and not a.prueba_rapida:
        ap.error("--idea-prueba solo existe para verificar el código con --prueba-rapida; la corrida real aplica la regla preregistrada")
    if a.parte is None and a.etapas is None and a.prueba_rapida:          # la prueba rápida recorre las dos partes, cada una en su carpeta
        for parte in ("1", "2"):
            b = argparse.Namespace(**vars(a))
            b.parte, b.etapas = parte, (PARTE_1 if parte == "1" else PARTE_2)
            c = ejecutar(b)
            if c:
                return c
        return 0
    if a.parte is None:
        a.parte = "2" if a.etapas and set(a.etapas) & SOLO_2 else "1"
    if a.etapas is None:
        a.etapas = PARTE_2 if a.parte == "2" else PARTE_1
    prohibidas = sorted(set(a.etapas) & (SOLO_1 if a.parte == "2" else SOLO_2))
    if prohibidas:
        ap.error(f"las etapas {prohibidas} pertenecen a la otra parte (parte 1: {PARTE_1}; parte 2: {PARTE_2})")
    return ejecutar(a)


def ejecutar(a) -> int:
    rapido = dict(RAPIDO) if a.prueba_rapida else None
    if rapido and a.idea_prueba:
        rapido["idea_forzada"] = a.idea_prueba
    base = ("resultados_prueba_rapida_e3" + (f"_{a.idea_prueba}" if a.idea_prueba else "")) if rapido else "resultados_e3"
    salida = RAIZ / f"{base}_parte{a.parte}"
    p1 = salida if a.parte == "1" else Path(a.resultados_parte1 or (RAIZ / f"{base}_parte1"))
    salida.mkdir(exist_ok=True)
    log = Bitacora(salida / "bitacora.log")
    if not a.resultados_e2:
        a.resultados_e2 = [str(p) for p in sorted(RAIZ.parent.glob("*/resultados_e2*")) if p.is_dir()]
    necesitan_e2 = [e for e in a.etapas if e in ("potencia", "familia", "adicionales", "robustez", "exportar", "interpretabilidad", "estadistica")]
    if necesitan_e2 and not a.resultados_e2 and not rapido:
        log(f"ERROR: las etapas {necesitan_e2} (parte 2) comparan con la familia y necesitan los resultados de Completar_E2 y de "
            "NBEATS_TimesNet_E2. Indíquelos con --resultados-e2 RUTA1 RUTA2, o ejecute primero la parte 1 (sin --parte 2).")
        return 3
    dispositivo = ("cuda" if torch.cuda.is_available() else "cpu") if a.dispositivo == "auto" else a.dispositivo
    if dispositivo == "cuda" and not torch.cuda.is_available():
        log("Se pidió GPU pero PyTorch no la detecta; se usa CPU.")
        dispositivo = "cpu"
    gpu = f" ({torch.cuda.get_device_name(0)}{', ROCm' if getattr(torch.version, 'hip', None) else ''})" if dispositivo == "cuda" else ""
    log("=" * 78)
    log(f"{'PRUEBA RÁPIDA' if rapido else 'EJECUCIÓN'} | PARTE {a.parte} -> {salida.name} | etapas {a.etapas} | dispositivo {dispositivo}{gpu} | "
        f"resultados E2: {a.resultados_e2 or 'ninguno'}" + (f" | parte 1 (solo lectura): {p1}" if a.parte == "2" else ""))
    t_ini = time.time()

    h = huellas()
    info_p1 = None
    if a.parte == "2":
        faltan = [c for c in CLAVES_PARTE1 if not (p1 / c).exists()]
        if faltan or not (p1 / "REGISTRO.json").exists():
            log(f"ERROR: la parte 1 en {p1} no está completa (faltan {faltan or ['REGISTRO.json']}). Termine la parte 1 o indique su carpeta con "
                "--resultados-parte1.")
            return 6
        reg1 = PR.leer_json(p1 / "REGISTRO.json")
        if reg1["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg1["huellas_sha256"]) if reg1["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: el paquete no es el mismo con el que se hizo la parte 1 (cambiaron {cambiados}). Use el mismo paquete sin modificar.")
            return 2
        info_p1 = dict(ruta=str(p1.resolve()), huellas_sha256={c: sha256(p1 / c) for c in CLAVES_PARTE1})
    rreg = salida / "REGISTRO.json"
    if rreg.exists():
        reg = PR.leer_json(rreg)
        if reg["huellas_sha256"] != h:
            cambiados = sorted(k for k in set(h) | set(reg["huellas_sha256"]) if reg["huellas_sha256"].get(k) != h.get(k))
            log(f"ERROR: estos archivos cambiaron después de iniciar: {cambiados}. Para empezar de cero, renombre la carpeta {salida.name}.")
            return 2
        if info_p1 and reg.get("parte1", {}).get("huellas_sha256") not in (None, info_p1["huellas_sha256"]):
            log("ERROR: los resultados de la parte 1 cambiaron desde que empezó la parte 2 (decisión, ajuste, piloto o sanidad).")
            return 2
        reg.setdefault("reanudaciones", []).append(dt.datetime.now().astimezone().isoformat(timespec="seconds"))
    else:
        reg = dict(registro="Escrito antes de entrenar: el plan, el protocolo, las semillas y las reglas quedan fijados por las huellas.",
                   creado=dt.datetime.now().astimezone().isoformat(timespec="seconds"), plan=PLAN["version"], parte=int(a.parte), prueba_rapida=bool(rapido),
                   huellas_sha256=h, reanudaciones=[])
    if info_p1:
        reg["parte1"] = info_p1
    PR.guardar_json(rreg, reg)
    PR.guardar_json(salida / f"entorno_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", entorno(dispositivo))

    log("Cargando el panel principal y los tres conjuntos adicionales (SHA-256)...")
    datos = DatosNumericos(RAIZ)
    cache = p1 / "cache_adicionales" if (p1 / "cache_adicionales").exists() else salida / "cache_adicionales"   # caché de lectura, no un resultado
    adic = {n: DatosAdicionales(RAIZ, n, d, cache=cache) for n, d in PLAN["adicionales"].items()}
    _liberar_memoria()
    for n, d in adic.items():
        PR.guardar_json(salida / f"conjunto_{n}.json", d.resumen())
    comp = comprobaciones(datos, adic)
    PR.guardar_json(salida / "comprobaciones_previas.json", comp)
    fallas = [f"{g}.{k}" for g, d in comp.items() for k, v in d.items() if not v]
    if fallas:
        log(f"ERROR: fallaron las comprobaciones previas {fallas}. No se entrena.")
        return 4
    resumen = PR.leer_json(salida / "RESUMEN_E3.json") if (salida / "RESUMEN_E3.json").exists() else {}
    if "verificar" in a.etapas:
        resumen["verificar"] = verificar(salida, log)
        if resumen["verificar"]["codigo"] != 0:
            log("ERROR: fallaron las pruebas unitarias (ver pytest.txt). No se entrena.")
            PR.guardar_json(salida / "RESUMEN_E3.json", resumen)
            return 5
    log("Preparando el canal de documentos oficiales y las descripciones de canal (codificador E5)...")
    if a.parte == "2" and (p1 / "texto").exists() and not (salida / "texto").exists():
        import shutil                                      # los vectores de la parte 1 se copian: no se vuelven a codificar
        shutil.copytree(p1 / "texto", salida / "texto")
    canal, desc = preparar_texto(salida, datos, dispositivo, log, rapido, a)
    _liberar_memoria()
    desc_adic = descripciones_adicionales(salida, adic, datos, dispositivo, log, rapido, a)
    e3 = P3.E3(RAIZ, salida, PLAN, datos, canal, desc, dispositivo, log, rapido, a, adic, desc_adic, parte1=p1)

    for etapa in [e for e in ETAPAS if e in a.etapas and e != "verificar"]:
        log(f"---- Etapa: {etapa}")
        try:
            with tqdm(total=None, desc=f"E3 {etapa}", unit="modelo", dynamic_ncols=True, ascii=ASCII) as barra:
                e3.barra = barra
                if etapa == "estimar":
                    resumen["estimar"] = estimar(e3, log, salida / "estimacion")
                elif etapa == "diseno":
                    resumen["diseno"] = {k: v for k, v in e3.diseno().items() if k != "resumen"}
                elif etapa == "ajuste":
                    resumen["ajuste"] = e3.ajuste()
                elif etapa == "piloto":
                    resumen["piloto"] = e3.piloto_original().MASE.mean()
                elif etapa == "adicionales_ajuste":
                    resumen["adicionales_ajuste"] = e3.adicionales_original(a.conjuntos)
                elif etapa == "potencia":
                    resumen["potencia"] = e3.potencia()
                elif etapa == "familia":
                    resumen["familia"] = e3.familia().groupby("clave").MASE.mean().to_dict()
                elif etapa == "adicionales":
                    t = e3.adicionales(a.conjuntos)
                    resumen["adicionales"] = t.groupby(["conjunto", "clave"]).MASE.mean().reset_index().to_dict("records") if len(t) else []
                elif etapa == "ablacion":
                    resumen["ablacion"] = e3.ablacion().groupby("variante").MASE.mean().to_dict()
                elif etapa == "sensibilidad":
                    resumen["sensibilidad"] = e3.sensibilidad().groupby("punto").MASE.mean().to_dict()
                elif etapa == "curva":
                    resumen["curva"] = e3.curva().groupby(["clave", "fraccion"]).MASE.mean().reset_index().to_dict("records")
                elif etapa == "escalabilidad":
                    resumen["escalabilidad"] = f"{len(e3.escalabilidad())} mediciones"
                elif etapa == "robustez":
                    resumen["robustez"] = f"{len(e3.robustez())} evaluaciones"
                elif etapa == "sanidad":
                    resumen["sanidad"] = e3.sanidad()
                elif etapa == "exportar":
                    resumen["exportar"] = exportacion.exportar(e3, salida / "artifacts")
                elif etapa == "interpretabilidad":
                    resumen["interpretabilidad"] = interpretabilidad.ejecutar(e3)
                elif etapa == "estadistica":
                    resumen["estadistica"] = estadistica_e3.ejecutar(e3).get("veredicto")
        except P3.SinResultadosE2 as err:
            log(f"Etapa {etapa} omitida: {err}")
            resumen[etapa] = f"omitida: {err}"
        PR.guardar_json(salida / "RESUMEN_E3.json", resumen)
        _liberar_memoria()
    log(f"Etapas terminadas en {(time.time() - t_ini) / 3600:.2f} h.")
    if not a.sin_empaquetar and a.etapas not in (["estimar"], ["verificar"], ["verificar", "estimar"]):
        empaquetar(salida, log, a.parte)
    return 0


if __name__ == "__main__":
    sys.exit(main())

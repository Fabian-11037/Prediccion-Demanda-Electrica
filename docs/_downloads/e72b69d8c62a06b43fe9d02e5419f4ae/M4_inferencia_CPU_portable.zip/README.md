# Inferencia portable de M4_N

Python 3.13, CPU. No se necesitan PyTorch, el repositorio ni rutas externas.

```
python -m venv .venv
# Windows: .venv/Scripts/python; Linux: .venv/bin/python
python -m pip install -r requirements.txt
python ejecutar.py --verificar
python ejecutar.py --entrada ejemplo_0.npz --salida pronostico.json
```

El pipeline ejecuta tres expertos, reconstruye sus atributos del contexto, combina con M1 y consulta la memoria. Los cinco ejemplos tienen entradas anteriores a su origen, escaladas con parámetros conservados. El contrato NPZ contiene x/cp/cf/dia/nivel por experto; contexto numérico912; nivel_contexto; keys365×912 ya escaladas; days; origin; residuals365×24 normalizados por q. Los episodios ausentes se rellenan con edad cero y residuo cero. Antes de usar datos propios se debe construir este contrato con el preprocesamiento y las reglas de disponibilidad documentadas en el JBook; los ejemplos no sustituyen una adquisición automática de datos.

La predicción corresponde a la semilla101, prefijada; no es el promedio de pérdidas de las diez semillas. El manifiesto contiene hashes, tolerancia y errores del round-trip. exportacion.json conserva la procedencia.

Contenedor: `docker build -t m4-cpu .` y `docker run --rm m4-cpu`. El Dockerfile queda preparado; su construcción requiere un motor Docker disponible.

Orden de expertos en el contrato: índice0=PatchTST, índice1=E, índice2=periódico. exportacion.json registra los SHA-256 de los cinco checkpoints de origen. El ZIP se extrajo y verificó en un entorno Windows nuevo con las dependencias fijadas.
